# Değişiklik Günlüğü

## v0.0.8 — 2026-09-24

- Gerçek Android APK üretimi için tekrarlanabilir GitHub Actions hattı eklendi.
- Derleme araç zinciri `config/build_profile.json` içinde sabitlendi: Godot 4.7.2, Java 17, API 33–36, Build Tools 36.0.0, NDK 29.0.13113456, CMake 3.31.6, arm64-v8a ve llama.cpp v0.4.1.
- Android kaynak/AAR/export sözleşmesini statik doğrulayan `tools/verify_android_contract.py` eklendi.
- Android ön kontrolüne Build Tools ve CMake denetimi eklendi.
- Model Merkezi'ne uygulama açılışında seçili modeli otomatik yükleme seçeneği eklendi.
- Yüklü gerçek model için tek tuşlu **Yerel AI Türkçe self-test** akışı eklendi.
- Self-test, yerel modelden beklenen Türkçe hazır mesajını almadığında başarısız kabul edilir.
- Model paneli taşmayı önlemek için kaydırılabilir hale getirildi.
- Otomatik yükleme UI senkronizasyonunda sinyal döngüsü engellendi.
- CI hattındaki strict Android ön-kontrolü artık hata durumunu gizlemez.

## v0.0.6 — 2026-09-24

- Android gerçek APK hattı için `Android Debug` export preset eklendi; Gradle build, API 33–36 ve arm64 hedefi hazırlandı.
- `YerelAIBackend` Godot editor eklentisi proje ayarlarında varsayılan etkin hale getirildi.
- llama.cpp hazırlama betiği değişken `master` yerine varsayılan `v0.4.1` sürümüne sabitlendi.
- Android native köprüye cihaz tanısı eklendi: RAM, boş depolama, Android API, ABI ve backend/model durumu.
- GGUF seçiminde gerçek dosya imzası doğrulaması eklendi.
- Büyük GGUF aktarımına ön boş alan kontrolü, arka plan kopyalama, yüzde ilerleme ve `.part` atomik tamamlama eklendi.
- Model yüklemeden önce GGUF yeniden doğrulanıyor.
- Model Merkezi'ne `CİHAZI VE MODELİ KONTROL ET` ekranı eklendi.
- Android derleme ortamı için `tools/android_preflight.py` ve tek komut debug APK betiği eklendi.
- Türkçe arayüz/durum mesajları yeni Android akışının tamamına uygulandı.

## v0.0.5

- Yeni **İhale ve Sözleşme Uzmanı** ajanı eklendi.
- KİK, YFK, ihale/sözleşme mevzuatı ve diğer resmi kaynakları ayrı kategorilerde tutan yerel karar korpusu eklendi.
- İhale uzmanı proje RAG'i ile karar/mevzuat RAG'ini birlikte kullanabiliyor.
- Karar numarası/tarihi için otomatik meta veri çıkarımı eklendi.
- KİK karar numarası biçimi için yerel metin algılama eklendi.
- Yerel arşiv kapsamı ve son güncelleme bilgisi kullanıcıya gösteriliyor.
- Android ve masaüstü belge içe aktarıcı, proje belgesi ile ihale korpusu hedeflerini ayıracak şekilde genişletildi.
- Çok sayıda kararın tek dosyada yüklenmesi için `yerel_ai_procurement_bundle` JSON paketi desteği eklendi.
- Korpus paketi oluşturmak için `tools/build_procurement_bundle.py` eklendi.
- İhale/sözleşme anahtarları geçen disiplinler arası toplantıya İhale ve Sözleşme Uzmanı otomatik katılıyor.
- Uygulama içinde KİK/EKAP resmi karar araması ve YFK resmi sayfasına kısayol eklendi.
- Resmi kaynak kayıtları `config/procurement_sources.json` dosyasına eklendi.
- Tüm yeni kullanıcı arayüzleri ve ajan davranışları Türkçe tutuldu.


## v0.0.4 — 2026-09-24

- Deterministik `EngineeringTools` mühendislik araç motoru eklendi.
- Basit mesnetli kirişte düzgün yayılı yük için mesnet tepkisi, kesme, moment ve isteğe bağlı elastik sehim hesabı eklendi.
- Basit mesnetli kirişte tekil yük için mesnet tepkileri ve yük altındaki moment hesabı eklendi.
- Dikdörtgen kesit A/I/W özellikleri, eksenel gerilme, alan yükü→çizgisel yük ve öz ağırlık araçları eklendi.
- Boyut ailesi kontrollü temel birim dönüşüm motoru eklendi.
- İnşaat Mühendisi, Koordinatör ve Genel Yerel Zekâ için kapalı araç çağırma protokolü eklendi.
- Ajan araç çağrısını yaptıktan sonra deterministik sonucu yeniden modele verip Türkçe açıklama üreten iki aşamalı akış eklendi.
- Uzman toplantılarında İnşaat Mühendisi için tek tur hesap aracı kullanımı bağlandı.
- Dünya içine fiziksel Mühendislik Hesap Masası ve arayüze HESAP paneli eklendi.
- Hesap geçmişi `user://engineering/history.jsonl` dosyasına proje/ajan bağlamıyla kaydediliyor.
- Temel mekanik hesabı ile mevzuata göre tasarım/yeterlilik kararı açık biçimde ayrıldı.
- TBDY 2018 için yalnız resmi kaynak meta kaydı eklendi; standart/metin içeriği pakete gömülmedi.
- Mühendislik eşitlikleri için bağımsız sayısal kontrol betiği eklendi.

## v0.0.3 — 2026-09-24

- Uygulama ve tüm ajanlar için varsayılan/zorunlu Türkçe yanıt kuralı eklendi.
- Proje oluşturma ve aktif proje seçme çalışma alanı eklendi.
- Proje belgelerini yerel JSON bilgi tabanında saklayan ProjectStore eklendi.
- Belgeleri örtüşmeli parçalara ayıran yerel indeksleme eklendi.
- Türkçe normalize edilmiş sözcüksel RAG araması eklendi.
- Ajan ve toplantı istemlerine kaynaklı proje bağlamı bağlandı.
- Kaynağa dayanan yanıtlarda [Kaynak N: ...] etiketi kuralı eklendi.
- Android belge seçiciyle PDF/TXT/MD/CSV/JSON içe aktarma eklendi.
- PDFBox-Android ile tamamen cihaz-içi PDF metin çıkarımı eklendi.
- PDF/belge işlemleri ve masaüstü metin okuma ana arayüz iş parçacığından ayrıldı.
- Görüntü/tarama PDF için OCR'ın henüz desteklenmediği açık hata mesajı eklendi.

## v0.0.2 — 2026-09-24

- Yerel model ayarları ve lisans kayıtları için ModelManager eklendi.
- Tek-model inference kuyruğu ve worker thread servisi eklendi.
- AgentRouter asenkron modele geçirildi.
- Yedi uzman + Koordinatör sentezli gerçek toplantı zinciri kuruldu.
- Godot 4.7 Android v2 `YerelAIBackend` Kotlin plugin kaynakları eklendi.
- Güncel llama.cpp Android `AiChat/InferenceEngine` API'sine köprü eklendi.
- Android Storage Access Framework ile GGUF importu eklendi.
- Godot model ekranı Android native picker sinyallerine bağlandı.
- llama.cpp AAR derleme ve Godot addon kurulum scriptleri eklendi.
- Model lisansının teknik yüklenebilirlikten ayrı doğrulanması eklendi.

## v0.0.1

- İlk procedural dünya, ajanlar, mobil kontroller, hafıza, chat UI ve demo backend.

