#!/usr/bin/env python3
from pathlib import Path
import os, shutil, subprocess, sys
ROOT = Path(__file__).resolve().parents[1]
checks=[]
def add(name, ok, detail): checks.append((name, bool(ok), str(detail)))
def version(cmd, args):
    path=shutil.which(cmd)
    if not path: return None, f"{cmd} bulunamadı"
    try:
        p=subprocess.run([path,*args],capture_output=True,text=True,timeout=10)
        lines=(p.stdout or p.stderr).strip().splitlines()
        return path, lines[0] if lines else path
    except Exception as e: return path, str(e)
java,jv=version('java',['-version']); add('Java/JDK', java is not None and ('17' in jv or '21' in jv), jv)
sdk=os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME')
add('Android SDK', bool(sdk and Path(sdk).exists()), sdk or 'ANDROID_SDK_ROOT / ANDROID_HOME tanımlı değil')
if sdk and Path(sdk).exists():
    sp=Path(sdk); add('Android API 36',(sp/'platforms/android-36').exists(),sp/'platforms/android-36'); add('Build Tools 36.0.0',(sp/'build-tools/36.0.0').exists(),sp/'build-tools/36.0.0'); add('NDK 29.0.13113456',(sp/'ndk/29.0.13113456').exists(),sp/'ndk/29.0.13113456'); add('CMake 3.31.6',(sp/'cmake/3.31.6').exists(),sp/'cmake/3.31.6')
else:
    add('Android API 36',False,'SDK bulunamadı'); add('Build Tools 36.0.0',False,'SDK bulunamadı'); add('NDK 29.0.13113456',False,'SDK bulunamadı'); add('CMake 3.31.6',False,'SDK bulunamadı')
godot=None; gd='Godot bulunamadı'
for c in [os.environ.get('GODOT_BIN',''),'godot4','godot']:
    if not c: continue
    path=shutil.which(c) if os.path.sep not in c else (c if Path(c).exists() else None)
    if path:
        godot=path
        try:
            r=subprocess.run([path,'--version'],capture_output=True,text=True,timeout=10); gd=(r.stdout or r.stderr).strip()
        except Exception as e: gd=str(e)
        break
add('Godot 4.7', bool(godot and '4.7' in gd), gd)
addon=ROOT/'addons/YerelAIBackend'
for title,rel in [('YerelAIBackend debug AAR','bin/debug/YerelAIBackend-debug.aar'),('YerelAIBackend release AAR','bin/release/YerelAIBackend-release.aar'),('llama.cpp debug AAR','bin/debug/llama-android-release.aar'),('llama.cpp release AAR','bin/release/llama-android-release.aar')]:
    f=addon/rel; add(title,f.exists(),f)
add('Android export preset',(ROOT/'export_presets.cfg').exists(),ROOT/'export_presets.cfg')
project=(ROOT/'project.godot').read_text(encoding='utf-8'); add('Godot eklentisi etkin','res://addons/YerelAIBackend/plugin.cfg' in project,'project.godot [editor_plugins]')
print('ANDROID PREFLIGHT')
for name,ok,detail in checks: print(f"[{'OK' if ok else 'EKSİK'}] {name}: {detail}")
print(f"\nSonuç: {sum(ok for _,ok,_ in checks)}/{len(checks)} kontrol geçti.")
strict='--strict' in sys.argv
fatal={'Java/JDK','Android SDK','Android API 36','Build Tools 36.0.0','NDK 29.0.13113456','CMake 3.31.6','Godot 4.7','Android export preset','Godot eklentisi etkin'}
if strict: fatal |= {'YerelAIBackend debug AAR','llama.cpp debug AAR'}
failed=[n for n,o,_ in checks if not o and n in fatal]
if failed:
    print('Derleme hazır değil: '+', '.join(failed)); sys.exit(1)
print('ANDROID PREFLIGHT OK')
