#!/usr/bin/env python3
from pathlib import Path
import json, re, sys

root = Path(__file__).resolve().parents[1]
errors=[]

# JSON files
for p in root.rglob('*.json'):
    try:
        json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        errors.append(f'JSON {p.relative_to(root)}: {e}')

# res:// references in text-based Godot files
for p in list(root.rglob('*.gd')) + list(root.rglob('*.tscn')) + [root/'project.godot']:
    text=p.read_text(encoding='utf-8')
    for ref in re.findall(r'res://[^\"\'\)\]\s]+', text):
        # Strip punctuation sometimes adjacent in config.
        rel=ref[len('res://'):].rstrip(',;')
        if not (root/rel).exists():
            errors.append(f'Missing resource from {p.relative_to(root)}: {ref}')

# Lightweight delimiter check that ignores strings/comments sufficiently for our scripts.
def check_delims(path: Path):
    text=path.read_text(encoding='utf-8')
    stack=[]
    pairs={')':'(',']':'[','}':'{'}
    opens=set(pairs.values())
    quote=None
    triple=False
    esc=False
    i=0
    while i < len(text):
        ch=text[i]
        if quote:
            if triple:
                if text.startswith(quote*3,i):
                    quote=None; triple=False; i+=3; continue
                i+=1; continue
            if esc: esc=False; i+=1; continue
            if ch=='\\': esc=True; i+=1; continue
            if ch==quote: quote=None
            i+=1; continue
        if text.startswith('"""',i) or text.startswith("'''",i):
            quote=text[i]; triple=True; i+=3; continue
        if ch in ('"',"'"):
            quote=ch; i+=1; continue
        if ch=='#':
            nl=text.find('\n',i)
            if nl<0: break
            i=nl+1; continue
        if ch in opens: stack.append((ch,i))
        elif ch in pairs:
            if not stack or stack[-1][0]!=pairs[ch]:
                errors.append(f'Delimiter mismatch in {path.relative_to(root)} at byte {i}')
                return
            stack.pop()
        i+=1
    if quote:
        errors.append(f'Unclosed string in {path.relative_to(root)}')
    if stack:
        errors.append(f'Unclosed delimiter in {path.relative_to(root)}: {stack[-1][0]}')

for p in root.rglob('*.gd'):
    check_delims(p)

# Required project files
required=[
    'project.godot','scenes/main.tscn','scripts/main.gd',
    'scripts/ai/agent_router.gd','scripts/ai/inference_service.gd','scripts/ai/local_ai.gd',
    'scripts/model/model_manager.gd','scripts/projects/project_store.gd','scripts/procurement/procurement_knowledge.gd','scripts/documents/document_importer.gd','scripts/engineering/engineering_tools.gd','config/procurement_sources.json','android_plugin/plugin/src/main/java/com/yerelai/backend/YerelAIBackendPlugin.kt',
    'android_plugin/export_scripts_template/export_plugin.gd','export_presets.cfg','tools/android_preflight.py','tools/build_android_debug.sh'
]
for rel in required:
    if not (root/rel).is_file(): errors.append(f'Missing required file: {rel}')


# Product language invariant
router=(root/'scripts/ai/agent_router.gd').read_text(encoding='utf-8')
if 'yalnızca Türkçe konuş ve yaz' not in router:
    errors.append('Türkçe ajan dil kuralı bulunamadı.')
if 'ProjectStore.build_rag_context' not in router:
    errors.append('Ajanlara proje RAG bağlamı bağlı değil.')

# Engineering tool invariant
engineering=(root/'scripts/engineering/engineering_tools.gd').read_text(encoding='utf-8')
for marker in ['basit_kiris_yayili_yuk','basit_kiris_tekil_yuk','dikdortgen_kesit','eksenel_gerilme','YEREL_ARAC']:
    if marker not in engineering:
        errors.append(f'Mühendislik aracı/işareti eksik: {marker}')
router=(root/'scripts/ai/agent_router.gd').read_text(encoding='utf-8')
if 'EngineeringTools.parse_tool_call' not in router or 'EngineeringTools.run_tool' not in router:
    errors.append('AgentRouter mühendislik araç motoruna bağlı değil.')
project=(root/'project.godot').read_text(encoding='utf-8')
if 'EngineeringTools="*res://scripts/engineering/engineering_tools.gd"' not in project:
    errors.append('EngineeringTools autoload kaydı eksik.')

# Procurement / contract expert invariant
procurement=(root/'scripts/procurement/procurement_knowledge.gd').read_text(encoding='utf-8')
for marker in ['build_context','archive_coverage_text','source_kind','KİK','YFK']:
    if marker not in procurement:
        errors.append(f'İhale bilgi tabanı işareti eksik: {marker}')
router=(root/'scripts/ai/agent_router.gd').read_text(encoding='utf-8')
for marker in ['"procurement"','İhale ve Sözleşme Uzmanı','ProcurementKnowledge.build_context']:
    if marker not in router:
        errors.append(f'İhale uzmanı entegrasyonu eksik: {marker}')
main=(root/'scripts/main.gd').read_text(encoding='utf-8')
for marker in ['İHALE VE SÖZLEŞME BİLGİ MERKEZİ','_toggle_procurement_panel','request_native_procurement_picker']:
    if marker not in main:
        errors.append(f'İhale arayüzü entegrasyonu eksik: {marker}')
project=(root/'project.godot').read_text(encoding='utf-8')
if 'ProcurementKnowledge="*res://scripts/procurement/procurement_knowledge.gd"' not in project:
    errors.append('ProcurementKnowledge autoload kaydı eksik.')


# Android v0.0.7 readiness invariant
project=(root/'project.godot').read_text(encoding='utf-8')
if 'res://addons/YerelAIBackend/plugin.cfg' not in project:
    errors.append('YerelAIBackend editor plugin etkin değil.')
export=(root/'export_presets.cfg').read_text(encoding='utf-8')
for marker in ['name="Android Debug"','gradle_build/use_gradle_build=true','architectures/arm64-v8a=true','gradle_build/min_sdk="33"','gradle_build/target_sdk="36"']:
    if marker not in export:
        errors.append(f'Android export preset işareti eksik: {marker}')
kotlin=(root/'android_plugin/plugin/src/main/java/com/yerelai/backend/YerelAIBackendPlugin.kt').read_text(encoding='utf-8')
for marker in ['GgufMetadataReader','getRuntimeDiagnostics','inspectModel','modelImportProgress','.part','MODEL_FREE_SPACE_RESERVE']:
    if marker not in kotlin:
        errors.append(f'Android native güvenlik/tanı işareti eksik: {marker}')
prepare=(root/'android_plugin/prepare_llama_android.sh').read_text(encoding='utf-8')
if 'LLAMA_CPP_REF:-v0.4.1' not in prepare:
    errors.append('llama.cpp sürümü v0.4.1 olarak sabitlenmemiş.')

if errors:
    print('VALIDATION FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print('VALIDATION OK')
print(f'Root: {root}')
print(f'GDScript files: {len(list(root.rglob("*.gd")))}')
print(f'Files total: {len([p for p in root.rglob("*") if p.is_file()])}')
