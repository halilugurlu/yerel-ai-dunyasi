#!/usr/bin/env python3
from pathlib import Path
import json, math

root=Path(__file__).resolve().parents[1]
e=json.loads((root/'tests/engineering_expected.json').read_text(encoding='utf-8'))

def close(a,b):
    return math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-9)

u=e['beam_udl']; L=u['span_m']; w=u['w_kn_m']
assert close(w*L/2,u['reaction_kn'])
assert close(w*L*L/8,u['moment_knm'])

p=e['beam_point']; L=p['span_m']; P=p['load_kn']; a=p['a_m']; b=L-a
ra=P*b/L; rb=P*a/L
assert close(ra,p['ra_kn']); assert close(rb,p['rb_kn']); assert close(ra*a,p['moment_knm'])

r=e['rect']; b=r['b_mm']; h=r['h_mm']; A=b*h; Ix=b*h**3/12; Iy=h*b**3/12
assert close(A,r['area_mm2']); assert close(Ix,r['ix_mm4']); assert close(Iy,r['iy_mm4'])
assert close(Ix/(h/2),r['wx_mm3']); assert close(Iy/(b/2),r['wy_mm3'])

a=e['axial']; assert close(a['force_kn']*1000/a['area_mm2'],a['stress_mpa'])
al=e['area_to_line']; assert close(al['q_kn_m2']*al['width_m'],al['w_kn_m'])
sw=e['self_weight']; assert close(sw['volume_m3']*sw['gamma_kn_m3'],sw['weight_kn'])

print('ENGINEERING MATH OK')
