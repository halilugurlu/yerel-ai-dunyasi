#!/usr/bin/env python3
from pathlib import Path
import json, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def need(cond, msg):
    if not cond:
        errors.append(msg)

profile_path = ROOT / "config/build_profile.json"
need(profile_path.exists(), "config/build_profile.json yok")
profile = json.loads(profile_path.read_text(encoding="utf-8")) if profile_path.exists() else {}
need(profile.get("product_version") == "0.0.8", "ürün sürümü 0.0.8 değil")
need(profile.get("godot") == "4.7.2-stable", "Godot sabitlemesi 4.7.2-stable değil")
need(profile.get("llama_cpp", {}).get("ref") == "v0.4.1", "llama.cpp v0.4.1'e sabit değil")
need(profile.get("android", {}).get("abi") == "arm64-v8a", "Android ABI arm64-v8a değil")

project = (ROOT / 'project.godot').read_text(encoding='utf-8')
need('textures/vram_compression/import_etc2_astc=true' in project, 'Android ETC2/ASTC doku sıkıştırması etkin değil')

preset = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
for fragment in [
    'name="Android Debug"',
    'gradle_build/use_gradle_build=true',
    'gradle_build/min_sdk="33"',
    'gradle_build/target_sdk="36"',
    'architectures/arm64-v8a=true',
    'version/code=8',
    'version/name="0.0.8"',
    'yerel-ai-dunyasi-v008-debug.apk',
]:
    need(fragment in preset, f"Android export sözleşmesi eksik: {fragment}")

plugin_gradle = (ROOT / "android_plugin/plugin/build.gradle.kts").read_text(encoding="utf-8")
for fragment in [
    'compileSdk = 36',
    'minSdk = 33',
    'org.godotengine:godot:4.7.2.stable',
    'compileOnly(files(llamaAar))',
]:
    need(fragment in plugin_gradle, f"plugin Gradle sözleşmesi eksik: {fragment}")

manifest = (ROOT / "android_plugin/plugin/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
need('org.godotengine.plugin.v2.' in manifest, "Godot Android plugin v2 manifest kaydı yok")

kotlin = (ROOT / "android_plugin/plugin/src/main/java/com/yerelai/backend/YerelAIBackendPlugin.kt").read_text(encoding="utf-8")
for fragment in [
    'class YerelAIBackendPlugin(godot: Godot) : GodotPlugin(godot)',
    '@UsedByGodot',
    'GgufMetadataReader',
    'AiChat.getInferenceEngine',
    'fun loadModel(',
    'fun generate(',
    'fun pickModel(',
    'fun getRuntimeDiagnostics(',
]:
    need(fragment in kotlin, f"Kotlin köprü sözleşmesi eksik: {fragment}")

export_plugin = (ROOT / "addons/YerelAIBackend/export_plugin.gd").read_text(encoding="utf-8")
for fragment in [
    '_get_android_libraries',
    'YerelAIBackend-debug.aar',
    'llama-android-release.aar',
    '_get_android_dependencies',
]:
    need(fragment in export_plugin, f"Godot export plugin sözleşmesi eksik: {fragment}")

workflow = ROOT / ".github/workflows/android-debug-apk.yml"
need(workflow.exists(), "GitHub Android APK iş akışı yok")
if workflow.exists():
    wt = workflow.read_text(encoding="utf-8")
    ci_script = ROOT / "tools/ci_android_debug.sh"
    need(ci_script.exists(), "CI Android derleme scripti yok")
    ct = ci_script.read_text(encoding="utf-8") if ci_script.exists() else ""
    combined = wt + "\n" + ct
    for fragment in [
        "v0.4.1",
        "4.7.2",
        "android-36",
        "yerel-ai-dunyasi-v008-debug.apk",
        "godotengine/godot-builds/releases/download",
        "python3 tools/android_preflight.py --strict",
    ]:
        need(fragment in combined, f"CI iş akışı sabitlemesi eksik: {fragment}")
    need("--strict || true" not in combined, "CI strict ön-kontrol hatayı yutuyor")

need((ROOT / "docs/ANDROID_BUILD_V008.md").exists(), "v0.0.8 Android derleme rehberi yok")
need((ROOT / "docs/GITHUB_ACTIONS_APK.md").exists(), "GitHub Actions APK rehberi yok")
need((ROOT / ".gitignore").exists(), ".gitignore yok")

if errors:
    print("ANDROID CONTRACT FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("ANDROID CONTRACT OK")
print("Godot: 4.7.2-stable | llama.cpp: v0.4.1 | Android: API 33-36 | ABI: arm64-v8a")
