#!/usr/bin/env python3
"""Yerel AI Dünyası için KİK/YFK/mevzuat toplu içe aktarma paketi üretir.

Kullanım:
  python tools/build_procurement_bundle.py ./indirilen_kararlar kik kararlar_kik.json

Girdi klasöründeki .txt, .md, .csv ve .json dosyalarının metni tek pakete alınır.
PDF metni bu araçta otomatik çıkarılmaz; Android uygulaması PDF'yi cihaz içinde içe alabilir.
"""
from pathlib import Path
import json, sys, time

if len(sys.argv) < 4:
    print("Kullanım: build_procurement_bundle.py <klasör> <kik|yfk|legislation|other> <çıktı.json>")
    raise SystemExit(2)

root = Path(sys.argv[1]).expanduser().resolve()
kind = sys.argv[2].strip().lower()
out = Path(sys.argv[3]).expanduser().resolve()
if kind not in {"kik", "yfk", "legislation", "other"}:
    raise SystemExit("Kaynak türü kik, yfk, legislation veya other olmalı.")
if not root.is_dir():
    raise SystemExit(f"Klasör bulunamadı: {root}")

records=[]
skipped=[]
for p in sorted(root.rglob('*')):
    if not p.is_file():
        continue
    if p.suffix.lower() not in {'.txt','.md','.csv','.json'}:
        if p.suffix.lower()=='.pdf':
            skipped.append(str(p.relative_to(root)))
        continue
    try:
        text=p.read_text(encoding='utf-8', errors='replace').strip()
    except Exception as exc:
        skipped.append(f"{p.relative_to(root)} ({exc})")
        continue
    if len(text)<20:
        continue
    records.append({
        "name": p.name,
        "source_kind": kind,
        "source_path": str(p.relative_to(root)),
        "metadata": {},
        "text": text,
    })

bundle={
    "type":"yerel_ai_procurement_bundle",
    "schema_version":1,
    "created_unix":int(time.time()),
    "source_kind":kind,
    "records":records,
}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding='utf-8')
print(f"Paket hazır: {out}")
print(f"Kayıt: {len(records)}")
if skipped:
    print(f"Atlanan/dönüştürülmesi gereken dosya: {len(skipped)}")
    for item in skipped[:20]: print(' -', item)
