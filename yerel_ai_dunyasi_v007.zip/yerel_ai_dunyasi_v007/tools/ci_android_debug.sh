#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT_VERSION="${GODOT_VERSION:-4.7.2}"
ANDROID_NDK_VERSION="${ANDROID_NDK_VERSION:-29.0.13113456}"
ANDROID_CMAKE_VERSION="${ANDROID_CMAKE_VERSION:-3.31.6}"
ANDROID_BUILD_TOOLS="${ANDROID_BUILD_TOOLS:-36.0.0}"
GODOT_ANDROID_NDK_VERSION="${GODOT_ANDROID_NDK_VERSION:-29.0.14206865}"
GODOT_ANDROID_BUILD_TOOLS="${GODOT_ANDROID_BUILD_TOOLS:-36.1.0}"
LLAMA_CPP_REF="${LLAMA_CPP_REF:-v0.4.1}"

cd "$ROOT"

# Android SDK path.
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/local/lib/android/sdk}}"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_NDK_HOME="$SDK_ROOT/ndk/$ANDROID_NDK_VERSION"

SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "$SDKMANAGER" ]]; then
  SDKMANAGER="$(find "$SDK_ROOT/cmdline-tools" -type f -name sdkmanager | sort -V | tail -1)"
fi
test -x "$SDKMANAGER"

yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true
"$SDKMANAGER" \
  "platform-tools" \
  "platforms;android-36" \
  "build-tools;$ANDROID_BUILD_TOOLS" \
  "build-tools;$GODOT_ANDROID_BUILD_TOOLS" \
  "ndk;$ANDROID_NDK_VERSION" \
  "ndk;$GODOT_ANDROID_NDK_VERSION" \
  "cmake;$ANDROID_CMAKE_VERSION"

# Godot binary + export templates.
mkdir -p "$HOME/bin" "$HOME/.local/share/godot/export_templates/4.7.2.stable"
GODOT_BIN="$HOME/bin/Godot_v${GODOT_VERSION}-stable_linux.x86_64"
if [[ ! -x "$GODOT_BIN" ]]; then
  curl -fL --retry 5 --retry-delay 3 \
    "https://github.com/godotengine/godot-builds/releases/download/${GODOT_VERSION}-stable/Godot_v${GODOT_VERSION}-stable_linux.x86_64.zip" \
    -o /tmp/godot.zip
  unzip -qo /tmp/godot.zip -d "$HOME/bin"
  chmod +x "$GODOT_BIN"
fi
export GODOT_BIN

TEMPLATE_DIR="$HOME/.local/share/godot/export_templates/4.7.2.stable"
if [[ ! -f "$TEMPLATE_DIR/android_debug.apk" ]]; then
  rm -rf /tmp/godot_templates
  mkdir -p /tmp/godot_templates
  curl -fL --retry 5 --retry-delay 3 \
    "https://github.com/godotengine/godot-builds/releases/download/${GODOT_VERSION}-stable/Godot_v${GODOT_VERSION}-stable_export_templates.tpz" \
    -o /tmp/templates.tpz
  unzip -q /tmp/templates.tpz -d /tmp/godot_templates
  cp -a /tmp/godot_templates/templates/. "$TEMPLATE_DIR/"
fi

test -f "$TEMPLATE_DIR/android_debug.apk"

# Guard against AndroidX versions that are newer than Godot 4.7.2's AGP.
if grep -R -nE 'androidx\.core:(core|core-ktx):1\.17\.0|androidx\.datastore:datastore-preferences:1\.2\.0' \
    addons/YerelAIBackend android_plugin/export_scripts_template android_plugin/plugin/build.gradle.kts; then
  echo "Uyumsuz AndroidX bağımlılığı bulundu; Godot 4.7.2 AGP 8.6.1 ile export durduruldu." >&2
  exit 1
fi

# Deterministic source checks before expensive native compilation.
python3 tools/validate_project.py
python3 tools/check_engineering_math.py
python3 tools/verify_android_contract.py
python3 tools/check_android_dependency_compat.py

# Build Android AI libraries. v0.0.8 scripts are ARM64/debug optimized.
export LLAMA_CPP_REF
./android_plugin/build_and_install.sh
python3 tools/android_preflight.py --strict

# Explicit disposable debug keystore avoids editor-state dependencies in CI.
DEBUG_KEYSTORE="${RUNNER_TEMP:-/tmp}/yerelai-debug.keystore"
rm -f "$DEBUG_KEYSTORE"
keytool -genkeypair \
  -keystore "$DEBUG_KEYSTORE" \
  -storepass android \
  -alias androiddebugkey \
  -keypass android \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -dname "CN=Android Debug,O=Yerel AI,C=TR" >/dev/null 2>&1
export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$DEBUG_KEYSTORE"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER="androiddebugkey"
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD="android"

# ETC2/ASTC is a hard Android export requirement on Linux CI.
grep -q '^textures/vram_compression/import_etc2_astc=true$' project.godot

mkdir -p build

timeout 30m "$GODOT_BIN" \
  --headless \
  --verbose \
  --path "$ROOT" \
  --install-android-build-template \
  --export-debug "Android Debug" \
  "$ROOT/build/yerel-ai-dunyasi-v008-debug.apk"

test -s build/yerel-ai-dunyasi-v008-debug.apk
sha256sum build/yerel-ai-dunyasi-v008-debug.apk > build/yerel-ai-dunyasi-v008-debug.apk.sha256
ls -lh build/yerel-ai-dunyasi-v008-debug.apk
cat build/yerel-ai-dunyasi-v008-debug.apk.sha256
