#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT_BIN="${GODOT_BIN:-}"
if [[ -z "$GODOT_BIN" ]]; then GODOT_BIN="$(command -v godot4 || command -v godot || true)"; fi
if [[ -z "$GODOT_BIN" ]]; then echo "Godot 4.7 bulunamadı. GODOT_BIN değişkenini ayarla." >&2; exit 1; fi
python3 "$ROOT/tools/validate_project.py"
python3 "$ROOT/tools/check_engineering_math.py"
python3 "$ROOT/tools/verify_android_contract.py"
python3 "$ROOT/tools/android_preflight.py" || true
if [[ ! -f "$ROOT/addons/YerelAIBackend/bin/debug/YerelAIBackend-debug.aar" || ! -f "$ROOT/addons/YerelAIBackend/bin/debug/llama-android-release.aar" ]]; then
  echo "Android AI eklentisi hazırlanıyor..."
  "$ROOT/android_plugin/build_and_install.sh"
fi
python3 "$ROOT/tools/android_preflight.py" --strict
mkdir -p "$ROOT/build"
"$GODOT_BIN" --headless --verbose --path "$ROOT"   --install-android-build-template   --export-debug "Android Debug"   "$ROOT/build/yerel-ai-dunyasi-v008-debug.apk"
test -s "$ROOT/build/yerel-ai-dunyasi-v008-debug.apk"
echo "APK hazır: $ROOT/build/yerel-ai-dunyasi-v008-debug.apk"
