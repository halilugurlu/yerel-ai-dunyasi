#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
files = [
    ROOT / "addons/YerelAIBackend/export_plugin.gd",
    ROOT / "android_plugin/export_scripts_template/export_plugin.gd",
    ROOT / "android_plugin/plugin/build.gradle.kts",
]
forbidden = [
    "androidx.core:core-ktx:1.17.0",
    "androidx.core:core:1.17.0",
    "androidx.datastore:datastore-preferences:1.2.0",
]
found=[]
for f in files:
    text=f.read_text(encoding="utf-8")
    for dep in forbidden:
        if dep in text:
            found.append(f"{f.relative_to(ROOT)} -> {dep}")
if found:
    raise SystemExit("UYUMSUZ ANDROID BAĞIMLILIĞI\n" + "\n".join(found))
print("ANDROID DEPENDENCY COMPAT OK")
