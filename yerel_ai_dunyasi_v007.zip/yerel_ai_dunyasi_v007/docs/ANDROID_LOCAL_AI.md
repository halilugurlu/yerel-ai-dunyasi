# Android Yerel AI Derleme Notları — v0.0.2

## Mimari

```text
Godot 4.7 oyun/UI
      │
      ▼
InferenceService (tek sıra + worker thread)
      │
      ▼
LocalAI.gd
      │
      ▼
Godot Android v2 plugin: YerelAIBackend
      │
      ▼
llama.cpp examples/llama.android/lib AAR
      │
      ▼
GGUF model (uygulamanın private files/models alanı)
```

## Neden Android plugin?

Yerel modelin native C/C++ kodu, Android lifecycle ve uygulama-private dosya yolu ile doğrudan çalışması gerekiyor. Godot dünyası yalnızca stabil bir `YerelAIBackend` sözleşmesi görür. Böylece llama.cpp güncellense veya ileride başka ücretsiz yerel backend seçilse oyun ve ajan katmanı değişmeden kalabilir.

## Gereksinimler

İlk entegrasyon resmi güncel `llama.cpp/examples/llama.android/lib` yapısını takip eder. Bu hat şu anda:

- compileSdk 36
- minSdk 33
- NDK 29.0.13113456
- Java/JVM 17
- arm64-v8a ve x86_64

hedefleriyle derlenmektedir. Bu nedenle v0.0.2'nin gerçek llama.cpp Android katmanı Android 13 / API 33 ve üstünü hedefler. Daha eski Android desteği gerekiyorsa daha sonra kendi daha düşük-minSdk JNI katmanımızı ayrı olarak ele alabiliriz.

## 1. llama.cpp Android AAR'ını hazırla

Linux/macOS/Git Bash/WSL ortamında:

```bash
cd android_plugin
./prepare_llama_android.sh
```

Script:

1. `ggml-org/llama.cpp` resmi deposunu `.third_party/llama.cpp` içine alır.
2. `examples/llama.android/lib` release AAR'ını resmi Gradle wrapper ile derler.
3. `plugin/libs/llama-android-release.aar` konumuna kopyalar.
4. Kullanılan git commit'ini `LLAMA_CPP_REVISION.txt` içine kaydeder.

Belirli bir revision/tag kullanmak için:

```bash
LLAMA_CPP_REF=<git-ref> ./prepare_llama_android.sh
```

Üretim sürümünde `master` yerine test edilmiş sabit commit/tag kullanılması tavsiye edilir.

## 2. Godot Android köprüsünü derle ve kur

```bash
./build_and_install.sh
```

Bu işlem hem debug hem release `YerelAIBackend` AAR'ını üretir ve gerekli dosyaları proje içindeki:

```text
addons/YerelAIBackend/
```

klasörüne kurar.

## 3. Godot ayarları

Godot Editor içinde:

1. `Project > Project Settings > Plugins` → `YerelAIBackend` → Enable.
2. `Project > Install Android Build Template`.
3. `Project > Export` → Android preset ekle.
4. `Gradle Build > Use Gradle Build` = `On`.
5. Android SDK/JDK yollarını doğrula.
6. Bağlı cihazda çalıştır veya debug APK üret.

## 4. Telefonda model seçimi

Uygulamada:

1. `MODEL` ekranını aç.
2. `GGUF SEÇ` düğmesine bas.
3. Android sistem dosya seçicisinden `.gguf` seç.
4. Dosya uygulamanın private `files/models/` klasörüne kopyalanır.
5. `MODELİ YÜKLE` düğmesine bas.

Bu yöntemde genel depolama izni gerekmiyor. Android'in Storage Access Framework seçicisi yalnızca kullanıcının seçtiği dosyayı uygulamaya açıyor.

## Native sözleşme

`YerelAIBackend` Godot singleton'ı şu metotları sağlar:

- `isModelLoaded() -> bool`
- `getActiveModelPath() -> String`
- `getBackendInfo() -> String`
- `loadModel(path: String) -> JSON String`
- `unloadModel()`
- `generate(payloadJson: String) -> String`
- `pickModel() -> bool`

Sinyaller:

- `modelImported(path, displayName)`
- `modelImportFailed(error)`

## Thread modeli

Kotlin köprüsündeki `loadModel()` ve `generate()` bloklayan metotlardır. Bunlar Godot ana/render thread'inden doğrudan çağrılmaz. `InferenceService.gd` bütün yükleme ve üretim işlerini tek worker thread ve tek kuyruk üzerinden sıraya sokar. Bu aynı zamanda tek LLM instance'ını birden fazla ajan arasında güvenli biçimde paylaşmamızı sağlar.

## Bilinen sınırlamalar

- v0.0.2 tokenları UI'ya parça parça stream etmez; Kotlin katmanı Flow'u toplar ve tam cevabı Godot'a döndürür. Godot tarafındaki kuyruk buna hazırdır; gerçek UI streaming sonraki iterasyonda eklenebilir.
- Resmi Android binding'in sampling ayarları şu anda tüm generation seçeneklerini dışarı açmadığı için `temperature` GDScript'ten native backend'e henüz uygulanmıyor.
- Model dosyaları büyük olabilir. Import sırasında cihazda hem kaynak dosya hem private kopya için yeterli boş alan gerekir.
- Büyük context/model kombinasyonları mobil RAM'i aşabilir; ilk testlerde 4K civarı context ve küçük/orta quantized modeller tercih edilmeli.

## v0.0.4 belge işleme

Android eklentisi PDF/TXT/MD/CSV/JSON seçimi için Storage Access Framework kullanır. PDF metni `pdfbox-android:2.0.27.0` ile cihaz içinde çıkarılır. Metin çıkarma işlemi Android arayüz iş parçacığında çalışmaz. Çıkarılan metin uygulamanın özel `files/documents/` alanına yazılır ve Godot tarafında aktif projenin yerel bilgi tabanına alınır.

Taranmış/görüntü PDF'leri için OCR henüz etkin değildir.
