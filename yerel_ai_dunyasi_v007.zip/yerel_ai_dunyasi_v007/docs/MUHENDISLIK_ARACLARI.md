# Mühendislik Araç Motoru — v0.0.4

Bu sürümde amaç, dil modelinin sayısal mühendislik hesabını tahmin etmesini engelleyip basit ve doğrulanabilir hesapları deterministik bir araç katmanına taşımaktır.

## İlk araçlar

- Basit mesnetli kiriş + düzgün yayılı yük: mesnet tepkileri, maksimum kesme, maksimum moment; E ve I verilirse elastik maksimum sehim.
- Basit mesnetli kiriş + tekil yük: mesnet tepkileri ve yük altındaki maksimum moment.
- Dikdörtgen kesit: A, Ix, Iy, Wx, Wy.
- Ortalama eksenel gerilme: σ=N/A.
- Alan yükünü tesir genişliği ile çizgisel yüke çevirme.
- Hacim ve kullanıcı tarafından verilen birim hacim ağırlıktan toplam ağırlık.
- Boyutsal aile kontrollü temel birim dönüşümü.

## Güvenlik sınırı

Bu araçlar temel statik, mukavemet ve birim işlemleridir. Şunları tek başına yapmaz:

- yük birleşimleri ve katsayıları,
- deprem hesabı,
- betonarme/çelik/ahşap tasarım dayanımı,
- stabilite ve ikinci mertebe kontrolleri,
- süneklik ve detaylandırma,
- temel-zemin tasarımı,
- yönetmeliğe göre nihai yeterlilik kararı.

Bu nedenle araç sonucu her zaman varsayımlar ve kapsam uyarısıyla döner. Mevzuata dayalı bir karar için sürümü doğrulanmış kaynak ve gerekli proje girdileri ayrıca gerekir.

## Ajan araç protokolü

İnşaat Mühendisi, Koordinatör ve Genel Yerel Zekâ uygun durumda aşağıdaki kapalı protokolü kullanabilir:

`<YEREL_ARAC>{"tool":"basit_kiris_yayili_yuk","args":{"span_m":5,"w_kn_m":12}}</YEREL_ARAC>`

Kullanıcı bu ham çağrıyı görmez. `AgentRouter` çağrıyı yakalar, `EngineeringTools` hesabı yapar ve sonucu tekrar yerel modele verir. Model bundan sonra Türkçe açıklama üretir.

Araç döngüsü sınırlıdır. Bir sohbet yanıtında en fazla iki ardışık hesap çağrısına izin verilir; toplantı uzmanında bir hesap turundan sonra rapor tamamlanır.

## Hesap geçmişi

Her araç çalışması cihazda `user://engineering/history.jsonl` dosyasına eklenir. Kayıtta proje kimliği, ajan, kullanıcı sorusu, araç, sonuç, varsayımlar ve zaman bilgisi bulunur. Bu kayıt ileride proje raporu ve hesap föyü üretimi için temel olacaktır.
