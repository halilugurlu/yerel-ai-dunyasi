# Android APK derleme rehberi — v0.0.8

Bu sürümün amacı, aynı kaynak kodundan tekrarlanabilir biçimde gerçek Android debug APK üretmektir. Uygulamanın kullanıcı dili ve yerel yapay zekâ varsayılanı Türkçedir.

## Sabitlenen araç zinciri

- Godot: **4.7.2 stable**
- Java: **17**
- Android min SDK: **33**
- Android target/compile SDK: **36**
- Build Tools: **36.0.0**
- NDK: **29.0.13113456**
- CMake: **3.31.6**
- ABI: **arm64-v8a**
- llama.cpp: **v0.4.1**

Bu değerler `config/build_profile.json` içinde tek yerde kayıtlıdır. llama.cpp Android kütüphanesi daha sıkı araç zinciri gerektirdiği için, yalnız Godot'un asgari Android şartlarıyla yetinilmez.

## Yerel derleme

Gerekli Android SDK/NDK/CMake ve Godot 4.7.2 kuruluysa proje kökünde:

```bash
./tools/build_android_debug.sh
```

Betik sırasıyla proje doğrulamasını, mühendislik matematik testlerini, Android sözleşme kontrolünü, llama.cpp AAR derlemesini, Godot Android eklentisi AAR derlemesini ve son olarak Godot debug APK export'unu çalıştırır.

Başarılı çıktı:

```text
build/yerel-ai-dunyasi-v008-debug.apk
```

## Ön kontrol

Derleme ortamını değiştirmeden yalnız kontrol etmek için:

```bash
python3 tools/android_preflight.py
```

Eksik bileşen varsa derlemeyi durdurmak için:

```bash
python3 tools/android_preflight.py --strict
```

## GitHub Actions ile APK

Projede `.github/workflows/android-debug-apk.yml` bulunur. GitHub'a gönderildiğinde **Android Debug APK** iş akışı elle (`workflow_dispatch`) veya `main` dalındaki ilgili değişikliklerde çalışır.

Akış:

1. Java 17 ve Android SDK/NDK/CMake kurar.
2. Statik proje ve mühendislik testlerini çalıştırır.
3. llama.cpp `v0.4.1` Android AAR'ını derler.
4. `YerelAIBackend` AAR'ını üretip Godot eklentisine yerleştirir.
5. Resmi Godot 4.7.2 Linux editörünü ve export şablonlarını indirir.
6. Godot'u headless açarak başlangıç/sözdizimi kontrolü yapar.
7. Android Gradle build template'ini kurar ve debug APK üretir.
8. APK ile SHA-256 dosyasını GitHub Actions artefaktı olarak saklar.

CI'da `ANDROID_HOME` ve `JAVA_HOME` ortam değişkenleri Godot tarafından Android/Java SDK yolu için kullanılır.

## İlk telefon testi

APK kurulduktan sonra ilk doğrulama sırası:

1. Uygulamayı aç.
2. `MODEL` ekranını aç ve `CİHAZI VE MODELİ KONTROL ET` ile cihaz tanısını gör.
3. Lisansı ayrıca doğrulanmış bir `.gguf` seç.
4. Kopyalama bitene kadar yüzde ilerlemeyi takip et.
5. Modeli yükle.
6. `YEREL AI TÜRKÇE TESTİNİ ÇALIŞTIR` düğmesine bas.
7. Test başarılıysa Genel Yerel Zekâ ve en az iki uzman ajanla sohbet et.
8. Uygulamayı kapat/aç; istenirse otomatik model yükleme seçeneğini doğrula.

## Dağıtım notu

Debug APK yalnız geliştirme/test içindir. Bir GGUF modelinin teknik olarak çalışması, modelin ticari kullanım veya yeniden dağıtım için uygun olduğu anlamına gelmez. Model uygulamanın içine ancak lisansı ayrıca doğrulandıktan sonra gömülebilir.
