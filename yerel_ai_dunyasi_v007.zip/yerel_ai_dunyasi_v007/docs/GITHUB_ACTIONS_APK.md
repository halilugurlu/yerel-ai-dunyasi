# GitHub Actions ile tekrarlanabilir APK üretimi

`Android Debug APK` iş akışı, yerel makinedeki Android SDK kurulumuna bağlı kalmadan temiz bir Ubuntu koşucusunda APK üretmek için hazırlanmıştır.

## Neden var?

Bu proje Godot + Kotlin Android plugin + llama.cpp native AAR olmak üzere üç ayrı derleme katmanı kullanır. CI hattı bu katmanları aynı sabit sürümlerle her seferinde yeniden kurarak “benim bilgisayarımda çalışıyor” farkını azaltır.

## Üretilen artefakt

Başarılı çalışmada:

- `yerel-ai-dunyasi-v008-debug.apk`
- `yerel-ai-dunyasi-v008-debug.apk.sha256`

`yerel-ai-dunyasi-v008-android-debug` adlı Actions artefaktı içinde oluşur.

## Güvenlik

- Kaynak repo'da model dosyası veya kişisel proje belgesi bulunmaz.
- Workflow yalnız kaynak kodu ve açık kaynak bağımlılıkları derler.
- Release imzalama anahtarı kullanılmaz; çıktı debug APK'dır.
- Model lisansı APK derlemesinden ayrı kontroldür.
