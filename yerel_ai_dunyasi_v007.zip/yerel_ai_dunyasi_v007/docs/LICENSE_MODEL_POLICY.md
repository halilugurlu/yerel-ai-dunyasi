# Model ve Bağımlılık Lisans Politikası

Bu proje için teknik olarak çalışan bir bileşen, otomatik olarak dağıtıma uygun sayılmaz.

## Kural

Bir model/asset/bağımlılık ürünle dağıtılmadan önce en az şu bilgiler kayıt altına alınmalıdır:

- Kaynak/depo/model kartı
- Lisans adı ve tam lisans metnine erişim
- Ticari kullanıma izin durumu
- Yeniden dağıtım koşulları
- Attribution/NOTICE yükümlülükleri
- Türetilmiş model/quantization koşulları
- Kullanım alanı kısıtları varsa bunlar
- İnceleme tarihi ve sabit sürüm/revision

## Çalıştırma ile dağıtım ayrımı

Kullanıcının kendi cihazına seçtiği harici GGUF dosyasını yüklemesi ile uygulamanın APK/AAB paketinin içine o modeli gömerek yeniden dağıtması hukuken aynı işlem değildir. Bu nedenle ModelManager iki durumu ayrı tutar.

## Üretim yaklaşımı

- Ücretli model API'si çekirdeğin zorunlu bileşeni olmayacak.
- Lisansı belirsiz model uygulamaya gömülmeyecek.
- Model lisansı sonradan değişebileceği için üretim sürümü belirli bir model revision/hash ile sabitlenecek.
- Üçüncü taraf NOTICE/lisans dosyaları dağıtım paketinde korunacak.
