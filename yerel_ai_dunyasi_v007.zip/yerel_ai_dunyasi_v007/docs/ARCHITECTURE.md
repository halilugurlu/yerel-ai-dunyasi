# Yerel AI Dünyası — Mimari v0.0.4

## Değişmez ürün kuralları

- Kullanıcıya dönük dil Türkçedir.
- Ajanlar varsayılan olarak yalnızca Türkçe yanıt verir.
- Çekirdek yerel çalışmayı hedefler; ücretli API zorunlu değildir.
- Kritik mühendislik hesabı LLM tahminine bırakılmaz.
- Proje belgeleri cihaz içinde indekslenir ve kaynak etiketiyle bağlama alınır.
- Lisansı/ticari kullanım hakkı doğrulanmamış model, standart veya veri ürüne gömülmez.

## Temel veri yolu

`Proje Çalışma Alanı -> Belge İçe Aktarıcı -> ProjectStore -> Yerel RAG -> AgentRouter -> InferenceService -> Yerel GGUF`

## Mühendislik araç yolu

`Kullanıcı -> İnşaat Mühendisi / Koordinatör / Genel AI -> <YEREL_ARAC> çağrısı -> EngineeringTools -> deterministik sonuç -> AgentRouter -> yerel model -> Türkçe açıklama`

LLM araç çağrısının hangi hesap için gerektiğini seçebilir; sayısal eşitliği çalıştıran taraf LLM değildir. Araç sonucu varsayımlar, kapsam sınırı ve hesap geçmişiyle birlikte döner.

## Katmanlar

1. **Godot dünya ve UI:** açık dünya prototipi, ofis, uzman NPC'ler ve mobil kontrol.
2. **AgentRouter:** kim konuşuyor, hangi proje/RAG bağlamı ve hangi uzman araçları kullanılacak.
3. **EngineeringTools:** test edilebilir temel statik/mukavemet/birim hesapları.
4. **ProjectStore + DocumentImporter:** proje ve tamamen yerel belge/RAG katmanı.
5. **MemoryStore:** cihaz içi kalıcı konuşma geçmişi.
6. **InferenceService:** tek model kuyruğu, arka plan iş parçacığı ve ajan talepleri.
7. **LocalAI:** backend'den bağımsız tek model kapısı.
8. **Android native backend:** GGUF/model yükleme, llama.cpp inference ve yerel dosya seçicileri.

## Mühendislik güvenlik modeli

v0.0.4 hesap araçları temel mekanik sonuçları üretir; bunlar tek başına tasarım onayı değildir. Yük birleşimi, malzeme tasarım dayanımı, deprem, stabilite, süneklik, detaylandırma ve zemin/temel kontrolleri ancak ilgili doğrulanmış mevzuat modülü ve gerekli proje verileri mevcut olduğunda eklenebilir.

TBDY 2018 resmi AFAD kaynağının yalnız kimlik/tarih bilgisi `config/engineering_references.json` içinde tutulur. Tam standart/metin paketlemeye dahil edilmez. Kullanıcının hukuka uygun eriştiği teknik belgeler proje alanına eklenerek yerel RAG üzerinden kullanılabilir.
