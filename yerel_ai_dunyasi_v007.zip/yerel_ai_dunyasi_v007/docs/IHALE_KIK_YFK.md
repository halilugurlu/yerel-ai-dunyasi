# İhale ve Sözleşme Uzmanı — KİK / YFK bilgi mimarisi

## Amaç

Uygulamadaki **İhale ve Sözleşme Uzmanı**, kamu ihale mevzuatı ve yapım sözleşmesi uygulamalarında kullanıcıya Türkçe yardımcı olur. Uzman; KİK kararlarını, Yüksek Fen Kurulu (YFK) karar/görüşlerini ve ihale/sözleşme mevzuatını aynı belge türüymüş gibi değerlendirmez.

## Kaynak türleri

- `kik`: Kamu İhale Kurulu kararları ve EKAP karar çıktıları.
- `yfk`: Yüksek Fen Kurulu kararları ve görüşleri.
- `legislation`: 4734, 4735 ve ilgili ikincil mevzuat / Yapım İşleri Genel Şartnamesi gibi normatif kaynaklar.
- `other`: diğer resmi veya kullanıcı tarafından güvenilirliği ayrıca değerlendirilecek kaynaklar.

Resmi kaynak kayıtları `config/procurement_sources.json` dosyasında tutulur. Bu dosya karar metinlerinin kendisini paketlemez; resmi başvuru noktalarını ve kaynağın niteliğini kaydeder.

## Yerel karar arşivi

İçe aktarılan belgeler `user://procurement_knowledge/corpus.json` altında cihazda saklanır ve yaklaşık 1.800 karakterlik örtüşmeli parçalara ayrılır. Arama; karar numarası/tarih meta verisini, belge adını ve Türkçe anahtar sözcükleri birlikte puanlar.

YFK belgelerindeki `Karar No`, `Görüş No`, `Karar Tarihi` ve `Görüş Tarihi` alanları mümkün olduğunda otomatik çıkarılır. KİK karar numaraları için de karar metnindeki tipik numara biçimi aranır.

## Cevap güvenlik kuralı

Ajan, yerel arşivde bulunmayan karar numarası/tarih/sonuç uydurmaz. Yerel arşivin eksik olması, bir kararın resmi kaynakta bulunmadığı anlamına gelmez. Ajan gerektiğinde resmi kaynakta güncellik doğrulaması gerektiğini açıkça belirtir.

Kaynağa dayalı cevapta etiketler korunur:

- `[KİK N: ...]`
- `[YFK N: ...]`
- `[MEVZUAT N: ...]`

## “Bütün kararlar” hedefi

Tek tek dosya seçmek yerine toplu korpus yüklemek için `tools/build_procurement_bundle.py` kullanılır. Araç, bir klasördeki metin tabanlı kararları tek bir `yerel_ai_procurement_bundle` JSON dosyasına dönüştürür. Bu JSON uygulamada tek seferde içe aktarılabilir.

Tam arşiv iddiası yalnızca kararların gerçekten edinilip indekslenmesi ve güncellik kontrolünün yapılması halinde gösterilmelidir. Resmi web sayfasında yalnızca örnek karar/görüş yayımlanıyorsa sistem bunu “tam YFK arşivi” saymaz.
