# Proje Belgesi ve Yerel RAG Mimarisi

## Amaç

Her proje kendi belgelerine sahip olur. Ajanlar bütün belgeleri her soruda modele doldurmaz; bunun yerine yalnızca soruyla ilgili parçalar seçilir. Böylece bağlam daha küçük kalır, mobil model daha hızlı çalışır ve kaynağın nereden geldiği izlenebilir.

## Veri akışı

1. Kullanıcı aktif projeyi seçer.
2. PDF/TXT/MD/CSV/JSON belge ekler.
3. Android'de PDF metni cihaz içinde çıkarılır.
4. Metin yaklaşık 1.500 karakterlik, örtüşmeli parçalara ayrılır.
5. Soru Türkçe normalize edilir.
6. Belge parçaları yerel olarak puanlanır.
7. En ilgili parçalar `[Kaynak N: ...]` etiketiyle ajanın sistem bağlamına eklenir.
8. Ajan, belgeye dayanan iddiasında kaynak etiketini kullanmak zorundadır.

## Gizlilik

Bu katmanın çalışması için belge içeriğinin bir bulut hizmetine gönderilmesi gerekmez. Proje indeksi ve konuşma hafızası `user://` altında uygulamanın kendi verisinde tutulur.

## Sınırlar

- İlk sürümde arama sözcüksel/ifade tabanlıdır; embedding henüz zorunlu değildir.
- Taranmış görüntü PDF'leri OCR gerektirir; OCR v0.0.4 kapsamında değildir.
- Kaynak bulunması cevabın teknik olarak doğru olduğu garantisi değildir. Mevzuatın yürürlük tarihi ve mühendislik hesapları ayrıca doğrulanmalıdır.
