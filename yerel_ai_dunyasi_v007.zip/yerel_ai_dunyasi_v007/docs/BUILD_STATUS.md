# v0.0.8 Derleme / Doğrulama Durumu

## Kaynak ve proje doğrulaması

Bu paket üzerinde statik proje doğrulaması, deterministik mühendislik matematik testleri, Android entegrasyon sözleşmesi kontrolü, Python sözdizimi ve Bash sözdizimi kontrolleri çalıştırılır.

## Android v0.0.8 hattı

- Android debug export preset: **HAZIR** — Gradle, min API 33, target API 36, arm64-v8a.
- `YerelAIBackend` Godot v2 Android eklentisi: **KAYNAK HAZIR**.
- llama.cpp kaynak sürümü: **`v0.4.1` SABİT**.
- GGUF dosya biçimi/imza doğrulaması: **AKTİF**.
- Büyük model kopyalama: **arka plan thread + ilerleme + boş alan kontrolü + `.part` güvenli tamamlama**.
- Android cihaz tanısı: **RAM / depolama / SDK / ABI / backend**.
- Açılışta seçili modeli otomatik yükleme: **HAZIR**.
- Gerçek model Türkçe self-test: **HAZIR**.
- GitHub Actions tekrarlanabilir APK hattı: **HAZIR**.
- Türkçe ajan ve kullanıcı arayüzü kuralı: **AKTİF**.

## Bu çalışma ortamının sınırı

Bu sohbetin çalışma konteynerinde Android SDK/NDK/CMake ve Godot 4.7.2 ikilileri kurulu değildir; ayrıca dışarıdan bu büyük araç zinciri ikililerini konteynere indirme erişimi yoktur. Bu nedenle burada **gerçek AAR/APK ikilisi üretildiği veya fiziksel Android cihazda çalıştırıldığı iddia edilmez**.

Bu engeli aşmak için v0.0.8 paketine temiz Ubuntu koşucusunda tüm araç zincirini kurup APK üreten GitHub Actions iş akışı eklendi. GitHub bağlantısı/repoya yazma erişimi sağlandığında aynı kaynak CI üzerinde gerçek derlemeye gönderilebilir.

## Gerçek cihaz kabul kriteri

v0.0.8 “Android smoke test geçti” sayılmadan önce şu maddelerin tamamı görülmelidir:

1. Debug APK hatasız üretilmeli ve SHA-256 kaydı alınmalı.
2. ARM64, Android 13+ fiziksel cihazda kurulmalı.
3. Cihaz tanısı ekranı doğru RAM/depolama/API/ABI bilgisini göstermeli.
4. Geçerli bir GGUF seçilip kopyalanmalı ve model yüklenmeli.
5. `YEREL AI TÜRKÇE TESTİNİ ÇALIŞTIR` başarılı olmalı.
6. Genel Yerel Zekâ ile en az iki uzman ajan gerçek model üzerinden Türkçe yanıt vermeli.
7. Uygulama kapanıp açıldıktan sonra hafıza ve isteğe bağlı otomatik model yükleme doğrulanmalı.
