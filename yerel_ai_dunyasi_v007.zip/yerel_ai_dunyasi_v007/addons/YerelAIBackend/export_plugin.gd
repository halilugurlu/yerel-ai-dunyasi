@tool
extends EditorPlugin

var export_plugin: AndroidExportPlugin

func _enter_tree() -> void:
    export_plugin = AndroidExportPlugin.new()
    add_export_plugin(export_plugin)

func _exit_tree() -> void:
    if export_plugin != null:
        remove_export_plugin(export_plugin)
        export_plugin = null

class AndroidExportPlugin extends EditorExportPlugin:
    var _plugin_name := "YerelAIBackend"

    func _supports_platform(platform: EditorExportPlatform) -> bool:
        return platform is EditorExportPlatformAndroid

    func _get_android_libraries(_platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
        if debug:
            return PackedStringArray([
                "YerelAIBackend/bin/debug/YerelAIBackend-debug.aar",
                "YerelAIBackend/bin/debug/llama-android-release.aar"
            ])
        return PackedStringArray([
            "YerelAIBackend/bin/release/YerelAIBackend-release.aar",
            "YerelAIBackend/bin/release/llama-android-release.aar"
        ])

    func _get_android_dependencies(_platform: EditorExportPlatform, _debug: bool) -> PackedStringArray:
        return PackedStringArray([
            "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2",
            "com.tom-roush:pdfbox-android:2.0.27.0"
        ])

    func _get_android_dependencies_maven_repos(_platform: EditorExportPlatform, _debug: bool) -> PackedStringArray:
        return PackedStringArray([
            "https://maven.google.com",
            "https://repo1.maven.org/maven2"
        ])

    func _get_name() -> String:
        return _plugin_name
