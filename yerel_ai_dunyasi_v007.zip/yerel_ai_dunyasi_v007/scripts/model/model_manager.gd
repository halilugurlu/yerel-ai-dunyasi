extends Node

signal settings_changed

const SETTINGS_PATH := "user://local_ai_model.json"

var settings: Dictionary = {
    "schema_version": 4,
    "language": "tr-TR",
    "force_turkish": true,
    "auto_load_on_startup": false,
    "selected_model_path": "",
    "display_name": "",
    "license": {
        "name": "",
        "source": "",
        "reviewed": false,
        "commercial_use_allowed": false,
        "notes": ""
    },
    "generation": {
        "max_tokens": 768,
        "temperature": 0.25
    }
}

func _ready() -> void:
    load_settings()

func load_settings() -> void:
    if not FileAccess.file_exists(SETTINGS_PATH):
        return
    var file := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        _merge_dict(settings, parsed)

func save_settings() -> void:
    var file := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(settings, "  "))
    settings_changed.emit()

func set_selected_model(path: String, display_name: String = "") -> void:
    settings["selected_model_path"] = path
    settings["display_name"] = display_name if not display_name.is_empty() else path.get_file()
    save_settings()

func clear_selected_model() -> void:
    settings["selected_model_path"] = ""
    settings["display_name"] = ""
    save_settings()

func set_license_info(license_name: String, source: String, reviewed: bool, commercial_allowed: bool, notes: String = "") -> void:
    settings["license"] = {
        "name": license_name,
        "source": source,
        "reviewed": reviewed,
        "commercial_use_allowed": commercial_allowed,
        "notes": notes
    }
    save_settings()


func set_auto_load_on_startup(enabled: bool) -> void:
    settings["auto_load_on_startup"] = enabled
    save_settings()

func should_auto_load_on_startup() -> bool:
    return bool(settings.get("auto_load_on_startup", false))

func set_generation_settings(max_tokens: int, temperature: float) -> void:
    settings["generation"] = {
        "max_tokens": clampi(max_tokens, 64, 4096),
        "temperature": clampf(temperature, 0.0, 2.0)
    }
    save_settings()

func get_model_path() -> String:
    return str(settings.get("selected_model_path", ""))

func get_display_name() -> String:
    return str(settings.get("display_name", ""))

func get_license() -> Dictionary:
    return settings.get("license", {}).duplicate(true)

func get_generation_settings() -> Dictionary:
    return settings.get("generation", {}).duplicate(true)

func is_distribution_safe() -> bool:
    var license: Dictionary = settings.get("license", {})
    return bool(license.get("reviewed", false)) and bool(license.get("commercial_use_allowed", false))

func license_status_text() -> String:
    var license: Dictionary = settings.get("license", {})
    if not bool(license.get("reviewed", false)):
        return "Lisans doğrulanmadı"
    if not bool(license.get("commercial_use_allowed", false)):
        return "Ticari kullanım onayı yok"
    var name := str(license.get("name", "")).strip_edges()
    if name.is_empty():
        return "Lisans doğrulandı"
    return "%s · ticari kullanım doğrulandı" % name

func _merge_dict(target: Dictionary, incoming: Dictionary) -> void:
    for key in incoming.keys():
        if target.has(key) and target[key] is Dictionary and incoming[key] is Dictionary:
            _merge_dict(target[key], incoming[key])
        else:
            target[key] = incoming[key]
