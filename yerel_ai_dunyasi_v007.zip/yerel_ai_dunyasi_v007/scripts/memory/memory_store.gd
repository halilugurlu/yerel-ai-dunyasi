extends Node

const SAVE_PATH := "user://ai_world_memory.json"
var data: Dictionary = {
    "conversations": {},
    "notes": [],
    "settings": {"schema_version": 1}
}

func _ready() -> void:
    load_memory()

func load_memory() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        data = parsed

func save_memory() -> void:
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(data, "  "))

func append_message(agent_id: String, speaker: String, text: String) -> void:
    if not data["conversations"].has(agent_id):
        data["conversations"][agent_id] = []
    data["conversations"][agent_id].append({
        "speaker": speaker,
        "text": text,
        "unix_time": Time.get_unix_time_from_system()
    })
    # Mobil cihazda bağlamın kontrolsüz büyümesini engelle.
    if data["conversations"][agent_id].size() > 80:
        data["conversations"][agent_id] = data["conversations"][agent_id].slice(data["conversations"][agent_id].size() - 80)
    save_memory()

func get_recent(agent_id: String, limit: int = 12) -> Array:
    var items: Array = data["conversations"].get(agent_id, [])
    if items.size() <= limit:
        return items.duplicate(true)
    return items.slice(items.size() - limit)

func clear_conversation(agent_id: String) -> void:
    data["conversations"][agent_id] = []
    save_memory()
