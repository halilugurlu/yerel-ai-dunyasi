extends Node

signal corpus_changed
signal source_registry_changed

const ROOT_DIR := "user://procurement_knowledge"
const CORPUS_PATH := ROOT_DIR + "/corpus.json"
const SOURCE_REGISTRY_PATH := "res://config/procurement_sources.json"
const SCHEMA_VERSION := 1

var _corpus: Dictionary = {
    "schema_version": SCHEMA_VERSION,
    "updated_unix": 0,
    "documents": []
}
var _source_registry: Dictionary = {"version": 1, "sources": []}

func _ready() -> void:
    _ensure_root()
    _load_corpus()
    _load_source_registry()

func _ensure_root() -> void:
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(ROOT_DIR))

func _load_corpus() -> void:
    if not FileAccess.file_exists(CORPUS_PATH):
        return
    var file := FileAccess.open(CORPUS_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        _corpus = parsed
        if not _corpus.has("documents"):
            _corpus["documents"] = []
        if not _corpus.has("updated_unix"):
            _corpus["updated_unix"] = 0

func _save_corpus() -> void:
    _ensure_root()
    _corpus["updated_unix"] = Time.get_unix_time_from_system()
    var file := FileAccess.open(CORPUS_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(_corpus, "  "))
    corpus_changed.emit()

func _load_source_registry() -> void:
    if not FileAccess.file_exists(SOURCE_REGISTRY_PATH):
        return
    var file := FileAccess.open(SOURCE_REGISTRY_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        _source_registry = parsed
        source_registry_changed.emit()

func get_source_registry() -> Dictionary:
    return _source_registry.duplicate(true)

func get_documents() -> Array:
    return _corpus.get("documents", []).duplicate(true)

func get_stats() -> Dictionary:
    var stats := {
        "documents": 0,
        "chunks": 0,
        "kik": 0,
        "yfk": 0,
        "legislation": 0,
        "other": 0,
        "updated_unix": int(_corpus.get("updated_unix", 0))
    }
    for doc in _corpus.get("documents", []):
        stats["documents"] += 1
        stats["chunks"] += int(doc.get("chunk_count", 0))
        var kind := str(doc.get("source_kind", "other"))
        if not stats.has(kind):
            kind = "other"
        stats[kind] += 1
    return stats

func add_document(display_name: String, source_kind: String, source_path: String, mime_type: String, text: String, metadata: Dictionary = {}) -> Dictionary:
    var cleaned := _clean_text(text)
    if cleaned.length() < 20:
        return {"ok": false, "error": "Belgede kullanılabilir metin bulunamadı."}
    var normalized_kind := source_kind.to_lower().strip_edges()
    if normalized_kind not in ["kik", "yfk", "legislation", "other"]:
        normalized_kind = "other"
    var document_id := _make_id(display_name)
    var chunks := _chunk_text(cleaned, 1800, 260)
    var auto_metadata := _extract_metadata(cleaned, normalized_kind)
    for key in metadata.keys():
        auto_metadata[key] = metadata[key]
    var record := {
        "id": document_id,
        "name": display_name,
        "source_kind": normalized_kind,
        "source_path": source_path,
        "mime_type": mime_type,
        "imported_unix": Time.get_unix_time_from_system(),
        "char_count": cleaned.length(),
        "chunk_count": chunks.size(),
        "metadata": auto_metadata,
        "chunks": chunks
    }
    _corpus["documents"].append(record)
    _save_corpus()
    return {"ok": true, "document_id": document_id, "chunks": chunks.size()}

func search(query: String, limit: int = 10, kinds: Array = []) -> Array:
    var query_tokens := _tokens(query)
    var normalized_query := _normalize(query)
    if query_tokens.is_empty() and normalized_query.length() < 3:
        return []
    var allowed: Dictionary = {}
    for kind in kinds:
        allowed[str(kind)] = true
    var results: Array = []
    for doc in _corpus.get("documents", []):
        var source_kind := str(doc.get("source_kind", "other"))
        if not allowed.is_empty() and not allowed.has(source_kind):
            continue
        var doc_name := str(doc.get("name", "Belge"))
        var metadata: Dictionary = doc.get("metadata", {}) if doc.get("metadata", {}) is Dictionary else {}
        var chunk_index := 0
        for chunk in doc.get("chunks", []):
            var chunk_text := str(chunk)
            var score := _score_chunk(query, normalized_query, query_tokens, chunk_text, doc_name, metadata)
            if score > 0.0:
                results.append({
                    "score": score,
                    "document_id": str(doc.get("id", "")),
                    "document_name": doc_name,
                    "source_kind": source_kind,
                    "chunk_index": chunk_index,
                    "metadata": metadata,
                    "text": chunk_text
                })
            chunk_index += 1
    results.sort_custom(func(a: Dictionary, b: Dictionary): return float(a["score"]) > float(b["score"]))
    if results.size() > limit:
        results = results.slice(0, limit)
    return results

func build_context(query: String, limit: int = 10) -> String:
    var hits := search(query, limit)
    if hits.is_empty():
        return ""
    var parts: Array[String] = []
    var i := 1
    for hit in hits:
        var kind := str(hit.get("source_kind", "other"))
        var kind_label := _kind_label(kind)
        var metadata: Dictionary = hit.get("metadata", {}) if hit.get("metadata", {}) is Dictionary else {}
        var meta_bits: Array[String] = []
        for key in ["decision_no", "decision_date", "topic", "official_url"]:
            var value := str(metadata.get(key, "")).strip_edges()
            if not value.is_empty():
                meta_bits.append(value)
        var meta_text := ""
        if not meta_bits.is_empty():
            meta_text = " · " + " · ".join(meta_bits)
        parts.append("[%s %d: %s · parça %d%s]\n%s" % [kind_label, i, str(hit["document_name"]), int(hit["chunk_index"]) + 1, meta_text, str(hit["text"])])
        i += 1
    return "İHALE / SÖZLEŞME BİLGİ TABANI — YALNIZCA YEREL ARŞİVDEKİ İLGİLİ PARÇALAR\n%s" % "\n\n".join(parts)

func archive_coverage_text() -> String:
    var stats := get_stats()
    if int(stats["documents"]) == 0:
        return "Yerel KİK/YFK arşivi henüz boş. Uzman genel mevzuat mantığıyla konuşabilir ancak karar numarası uydurmamalıdır."
    var updated := "bilinmiyor"
    if int(stats["updated_unix"]) > 0:
        updated = Time.get_datetime_string_from_unix_time(int(stats["updated_unix"]), true)
    return "Yerel arşiv: %d belge, %d parça · KİK %d · YFK %d · Mevzuat %d · Son yerel güncelleme: %s" % [
        int(stats["documents"]), int(stats["chunks"]), int(stats["kik"]), int(stats["yfk"]), int(stats["legislation"]), updated
    ]

func add_bundle_json(bundle_text: String, fallback_kind: String = "other") -> Dictionary:
    var parsed = JSON.parse_string(bundle_text)
    if not (parsed is Dictionary):
        return {"ok": false, "error": "JSON, ihale karar paketi biçiminde değil."}
    if str(parsed.get("type", "")) != "yerel_ai_procurement_bundle":
        return {"ok": false, "error": "JSON dosyasında yerel AI ihale karar paketi işareti bulunamadı."}
    var records = parsed.get("records", [])
    if not (records is Array) or records.is_empty():
        return {"ok": false, "error": "Karar paketinde kayıt bulunamadı."}
    var added := 0
    var failed := 0
    var chunks := 0
    for item in records:
        if not (item is Dictionary):
            failed += 1
            continue
        var text := str(item.get("text", ""))
        var name := str(item.get("name", "Karar / mevzuat belgesi"))
        var kind := str(item.get("source_kind", fallback_kind))
        var metadata = item.get("metadata", {})
        if not (metadata is Dictionary):
            metadata = {}
        var result := add_document(name, kind, str(item.get("source_path", "bundle")), "text/plain", text, metadata)
        if bool(result.get("ok", false)):
            added += 1
            chunks += int(result.get("chunks", 0))
        else:
            failed += 1
    return {"ok": added > 0, "added": added, "failed": failed, "chunks": chunks, "error": "Paket içinden belge eklenemedi." if added == 0 else ""}

func _extract_metadata(text: String, source_kind: String) -> Dictionary:
    var out := {}
    var patterns := [
        ["decision_no", "(?im)(?:Karar|Görüş)\\s*No\\s*[:：]\\s*([^\\n\\r]+)"],
        ["decision_date", "(?im)(?:Karar|Görüş)\\s*Tarihi\\s*[:：]\\s*([^\\n\\r]+)"]
    ]
    for item in patterns:
        var regex := RegEx.new()
        if regex.compile(str(item[1])) == OK:
            var match := regex.search(text)
            if match != null:
                out[str(item[0])] = match.get_string(1).strip_edges().left(120)
    if source_kind == "kik" and not out.has("decision_no"):
        var kik_regex := RegEx.new()
        if kik_regex.compile("\\b20[0-9]{2}/[A-ZÇĞİÖŞÜ]{1,4}\\.[IVX]+-[0-9]+\\b") == OK:
            var kik_match := kik_regex.search(text.to_upper())
            if kik_match != null:
                out["decision_no"] = kik_match.get_string(0)
    return out

func _kind_label(kind: String) -> String:
    match kind:
        "kik": return "KİK"
        "yfk": return "YFK"
        "legislation": return "MEVZUAT"
        _: return "KAYNAK"

func _score_chunk(raw_query: String, normalized_query: String, query_tokens: Array[String], chunk: String, doc_name: String, metadata: Dictionary) -> float:
    var hay := _normalize(chunk)
    var score := 0.0
    if normalized_query.length() >= 6 and normalized_query in hay:
        score += 10.0
    var name_norm := _normalize(doc_name)
    var meta_text := _normalize(" ".join([
        str(metadata.get("decision_no", "")),
        str(metadata.get("decision_date", "")),
        str(metadata.get("topic", ""))
    ]))
    for token in query_tokens:
        var count := hay.count(token)
        if count > 0:
            score += 1.2 + minf(4.0, float(count) * 0.4)
        if token in name_norm:
            score += 1.1
        if token in meta_text:
            score += 2.0
    # Karar numaraları ve tarih gibi ayırt edici ifadeler daha ağır basar.
    for fragment in raw_query.replace("/", " ").replace("-", " ").split(" ", false):
        var f := _normalize(fragment)
        if f.length() >= 4 and f.is_valid_int() and f in meta_text:
            score += 3.0
    return score

func _clean_text(text: String) -> String:
    var value := text.replace("\r\n", "\n").replace("\r", "\n")
    while "\n\n\n" in value:
        value = value.replace("\n\n\n", "\n\n")
    return value.strip_edges()

func _chunk_text(text: String, target_chars: int, overlap_chars: int) -> Array:
    var chunks: Array = []
    if text.length() <= target_chars:
        return [text]
    var start := 0
    while start < text.length():
        var finish := mini(text.length(), start + target_chars)
        if finish < text.length():
            var search_from := maxi(start + int(target_chars * 0.55), finish - 420)
            var best_break := -1
            for marker in ["\n\n", ".\n", ". ", "\n"]:
                var pos := text.rfind(marker, finish)
                if pos >= search_from:
                    best_break = maxi(best_break, pos + marker.length())
            if best_break > start:
                finish = best_break
        var piece := text.substr(start, finish - start).strip_edges()
        if piece.length() >= 40:
            chunks.append(piece)
        if finish >= text.length():
            break
        start = maxi(start + 1, finish - overlap_chars)
    return chunks

func _tokens(text: String) -> Array[String]:
    var normalized := _normalize(text)
    var stop := {
        "ve":true,"veya":true,"ile":true,"icin":true,"bir":true,"bu":true,"su":true,"da":true,"de":true,
        "mi":true,"mu":true,"mı":true,"mü":true,"ne":true,"nasil":true,"nedir":true,"olarak":true,"olan":true,
        "gibi":true,"daha":true,"cok":true,"ama":true,"ise":true,"ben":true,"sen":true,"biz":true,"bana":true,
        "karar":true,"karari":true,"gorus":true,"gore":true
    }
    var out: Array[String] = []
    for token in normalized.split(" ", false):
        if token.length() >= 3 and not stop.has(token) and not out.has(token):
            out.append(token)
    return out

func _normalize(text: String) -> String:
    var value := text.to_lower()
    var replacements := {"ç":"c", "ğ":"g", "ı":"i", "ö":"o", "ş":"s", "ü":"u", "â":"a", "î":"i", "û":"u"}
    for key in replacements.keys():
        value = value.replace(key, replacements[key])
    var cleaned := ""
    for c in value:
        if c.is_valid_int() or c.to_lower() != c.to_upper() or c in ["/", "-", "."]:
            cleaned += c
        else:
            cleaned += " "
    while "  " in cleaned:
        cleaned = cleaned.replace("  ", " ")
    return cleaned.strip_edges()

func _make_id(seed: String) -> String:
    var safe := _normalize(seed).replace(" ", "-").replace("/", "-").replace(".", "-")
    if safe.is_empty():
        safe = "belge"
    return "%s-%d" % [safe.left(50), int(Time.get_unix_time_from_system())]
