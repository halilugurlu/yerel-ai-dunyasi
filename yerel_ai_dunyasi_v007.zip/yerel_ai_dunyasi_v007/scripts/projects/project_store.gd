extends Node

signal projects_changed
signal active_project_changed(project_id: String)
signal document_added(project_id: String, document_id: String)

const ROOT_DIR := "user://projects"
const INDEX_PATH := ROOT_DIR + "/index.json"
const SCHEMA_VERSION := 1

var _index: Dictionary = {
    "schema_version": SCHEMA_VERSION,
    "active_project_id": "",
    "projects": []
}

func _ready() -> void:
    _ensure_root()
    _load_index()
    if get_projects().is_empty():
        create_project("İlk Projem")

func _ensure_root() -> void:
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(ROOT_DIR))

func _load_index() -> void:
    if not FileAccess.file_exists(INDEX_PATH):
        return
    var file := FileAccess.open(INDEX_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        _index = parsed
        if not _index.has("projects"):
            _index["projects"] = []
        if not _index.has("active_project_id"):
            _index["active_project_id"] = ""

func _save_index() -> void:
    _ensure_root()
    var file := FileAccess.open(INDEX_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(_index, "  "))

func get_projects() -> Array:
    return _index.get("projects", []).duplicate(true)

func get_active_project_id() -> String:
    return str(_index.get("active_project_id", ""))

func get_active_project() -> Dictionary:
    return get_project(get_active_project_id())

func get_project(project_id: String) -> Dictionary:
    for item in _index.get("projects", []):
        if str(item.get("id", "")) == project_id:
            var full := item.duplicate(true)
            full["documents"] = _load_project_documents(project_id)
            return full
    return {}

func create_project(project_name: String) -> String:
    var clean_name := project_name.strip_edges()
    if clean_name.is_empty():
        clean_name = "Yeni Proje"
    var project_id := _make_id(clean_name)
    var project_dir := _project_dir(project_id)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(project_dir))
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(project_dir + "/documents"))
    var record := {
        "id": project_id,
        "name": clean_name,
        "created_unix": Time.get_unix_time_from_system(),
        "updated_unix": Time.get_unix_time_from_system()
    }
    _index["projects"].append(record)
    _index["active_project_id"] = project_id
    _save_index()
    _save_project_documents(project_id, [])
    projects_changed.emit()
    active_project_changed.emit(project_id)
    return project_id

func set_active_project(project_id: String) -> bool:
    for item in _index.get("projects", []):
        if str(item.get("id", "")) == project_id:
            _index["active_project_id"] = project_id
            _save_index()
            active_project_changed.emit(project_id)
            return true
    return false

func add_document(project_id: String, display_name: String, source_path: String, mime_type: String, text: String) -> Dictionary:
    if project_id.is_empty():
        return {"ok": false, "error": "Aktif proje bulunamadı."}
    var cleaned := _clean_text(text)
    if cleaned.length() < 20:
        return {"ok": false, "error": "Belgede kullanılabilir metin bulunamadı."}

    var documents := _load_project_documents(project_id)
    var document_id := _make_id(display_name)
    var chunks := _chunk_text(cleaned)
    var record := {
        "id": document_id,
        "name": display_name,
        "source_path": source_path,
        "mime_type": mime_type,
        "imported_unix": Time.get_unix_time_from_system(),
        "char_count": cleaned.length(),
        "chunk_count": chunks.size(),
        "chunks": chunks
    }
    documents.append(record)
    _save_project_documents(project_id, documents)
    _touch_project(project_id)
    document_added.emit(project_id, document_id)
    projects_changed.emit()
    return {"ok": true, "document_id": document_id, "chunks": chunks.size()}

func get_documents(project_id: String = "") -> Array:
    var pid := project_id if not project_id.is_empty() else get_active_project_id()
    return _load_project_documents(pid)

func search(query: String, limit: int = 6, project_id: String = "") -> Array:
    var pid := project_id if not project_id.is_empty() else get_active_project_id()
    if pid.is_empty():
        return []
    var query_tokens := _tokens(query)
    if query_tokens.is_empty():
        return []
    var results: Array = []
    for doc in _load_project_documents(pid):
        var doc_name := str(doc.get("name", "Belge"))
        var chunk_index := 0
        for chunk in doc.get("chunks", []):
            var chunk_text := str(chunk)
            var score := _score_chunk(query, query_tokens, chunk_text, doc_name)
            if score > 0.0:
                results.append({
                    "score": score,
                    "document_id": str(doc.get("id", "")),
                    "document_name": doc_name,
                    "chunk_index": chunk_index,
                    "text": chunk_text
                })
            chunk_index += 1
    results.sort_custom(func(a: Dictionary, b: Dictionary): return float(a["score"]) > float(b["score"]))
    if results.size() > limit:
        results = results.slice(0, limit)
    return results

func build_rag_context(query: String, limit: int = 6, project_id: String = "") -> String:
    var hits := search(query, limit, project_id)
    if hits.is_empty():
        return ""
    var parts: Array[String] = []
    var i := 1
    for hit in hits:
        parts.append("[Kaynak %d: %s · parça %d]\n%s" % [i, str(hit["document_name"]), int(hit["chunk_index"]) + 1, str(hit["text"])])
        i += 1
    return "PROJE BİLGİ TABANI — YALNIZCA İLGİLİ PARÇALAR\n%s" % "\n\n".join(parts)

func _project_dir(project_id: String) -> String:
    return "%s/%s" % [ROOT_DIR, project_id]

func _documents_path(project_id: String) -> String:
    return "%s/documents.json" % _project_dir(project_id)

func _load_project_documents(project_id: String) -> Array:
    if project_id.is_empty():
        return []
    var path := _documents_path(project_id)
    if not FileAccess.file_exists(path):
        return []
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return []
    var parsed = JSON.parse_string(file.get_as_text())
    return parsed if parsed is Array else []

func _save_project_documents(project_id: String, documents: Array) -> void:
    var dir := _project_dir(project_id)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(dir))
    var file := FileAccess.open(_documents_path(project_id), FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(documents, "  "))

func _touch_project(project_id: String) -> void:
    for item in _index.get("projects", []):
        if str(item.get("id", "")) == project_id:
            item["updated_unix"] = Time.get_unix_time_from_system()
            break
    _save_index()

func _make_id(seed: String) -> String:
    var safe := seed.to_lower().strip_edges()
    for ch in ["ç", "ğ", "ı", "ö", "ş", "ü"]:
        var replacements := {"ç":"c", "ğ":"g", "ı":"i", "ö":"o", "ş":"s", "ü":"u"}
        safe = safe.replace(ch, replacements[ch])
    safe = safe.replace(" ", "-")
    var filtered := ""
    for c in safe:
        if c.is_valid_identifier() or c == "-" or c.is_valid_int():
            filtered += c
    if filtered.is_empty():
        filtered = "proje"
    return "%s-%d" % [filtered.left(42), int(Time.get_unix_time_from_system())]

func _clean_text(text: String) -> String:
    var value := text.replace("\r\n", "\n").replace("\r", "\n")
    while "\n\n\n" in value:
        value = value.replace("\n\n\n", "\n\n")
    return value.strip_edges()

func _chunk_text(text: String, target_chars: int = 1500, overlap_chars: int = 220) -> Array:
    var chunks: Array = []
    if text.length() <= target_chars:
        return [text]
    var start := 0
    while start < text.length():
        var finish := mini(text.length(), start + target_chars)
        if finish < text.length():
            var search_from := maxi(start + int(target_chars * 0.55), finish - 350)
            var best_break := -1
            for marker in ["\n\n", ".\n", ". ", "\n"]:
                var pos := text.rfind(marker, finish)
                if pos >= search_from:
                    best_break = maxi(best_break, pos + marker.length())
            if best_break > start:
                finish = best_break
        var piece := text.substr(start, finish - start).strip_edges()
        if piece.length() >= 40:
            chunks.append(piece)
        if finish >= text.length():
            break
        start = maxi(start + 1, finish - overlap_chars)
    return chunks

func _score_chunk(raw_query: String, query_tokens: Array[String], chunk: String, doc_name: String) -> float:
    var hay := _normalize(chunk)
    var score := 0.0
    var normalized_query := _normalize(raw_query)
    if normalized_query.length() >= 8 and normalized_query in hay:
        score += 8.0
    for token in query_tokens:
        var count := hay.count(token)
        if count > 0:
            score += 1.0 + minf(3.0, float(count) * 0.35)
        if token in _normalize(doc_name):
            score += 0.8
    return score

func _tokens(text: String) -> Array[String]:
    var normalized := _normalize(text)
    var stop := {
        "ve":true,"veya":true,"ile":true,"icin":true,"bir":true,"bu":true,"su":true,"da":true,"de":true,
        "mi":true,"mu":true,"mı":true,"mü":true,"ne":true,"nasil":true,"nedir":true,"olarak":true,"olan":true,
        "gibi":true,"daha":true,"cok":true,"ama":true,"ise":true,"ben":true,"sen":true,"biz":true,"bana":true
    }
    var out: Array[String] = []
    for token in normalized.split(" ", false):
        if token.length() >= 3 and not stop.has(token) and not out.has(token):
            out.append(token)
    return out

func _normalize(text: String) -> String:
    var value := text.to_lower()
    var replacements := {
        "ç":"c", "ğ":"g", "ı":"i", "ö":"o", "ş":"s", "ü":"u",
        "â":"a", "î":"i", "û":"u"
    }
    for key in replacements.keys():
        value = value.replace(key, replacements[key])
    var cleaned := ""
    for c in value:
        if c.is_valid_int() or c.to_lower() != c.to_upper():
            cleaned += c
        else:
            cleaned += " "
    while "  " in cleaned:
        cleaned = cleaned.replace("  ", " ")
    return cleaned.strip_edges()
