extends Node

const PlayerClass = preload("res://scripts/world/player.gd")
const AgentClass = preload("res://scripts/world/agent.gd")

var player: CharacterBody3D
var camera: Camera3D
var world_root: Node3D
var agents: Array[Node3D] = []
var interactables: Array[Dictionary] = []
var nearest_target: Dictionary = {}
var chat_agent_id := "core"
var chat_panel: PanelContainer
var chat_title: Label
var transcript: RichTextLabel
var input_line: LineEdit
var send_button: Button
var hint_label: Label
var inference_status_label: Label
var touch_vector := Vector2.ZERO

var model_panel: PanelContainer
var model_status_label: Label
var model_path_label: Label
var model_diagnostics_label: Label
var license_status_label: Label
var license_name_edit: LineEdit
var license_source_edit: LineEdit
var license_reviewed_check: CheckBox
var commercial_allowed_check: CheckBox
var auto_load_check: CheckBox
var self_test_button: Button
var model_file_dialog: FileDialog
var active_meeting_id := -1

var project_panel: PanelContainer
var project_selector: OptionButton
var new_project_edit: LineEdit
var project_status_label: Label
var project_documents_label: RichTextLabel
var document_file_dialog: FileDialog

var engineering_panel: PanelContainer
var engineering_selector: OptionButton
var engineering_field_rows: Array[Control] = []
var engineering_field_labels: Array[Label] = []
var engineering_field_edits: Array[LineEdit] = []
var engineering_output: RichTextLabel
var engineering_presets: Array[Dictionary] = []

var procurement_panel: PanelContainer
var procurement_status_label: Label
var procurement_documents_label: RichTextLabel
var procurement_source_selector: OptionButton
var procurement_file_dialog: FileDialog

func _ready() -> void:
    AgentRouter.reply_completed.connect(_on_reply_completed)
    AgentRouter.reply_failed.connect(_on_reply_failed)
    AgentRouter.meeting_progress.connect(_on_meeting_progress)
    AgentRouter.meeting_completed.connect(_on_meeting_completed)
    InferenceService.state_changed.connect(_on_inference_state_changed)
    InferenceService.model_load_finished.connect(_on_model_load_finished)
    InferenceService.model_imported.connect(_on_native_model_imported)
    InferenceService.model_import_progress.connect(_on_native_model_import_progress)
    InferenceService.model_import_failed.connect(_on_native_model_import_failed)
    InferenceService.self_test_finished.connect(_on_self_test_finished)
    ModelManager.settings_changed.connect(_refresh_model_panel)
    ProjectStore.projects_changed.connect(_refresh_project_panel)
    ProjectStore.active_project_changed.connect(_on_active_project_changed)
    DocumentImporter.import_started.connect(_on_document_import_started)
    DocumentImporter.import_finished.connect(_on_document_import_finished)
    DocumentImporter.procurement_import_started.connect(_on_procurement_import_started)
    DocumentImporter.procurement_import_finished.connect(_on_procurement_import_finished)
    DocumentImporter.native_picker_state.connect(_on_document_picker_state)
    ProcurementKnowledge.corpus_changed.connect(_refresh_procurement_panel)
    _build_world()
    _build_ui()
    _refresh_model_panel()
    _refresh_project_panel()
    _refresh_procurement_panel()
    _on_inference_state_changed(InferenceService.get_state())
    call_deferred("_try_auto_load_selected_model")

func _process(_delta: float) -> void:
    if player != null and camera != null:
        var desired := player.global_position + Vector3(7.5, 8.5, 10.0)
        camera.global_position = camera.global_position.lerp(desired, 0.08)
        camera.look_at(player.global_position + Vector3(0, 1.1, 0), Vector3.UP)
        _update_nearest_target()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_E:
        _interact()

func _build_world() -> void:
    world_root = Node3D.new()
    world_root.name = "World"
    add_child(world_root)

    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color("#7f9fb3")
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color("#ffffff")
    environment.ambient_light_energy = 0.75
    env.environment = environment
    world_root.add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    world_root.add_child(sun)

    _box("MainFloor", Vector3(32, 0.25, 25), Vector3(0, -0.125, 0), Color("#d8d1c5"), true)
    _box("OfficeWing", Vector3(15, 0.12, 9), Vector3(-7.5, 0.02, -5.2), Color("#ece7df"), false)
    _box("Garden", Vector3(13, 0.10, 10), Vector3(8.5, 0.01, 5.8), Color("#66885c"), false)
    _box("Parking", Vector3(10, 0.10, 6), Vector3(-9.5, 0.01, 8.1), Color("#55585d"), false)

    _box("BackWall", Vector3(30, 3.2, 0.25), Vector3(0, 1.6, -12), Color("#f2f0eb"), true)
    _box("LeftWall", Vector3(0.25, 3.2, 24), Vector3(-15, 1.6, 0), Color("#f2f0eb"), true)
    _box("RightWall", Vector3(0.25, 3.2, 24), Vector3(15, 1.6, 0), Color("#f2f0eb"), true)

    _box("Desk", Vector3(3.0, 0.75, 1.2), Vector3(0, 0.38, -8.6), Color("#5a4637"), true)
    _box("Computer", Vector3(1.25, 0.85, 0.12), Vector3(0, 1.25, -8.95), Color("#20252b"), false)
    interactables.append({"type":"core", "id":"core", "name":"Ofis Bilgisayarı — Genel Yerel Zekâ", "position":Vector3(0,0,-8.3)})

    _box("MeetingTable", Vector3(5.2, 0.65, 2.0), Vector3(6.8, 0.34, -5.5), Color("#6a5140"), true)
    interactables.append({"type":"meeting", "id":"coordinator", "name":"Proje Toplantı Masası", "position":Vector3(6.8,0,-4.0)})

    _box("EngineeringBench", Vector3(3.0, 0.72, 1.25), Vector3(11.0, 0.37, -5.5), Color("#3f556b"), true)
    _box("EngineeringScreen", Vector3(1.25, 0.80, 0.10), Vector3(11.0, 1.20, -5.92), Color("#18222c"), false)
    interactables.append({"type":"engineering", "id":"civil", "name":"Mühendislik Hesap Masası", "position":Vector3(11.0,0,-4.4)})

    _cylinder("CampFire", 0.55, 0.18, Vector3(9, 0.10, 6.2), Color("#bd6b35"))
    for p in [Vector3(6.5,0,4.0), Vector3(11.0,0,3.8), Vector3(12.0,0,8.5), Vector3(6.0,0,8.8)]:
        _tree(p)

    _box("CarBody", Vector3(3.2, 0.75, 1.65), Vector3(-10, 0.52, 8.2), Color("#263849"), false)
    _box("CarCabin", Vector3(1.65, 0.65, 1.45), Vector3(-9.8, 1.10, 8.2), Color("#567087"), false)
    interactables.append({"type":"car", "id":"core", "name":"Araç — sürüş prototipi", "position":Vector3(-10,0,8.2)})

    _spawn_agents()
    _spawn_player()

func _spawn_player() -> void:
    player = PlayerClass.new()
    player.name = "Player"
    player.position = Vector3(0, 0.05, 2.5)

    var shape := CollisionShape3D.new()
    var capsule_shape := CapsuleShape3D.new()
    capsule_shape.radius = 0.42
    capsule_shape.height = 1.7
    shape.shape = capsule_shape
    shape.position.y = 0.85
    player.add_child(shape)

    var mesh := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.7
    mesh.mesh = capsule
    mesh.position.y = 0.85
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("#e8a34a")
    mesh.material_override = mat
    player.add_child(mesh)
    world_root.add_child(player)

    camera = Camera3D.new()
    camera.name = "Camera"
    camera.current = true
    camera.position = player.position + Vector3(7.5, 8.5, 10)
    world_root.add_child(camera)

func _spawn_agents() -> void:
    var setup := [
        ["coordinator", Vector3(-10.5,0,-7.0), Color("#805ad5")],
        ["architect", Vector3(-7.0,0,-7.0), Color("#d56565")],
        ["civil", Vector3(-3.5,0,-7.0), Color("#386fa4")],
        ["mechanical", Vector3(-10.5,0,-3.2), Color("#4f9c6b")],
        ["electrical", Vector3(-7.0,0,-3.2), Color("#e0ad3c")],
        ["interior", Vector3(-3.5,0,-3.2), Color("#c86b98")],
        ["landscape", Vector3(8.0,0,2.7), Color("#5e9f56")],
        ["regulations", Vector3(11.0,0,2.7), Color("#755548")],
        ["procurement", Vector3(11.0,0,-0.4), Color("#2f6b63")]
    ]
    for item in setup:
        var id: String = item[0]
        var profile: Dictionary = AgentRouter.get_profile(id)
        var agent = AgentClass.new()
        agent.setup(id, profile["name"], profile["role"], item[2])
        agent.position = item[1]
        world_root.add_child(agent)
        agents.append(agent)
        interactables.append({"type":"agent", "id":id, "name":profile["name"], "position":item[1]})

func _box(node_name: String, size: Vector3, pos: Vector3, color: Color, collision: bool) -> Node3D:
    var root: Node3D
    if collision:
        var body := StaticBody3D.new()
        root = body
        var cs := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        cs.shape = shape
        body.add_child(cs)
    else:
        root = Node3D.new()
    root.name = node_name
    root.position = pos
    var mi := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mi.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.85
    mi.material_override = mat
    root.add_child(mi)
    world_root.add_child(root)
    return root

func _cylinder(node_name: String, radius: float, height: float, pos: Vector3, color: Color) -> void:
    var root := Node3D.new()
    root.name = node_name
    root.position = pos
    var mi := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mi.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mi.material_override = mat
    root.add_child(mi)
    world_root.add_child(root)

func _tree(pos: Vector3) -> void:
    _cylinder("TreeTrunk", 0.15, 1.5, pos + Vector3(0,0.75,0), Color("#6b4e35"))
    var crown := Node3D.new()
    crown.position = pos + Vector3(0,1.9,0)
    var mi := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.75
    sphere.height = 1.5
    mi.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("#476f43")
    mi.material_override = mat
    crown.add_child(mi)
    world_root.add_child(crown)

func _build_ui() -> void:
    var canvas := CanvasLayer.new()
    add_child(canvas)

    var title := Label.new()
    title.text = "YEREL AI DÜNYASI  ·  v0.0.8"
    title.position = Vector2(22, 18)
    title.add_theme_font_size_override("font_size", 22)
    canvas.add_child(title)

    hint_label = Label.new()
    hint_label.text = "Uzmanlara yaklaş · E/KONUŞ ile etkileş"
    hint_label.position = Vector2(22, 52)
    hint_label.add_theme_font_size_override("font_size", 17)
    canvas.add_child(hint_label)

    inference_status_label = Label.new()
    inference_status_label.position = Vector2(930, 20)
    inference_status_label.size = Vector2(320, 30)
    inference_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    inference_status_label.add_theme_font_size_override("font_size", 16)
    canvas.add_child(inference_status_label)

    var left := _ui_button(canvas, "◀", Vector2(34, 575), Vector2(70, 70))
    var right := _ui_button(canvas, "▶", Vector2(184, 575), Vector2(70, 70))
    var up := _ui_button(canvas, "▲", Vector2(109, 500), Vector2(70, 70))
    var down := _ui_button(canvas, "▼", Vector2(109, 650), Vector2(70, 55))
    left.button_down.connect(func(): touch_vector.x = -1; _sync_touch())
    left.button_up.connect(func(): touch_vector.x = 0; _sync_touch())
    right.button_down.connect(func(): touch_vector.x = 1; _sync_touch())
    right.button_up.connect(func(): touch_vector.x = 0; _sync_touch())
    up.button_down.connect(func(): touch_vector.y = 1; _sync_touch())
    up.button_up.connect(func(): touch_vector.y = 0; _sync_touch())
    down.button_down.connect(func(): touch_vector.y = -1; _sync_touch())
    down.button_up.connect(func(): touch_vector.y = 0; _sync_touch())

    var talk := _ui_button(canvas, "KONUŞ", Vector2(1090, 610), Vector2(155, 62))
    talk.pressed.connect(_interact)
    var core := _ui_button(canvas, "AI ÇEKİRDEĞİ", Vector2(1070, 535), Vector2(175, 58))
    core.pressed.connect(func(): _open_chat("core"))
    var model_button := _ui_button(canvas, "MODEL", Vector2(1070, 470), Vector2(175, 52))
    model_button.pressed.connect(_toggle_model_panel)
    var project_button := _ui_button(canvas, "PROJE", Vector2(1070, 410), Vector2(175, 52))
    project_button.pressed.connect(_toggle_project_panel)
    var engineering_button := _ui_button(canvas, "HESAP", Vector2(1070, 350), Vector2(175, 52))
    engineering_button.pressed.connect(_toggle_engineering_panel)
    var procurement_button := _ui_button(canvas, "İHALE", Vector2(1070, 290), Vector2(175, 52))
    procurement_button.pressed.connect(_toggle_procurement_panel)

    _build_chat_panel(canvas)
    _build_model_panel(canvas)
    _build_project_panel(canvas)
    _build_engineering_panel(canvas)
    _build_procurement_panel(canvas)

func _build_chat_panel(canvas: CanvasLayer) -> void:
    chat_panel = PanelContainer.new()
    chat_panel.position = Vector2(690, 70)
    chat_panel.size = Vector2(565, 390)
    chat_panel.visible = false
    canvas.add_child(chat_panel)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    chat_panel.add_child(vb)

    var header := HBoxContainer.new()
    vb.add_child(header)
    chat_title = Label.new()
    chat_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    chat_title.add_theme_font_size_override("font_size", 20)
    header.add_child(chat_title)
    var close := Button.new()
    close.text = "✕"
    close.pressed.connect(func(): chat_panel.visible = false)
    header.add_child(close)

    transcript = RichTextLabel.new()
    transcript.bbcode_enabled = true
    transcript.fit_content = false
    transcript.custom_minimum_size = Vector2(530, 245)
    transcript.scroll_active = true
    vb.add_child(transcript)

    var input_row := HBoxContainer.new()
    vb.add_child(input_row)
    input_line = LineEdit.new()
    input_line.placeholder_text = "Mesajını yaz…"
    input_line.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    input_line.text_submitted.connect(func(_text): _send_chat())
    input_row.add_child(input_line)
    send_button = Button.new()
    send_button.text = "Gönder"
    send_button.pressed.connect(_send_chat)
    input_row.add_child(send_button)

    var meeting := Button.new()
    meeting.text = "Uzman Toplantısı Başlat"
    meeting.pressed.connect(_meeting_from_chat)
    vb.add_child(meeting)

func _build_model_panel(canvas: CanvasLayer) -> void:
    model_panel = PanelContainer.new()
    model_panel.position = Vector2(315, 78)
    model_panel.size = Vector2(660, 635)
    model_panel.visible = false
    canvas.add_child(model_panel)

    var scroll := ScrollContainer.new()
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    model_panel.add_child(scroll)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 9)
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(vb)

    var header := HBoxContainer.new()
    vb.add_child(header)
    var heading := Label.new()
    heading.text = "YEREL MODEL MERKEZİ"
    heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    heading.add_theme_font_size_override("font_size", 22)
    header.add_child(heading)
    var close := Button.new()
    close.text = "✕"
    close.pressed.connect(func(): model_panel.visible = false)
    header.add_child(close)

    model_status_label = Label.new()
    model_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(model_status_label)

    model_path_label = Label.new()
    model_path_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(model_path_label)

    model_diagnostics_label = Label.new()
    model_diagnostics_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    model_diagnostics_label.text = "Cihaz tanısı henüz çalıştırılmadı."
    vb.add_child(model_diagnostics_label)

    var diagnostics_button := Button.new()
    diagnostics_button.text = "CİHAZI VE MODELİ KONTROL ET"
    diagnostics_button.pressed.connect(_run_model_diagnostics)
    vb.add_child(diagnostics_button)

    var buttons := HBoxContainer.new()
    vb.add_child(buttons)
    var select_button := Button.new()
    select_button.text = "GGUF SEÇ"
    select_button.pressed.connect(_select_model)
    buttons.add_child(select_button)
    var load_button := Button.new()
    load_button.text = "MODELİ YÜKLE"
    load_button.pressed.connect(_load_selected_model)
    buttons.add_child(load_button)
    var unload_button := Button.new()
    unload_button.text = "BELLEKTEN ÇIKAR"
    unload_button.pressed.connect(func(): InferenceService.unload_model())
    buttons.add_child(unload_button)

    auto_load_check = CheckBox.new()
    auto_load_check.text = "Uygulama açılınca seçili modeli otomatik yükle"
    auto_load_check.toggled.connect(func(enabled: bool): ModelManager.set_auto_load_on_startup(enabled))
    vb.add_child(auto_load_check)

    self_test_button = Button.new()
    self_test_button.text = "YEREL AI TÜRKÇE TESTİNİ ÇALIŞTIR"
    self_test_button.pressed.connect(_run_local_ai_self_test)
    vb.add_child(self_test_button)

    var separator := HSeparator.new()
    vb.add_child(separator)

    var license_heading := Label.new()
    license_heading.text = "Model lisansı / ticari kullanım kaydı"
    license_heading.add_theme_font_size_override("font_size", 18)
    vb.add_child(license_heading)

    license_status_label = Label.new()
    vb.add_child(license_status_label)

    license_name_edit = LineEdit.new()
    license_name_edit.placeholder_text = "Lisans adı (örn. Apache-2.0, modelin kendi lisansı...)"
    vb.add_child(license_name_edit)

    license_source_edit = LineEdit.new()
    license_source_edit.placeholder_text = "Lisans kaynağı / model kartı referansı"
    vb.add_child(license_source_edit)

    license_reviewed_check = CheckBox.new()
    license_reviewed_check.text = "Lisans koşullarını doğruladım"
    vb.add_child(license_reviewed_check)

    commercial_allowed_check = CheckBox.new()
    commercial_allowed_check.text = "Ticari kullanım / yeniden dağıtım açısından uygunluğu doğrulandı"
    vb.add_child(commercial_allowed_check)

    var save_license := Button.new()
    save_license.text = "LİSANS KAYDINI KAYDET"
    save_license.pressed.connect(_save_license_record)
    vb.add_child(save_license)

    var info := Label.new()
    info.text = "Not: Model dosyasını yüklemek teknik olarak mümkün olsa bile, ürünün dağıtım güvenliği ayrı tutulur. Lisans doğrulanmadan model 'ticari dağıtıma güvenli' sayılmaz."
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(info)

    model_file_dialog = FileDialog.new()
    model_file_dialog.title = "GGUF model seç"
    model_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
    model_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
    model_file_dialog.filters = PackedStringArray(["*.gguf ; GGUF model"])
    model_file_dialog.file_selected.connect(_on_model_selected)
    canvas.add_child(model_file_dialog)

func _build_project_panel(canvas: CanvasLayer) -> void:
    project_panel = PanelContainer.new()
    project_panel.position = Vector2(280, 70)
    project_panel.size = Vector2(690, 575)
    project_panel.visible = false
    canvas.add_child(project_panel)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    project_panel.add_child(vb)

    var header := HBoxContainer.new()
    vb.add_child(header)
    var heading := Label.new()
    heading.text = "PROJE ÇALIŞMA ALANI"
    heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    heading.add_theme_font_size_override("font_size", 22)
    header.add_child(heading)
    var close := Button.new()
    close.text = "✕"
    close.pressed.connect(func(): project_panel.visible = false)
    header.add_child(close)

    var language_info := Label.new()
    language_info.text = "Tüm ajanlar ve proje çıktıları varsayılan olarak Türkçedir."
    vb.add_child(language_info)

    project_selector = OptionButton.new()
    project_selector.item_selected.connect(_on_project_selected)
    vb.add_child(project_selector)

    var create_row := HBoxContainer.new()
    vb.add_child(create_row)
    new_project_edit = LineEdit.new()
    new_project_edit.placeholder_text = "Yeni proje adı"
    new_project_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    create_row.add_child(new_project_edit)
    var create_button := Button.new()
    create_button.text = "PROJE OLUŞTUR"
    create_button.pressed.connect(_create_project_from_ui)
    create_row.add_child(create_button)

    var doc_row := HBoxContainer.new()
    vb.add_child(doc_row)
    var import_button := Button.new()
    import_button.text = "BELGE EKLE"
    import_button.pressed.connect(_select_document)
    doc_row.add_child(import_button)
    var info := Label.new()
    info.text = "Android: PDF/TXT/MD/CSV/JSON · cihaz içinde işlenir"
    info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    doc_row.add_child(info)

    project_status_label = Label.new()
    project_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(project_status_label)

    var docs_heading := Label.new()
    docs_heading.text = "Aktif proje belgeleri"
    docs_heading.add_theme_font_size_override("font_size", 18)
    vb.add_child(docs_heading)

    project_documents_label = RichTextLabel.new()
    project_documents_label.bbcode_enabled = true
    project_documents_label.custom_minimum_size = Vector2(650, 285)
    project_documents_label.fit_content = false
    vb.add_child(project_documents_label)

    var rag_info := Label.new()
    rag_info.text = "Ajanlar soruna uygun belge parçalarını yerel olarak bulur. Kaynağa dayanan yanıtlarında [Kaynak N: ...] etiketi kullanmaları istenir."
    rag_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(rag_info)

    document_file_dialog = FileDialog.new()
    document_file_dialog.title = "Projeye belge ekle"
    document_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
    document_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
    document_file_dialog.filters = PackedStringArray([
        "*.txt ; Metin dosyası",
        "*.md ; Markdown",
        "*.csv ; CSV",
        "*.json ; JSON",
        "*.pdf ; PDF (Android yerel çıkarım)"
    ])
    document_file_dialog.file_selected.connect(_on_document_selected)
    canvas.add_child(document_file_dialog)

func _build_procurement_panel(canvas: CanvasLayer) -> void:
    procurement_panel = PanelContainer.new()
    procurement_panel.position = Vector2(260, 62)
    procurement_panel.size = Vector2(720, 610)
    procurement_panel.visible = false
    canvas.add_child(procurement_panel)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    procurement_panel.add_child(vb)

    var header := HBoxContainer.new()
    vb.add_child(header)
    var heading := Label.new()
    heading.text = "İHALE VE SÖZLEŞME BİLGİ MERKEZİ"
    heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    heading.add_theme_font_size_override("font_size", 22)
    header.add_child(heading)
    var close := Button.new()
    close.text = "✕"
    close.pressed.connect(func(): procurement_panel.visible = false)
    header.add_child(close)

    var info := Label.new()
    info.text = "KİK kararları, YFK karar/görüşleri ve ihale mevzuatı ayrı kaynak türleri olarak yerel arşivde tutulur. Uzman karar numarası uydurmaz."
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(info)

    procurement_source_selector = OptionButton.new()
    procurement_source_selector.add_item("KİK kararı / EKAP")
    procurement_source_selector.set_item_metadata(0, "kik")
    procurement_source_selector.add_item("Yüksek Fen Kurulu kararı / görüşü")
    procurement_source_selector.set_item_metadata(1, "yfk")
    procurement_source_selector.add_item("İhale / sözleşme mevzuatı")
    procurement_source_selector.set_item_metadata(2, "legislation")
    procurement_source_selector.add_item("Diğer resmi kaynak")
    procurement_source_selector.set_item_metadata(3, "other")
    vb.add_child(procurement_source_selector)

    var row := HBoxContainer.new()
    vb.add_child(row)
    var import_button := Button.new()
    import_button.text = "ARŞİVE BELGE EKLE"
    import_button.pressed.connect(_select_procurement_document)
    row.add_child(import_button)
    var chat_button := Button.new()
    chat_button.text = "UZMANLA KONUŞ"
    chat_button.pressed.connect(func(): _open_chat("procurement"))
    row.add_child(chat_button)

    var official_row := HBoxContainer.new()
    vb.add_child(official_row)
    var kik_button := Button.new()
    kik_button.text = "KİK / EKAP RESMİ KARAR ARAMA"
    kik_button.pressed.connect(func(): OS.shell_open("https://ekap.kik.gov.tr/EKAP/Vatandas/KurulKararSorgu.aspx"))
    official_row.add_child(kik_button)
    var yfk_button := Button.new()
    yfk_button.text = "YFK RESMİ SAYFA"
    yfk_button.pressed.connect(func(): OS.shell_open("https://yfk.csb.gov.tr/"))
    official_row.add_child(yfk_button)

    procurement_status_label = Label.new()
    procurement_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(procurement_status_label)

    var list_heading := Label.new()
    list_heading.text = "Yerel ihale / sözleşme arşivi"
    list_heading.add_theme_font_size_override("font_size", 18)
    vb.add_child(list_heading)

    procurement_documents_label = RichTextLabel.new()
    procurement_documents_label.bbcode_enabled = true
    procurement_documents_label.custom_minimum_size = Vector2(680, 285)
    procurement_documents_label.fit_content = false
    vb.add_child(procurement_documents_label)

    var warning := Label.new()
    warning.text = "'Tüm kararlar' garantisi ancak resmi kaynaklardan karar korpusu gerçekten içe aktarılıp güncellendiğinde verilebilir. Arşiv dışındaki kararları sistem var/yok diye tahmin etmez."
    warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(warning)

    procurement_file_dialog = FileDialog.new()
    procurement_file_dialog.title = "İhale / sözleşme arşivine belge ekle"
    procurement_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
    procurement_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
    procurement_file_dialog.filters = PackedStringArray([
        "*.txt ; Metin dosyası",
        "*.md ; Markdown",
        "*.csv ; CSV",
        "*.json ; JSON",
        "*.pdf ; PDF (Android yerel çıkarım)"
    ])
    procurement_file_dialog.file_selected.connect(_on_procurement_document_selected)
    canvas.add_child(procurement_file_dialog)

func _build_engineering_panel(canvas: CanvasLayer) -> void:
    engineering_panel = PanelContainer.new()
    engineering_panel.position = Vector2(300, 70)
    engineering_panel.size = Vector2(660, 585)
    engineering_panel.visible = false
    canvas.add_child(engineering_panel)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    engineering_panel.add_child(vb)

    var header := HBoxContainer.new()
    vb.add_child(header)
    var heading := Label.new()
    heading.text = "MÜHENDİSLİK HESAP MASASI"
    heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    heading.add_theme_font_size_override("font_size", 22)
    header.add_child(heading)
    var close := Button.new()
    close.text = "✕"
    close.pressed.connect(func(): engineering_panel.visible = false)
    header.add_child(close)

    var info := Label.new()
    info.text = "Deterministik temel hesaplar · sonuçlar ajanların dil modeli tahmininden bağımsızdır."
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(info)

    engineering_selector = OptionButton.new()
    engineering_presets = EngineeringTools.get_manual_presets()
    for preset in engineering_presets:
        engineering_selector.add_item(str(preset.get("name", "Hesap")))
        engineering_selector.set_item_metadata(engineering_selector.item_count - 1, str(preset.get("id", "")))
    engineering_selector.item_selected.connect(_on_engineering_tool_selected)
    vb.add_child(engineering_selector)

    for i in range(4):
        var row := HBoxContainer.new()
        row.visible = false
        vb.add_child(row)
        var label := Label.new()
        label.custom_minimum_size = Vector2(250, 34)
        row.add_child(label)
        var edit := LineEdit.new()
        edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        row.add_child(edit)
        engineering_field_rows.append(row)
        engineering_field_labels.append(label)
        engineering_field_edits.append(edit)

    var calculate := Button.new()
    calculate.text = "HESAPLA"
    calculate.pressed.connect(_run_manual_engineering_tool)
    vb.add_child(calculate)

    engineering_output = RichTextLabel.new()
    engineering_output.bbcode_enabled = true
    engineering_output.custom_minimum_size = Vector2(620, 245)
    engineering_output.fit_content = false
    vb.add_child(engineering_output)

    var warning := Label.new()
    warning.text = "Bu masa temel mühendislik bağıntılarını hesaplar. Mevzuata göre nihai tasarım/yeterlilik kararı için doğrulanmış standart, yük birleşimleri ve proje girdileri ayrıca gerekir."
    warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(warning)

    if not engineering_presets.is_empty():
        engineering_selector.select(0)
        _refresh_engineering_form(0)

func _on_engineering_tool_selected(index: int) -> void:
    _refresh_engineering_form(index)

func _refresh_engineering_form(index: int) -> void:
    if index < 0 or index >= engineering_presets.size():
        return
    var fields: Array = engineering_presets[index].get("fields", [])
    for i in range(engineering_field_rows.size()):
        if i < fields.size():
            var field: Dictionary = fields[i]
            engineering_field_rows[i].visible = true
            engineering_field_labels[i].text = str(field.get("label", "Değer"))
            engineering_field_edits[i].text = str(field.get("default", ""))
            engineering_field_edits[i].set_meta("engineering_key", str(field.get("key", "")))
        else:
            engineering_field_rows[i].visible = false
            engineering_field_edits[i].text = ""
            engineering_field_edits[i].set_meta("engineering_key", "")
    engineering_output.clear()
    engineering_output.append_text("[i]Değerleri girip HESAPLA'ya bas. İnşaat Mühendisi ajanı da konuşma içinde gerektiğinde aynı araçları otomatik çağırabilir.[/i]")

func _run_manual_engineering_tool() -> void:
    var index := engineering_selector.selected
    if index < 0 or index >= engineering_presets.size():
        return
    var preset: Dictionary = engineering_presets[index]
    var args := {}
    for i in range(engineering_field_rows.size()):
        if not engineering_field_rows[i].visible:
            continue
        var key := str(engineering_field_edits[i].get_meta("engineering_key", ""))
        var raw := engineering_field_edits[i].text.strip_edges()
        if key.is_empty() or raw.is_empty():
            continue
        var normalized := raw.replace(",", ".")
        if not normalized.is_valid_float():
            engineering_output.clear()
            engineering_output.append_text("[color=red][b]Hata:[/b] %s sayısal olmalı.[/color]" % engineering_field_labels[i].text)
            return
        args[key] = normalized.to_float()
    var result := EngineeringTools.run_tool(str(preset.get("id", "")), args, "manual", "Mühendislik Hesap Masası")
    engineering_output.clear()
    engineering_output.append_text(EngineeringTools.format_result_bbcode(result))

func _toggle_engineering_panel() -> void:
    engineering_panel.visible = not engineering_panel.visible
    if engineering_panel.visible:
        chat_panel.visible = false
        model_panel.visible = false
        if project_panel != null:
            project_panel.visible = false
        if procurement_panel != null:
            procurement_panel.visible = false
        _refresh_engineering_form(engineering_selector.selected)

func _ui_button(parent: Node, text_value: String, pos: Vector2, size_value: Vector2) -> Button:
    var button := Button.new()
    button.text = text_value
    button.position = pos
    button.size = size_value
    button.focus_mode = Control.FOCUS_NONE
    parent.add_child(button)
    return button

func _sync_touch() -> void:
    if player != null:
        player.set_touch_input(touch_vector)

func _update_nearest_target() -> void:
    var best_dist := 999.0
    var best: Dictionary = {}
    for item in interactables:
        var pos: Vector3 = item["position"]
        var dist := Vector2(player.global_position.x - pos.x, player.global_position.z - pos.z).length()
        if dist < best_dist:
            best_dist = dist
            best = item
    if best_dist <= 2.8:
        nearest_target = best
        hint_label.text = "%s  ·  E / KONUŞ" % best["name"]
    else:
        nearest_target = {}
        hint_label.text = "Uzmanlara, bilgisayara, toplantı masasına veya araca yaklaş"

func _interact() -> void:
    if nearest_target.is_empty():
        return
    match str(nearest_target["type"]):
        "agent", "core":
            _open_chat(str(nearest_target["id"]))
        "meeting":
            _open_chat("coordinator")
            transcript.append_text("[b]Sistem:[/b] Toplantı masasındasın. Konuyu yazıp ‘Uzman Toplantısı Başlat’a bas.\n\n")
        "car":
            _open_chat("core")
            transcript.append_text("[b]Araç:[/b] Araç dünya nesnesi hazır. Sürüş fiziği bir sonraki dünya iterasyonunda bağlanacak. AI çekirdeğine buradan da erişebilirsin.\n\n")
        "engineering":
            engineering_panel.visible = true
            chat_panel.visible = false
            model_panel.visible = false
            if project_panel != null:
                project_panel.visible = false
            if procurement_panel != null:
                procurement_panel.visible = false
            _refresh_engineering_form(engineering_selector.selected)

func _open_chat(agent_id: String) -> void:
    chat_agent_id = agent_id
    var profile := AgentRouter.get_profile(agent_id)
    chat_title.text = "%s  —  %s" % [profile["name"], profile["role"]]
    transcript.clear()
    var history := MemoryStore.get_recent(agent_id, 10)
    for item in history:
        var who := "Sen" if item.get("speaker", "") == "user" else profile["name"]
        transcript.append_text("[b]%s:[/b] %s\n\n" % [who, item.get("text", "")])
    chat_panel.visible = true
    model_panel.visible = false
    if project_panel != null:
        project_panel.visible = false
    if engineering_panel != null:
        engineering_panel.visible = false
    if procurement_panel != null:
        procurement_panel.visible = false
    input_line.grab_focus()

func _send_chat() -> void:
    var text_value := input_line.text.strip_edges()
    if text_value.is_empty():
        return
    transcript.append_text("[b]Sen:[/b] %s\n\n" % text_value)
    input_line.clear()
    AgentRouter.ask_async(chat_agent_id, text_value)
    transcript.append_text("[i]Yanıt hazırlanıyor…[/i]\n\n")

func _on_reply_completed(agent_id: String, text: String, _request_id: int) -> void:
    if not chat_panel.visible or chat_agent_id != agent_id:
        return
    var profile := AgentRouter.get_profile(agent_id)
    transcript.append_text("[b]%s:[/b] %s\n\n" % [profile["name"], text])
    transcript.scroll_to_line(maxi(0, transcript.get_line_count() - 1))

func _on_reply_failed(agent_id: String, error: String, _request_id: int) -> void:
    if not chat_panel.visible or chat_agent_id != agent_id:
        return
    transcript.append_text("[color=red][b]Hata:[/b] %s[/color]\n\n" % error)

func _meeting_from_chat() -> void:
    var topic := input_line.text.strip_edges()
    if topic.is_empty():
        topic = "Mevcut proje için disiplinler arası ön değerlendirme"
    input_line.clear()
    chat_agent_id = "coordinator"
    var profile := AgentRouter.get_profile("coordinator")
    chat_title.text = "%s  —  %s" % [profile["name"], profile["role"]]
    transcript.append_text("[b]Sen:[/b] %s\n\n" % topic)
    active_meeting_id = AgentRouter.start_meeting(topic)

func _on_meeting_progress(session_id: int, text: String) -> void:
    if session_id != active_meeting_id:
        return
    transcript.append_text("[color=gray][i]%s[/i][/color]\n" % text)

func _on_meeting_completed(session_id: int, text: String) -> void:
    if session_id != active_meeting_id:
        return
    transcript.append_text("\n[b]Koordinatör — Toplantı Sonucu:[/b]\n%s\n\n" % text)
    active_meeting_id = -1
    transcript.scroll_to_line(maxi(0, transcript.get_line_count() - 1))

func _toggle_model_panel() -> void:
    model_panel.visible = not model_panel.visible
    if model_panel.visible:
        chat_panel.visible = false
        if project_panel != null:
            project_panel.visible = false
        if engineering_panel != null:
            engineering_panel.visible = false
        if procurement_panel != null:
            procurement_panel.visible = false
        _refresh_model_panel()

func _select_model() -> void:
    if OS.get_name() == "Android" and InferenceService.supports_native_model_picker():
        if InferenceService.request_native_model_picker():
            model_status_label.text = "Android dosya seçici açıldı. GGUF dosyanı seç…"
            return
    model_file_dialog.popup_centered_ratio(0.75)

func _on_native_model_import_progress(progress: String, detail: String) -> void:
    if model_status_label != null:
        model_status_label.text = "Model uygulama depolamasına aktarılıyor: %s · %s" % [progress, detail]

func _on_native_model_imported(path: String, display_name: String) -> void:
    _refresh_model_panel()
    model_status_label.text += "\n✓ Model uygulama depolamasına aktarıldı: %s" % display_name

func _on_native_model_import_failed(error: String) -> void:
    _refresh_model_panel()
    model_status_label.text += "\n✗ Model içe aktarma hatası: %s" % error


func _run_model_diagnostics() -> void:
    if model_diagnostics_label == null:
        return
    var lines: Array[String] = []
    var runtime := InferenceService.get_runtime_diagnostics()
    if bool(runtime.get("ok", false)):
        lines.append("Cihaz: %s" % str(runtime.get("device", "bilinmiyor")))
        var abi_parts := PackedStringArray()
        for abi in runtime.get("abis", []):
            abi_parts.append(str(abi))
        lines.append("Android API: %s · ABI: %s" % [str(runtime.get("android_sdk", "?")), abi_parts.join(", ")])
        lines.append("Kullanılabilir RAM: %s / toplam %s" % [_format_bytes(int(runtime.get("memory_available_bytes", 0))), _format_bytes(int(runtime.get("memory_total_bytes", 0)))])
        lines.append("Uygulama depolaması boş alan: %s" % _format_bytes(int(runtime.get("storage_available_bytes", 0))))
    else:
        lines.append("Android native tanı: %s" % str(runtime.get("error", "kullanılamıyor")))

    var model_path := ModelManager.get_model_path()
    if not model_path.is_empty():
        var inspected := InferenceService.inspect_selected_model()
        if bool(inspected.get("ok", false)):
            lines.append("GGUF doğrulaması: GEÇTİ · %s · %s" % [str(inspected.get("name", model_path.get_file())), _format_bytes(int(inspected.get("size_bytes", 0)))])
        else:
            lines.append("GGUF doğrulaması: BAŞARISIZ · %s" % str(inspected.get("error", "bilinmeyen hata")))
    else:
        lines.append("GGUF doğrulaması: model seçilmedi")
    model_diagnostics_label.text = "\n".join(lines)

func _format_bytes(value: int) -> String:
    if value <= 0:
        return "bilinmiyor"
    var gb := float(value) / 1073741824.0
    if gb >= 1.0:
        return "%.2f GB" % gb
    return "%.1f MB" % (float(value) / 1048576.0)

func _on_model_selected(path: String) -> void:
    ModelManager.set_selected_model(path, path.get_file())
    _refresh_model_panel()

func _load_selected_model() -> void:
    var path := ModelManager.get_model_path()
    if path.is_empty():
        model_status_label.text = "Önce GGUF model seçmelisin."
        return
    model_status_label.text = "Model yükleme kuyruğuna alındı…"
    InferenceService.load_model(path)

func _save_license_record() -> void:
    ModelManager.set_license_info(
        license_name_edit.text.strip_edges(),
        license_source_edit.text.strip_edges(),
        license_reviewed_check.button_pressed,
        commercial_allowed_check.button_pressed
    )

func _refresh_model_panel() -> void:
    if model_status_label == null:
        return
    var loaded_text := "YÜKLÜ" if InferenceService.is_model_loaded() else "YÜKLÜ DEĞİL / DEMO"
    model_status_label.text = "Altyapı: %s\nDurum: %s" % [InferenceService.get_backend_info(), loaded_text]
    var selected := ModelManager.get_model_path()
    model_path_label.text = "Seçili model: %s" % (selected if not selected.is_empty() else "Henüz seçilmedi")
    license_status_label.text = "Dağıtım durumu: %s" % ModelManager.license_status_text()
    var license := ModelManager.get_license()
    license_name_edit.text = str(license.get("name", ""))
    license_source_edit.text = str(license.get("source", ""))
    license_reviewed_check.button_pressed = bool(license.get("reviewed", false))
    commercial_allowed_check.button_pressed = bool(license.get("commercial_use_allowed", false))
    if auto_load_check != null:
        auto_load_check.set_pressed_no_signal(ModelManager.should_auto_load_on_startup())
    if self_test_button != null:
        self_test_button.disabled = not InferenceService.is_model_loaded()

func _try_auto_load_selected_model() -> void:
    if OS.get_name() != "Android":
        return
    if not ModelManager.should_auto_load_on_startup() or InferenceService.is_model_loaded():
        return
    var path := ModelManager.get_model_path()
    if path.is_empty():
        return
    model_status_label.text += "\nSeçili yerel model otomatik yükleniyor…"
    InferenceService.load_model(path)

func _run_local_ai_self_test() -> void:
    if model_status_label != null:
        model_status_label.text += "\nYerel AI Türkçe testi çalışıyor…"
    InferenceService.run_self_test()

func _on_self_test_finished(ok: bool, message: String) -> void:
    _refresh_model_panel()
    if model_status_label != null:
        model_status_label.text += "\n%s%s" % ["✓ Yerel AI testi geçti: " if ok else "✗ Yerel AI testi başarısız: ", message]

func _on_model_load_finished(ok: bool, message: String) -> void:
    _refresh_model_panel()
    model_status_label.text += "\n%s%s" % ["✓ " if ok else "✗ ", message]

func _on_inference_state_changed(state: String) -> void:
    match state:
        "ready":
            inference_status_label.text = "AI · YEREL MODEL HAZIR"
        "loading_model":
            inference_status_label.text = "AI · MODEL YÜKLENİYOR"
        "generating":
            inference_status_label.text = "AI · ÇALIŞIYOR"
        "unloading_model":
            inference_status_label.text = "AI · MODEL KAPATILIYOR"
        _:
            inference_status_label.text = "AI · DEMO / MODEL YÜKLÜ DEĞİL"


func _toggle_project_panel() -> void:
    project_panel.visible = not project_panel.visible
    if project_panel.visible:
        chat_panel.visible = false
        model_panel.visible = false
        if engineering_panel != null:
            engineering_panel.visible = false
        if procurement_panel != null:
            procurement_panel.visible = false
        _refresh_project_panel()

func _refresh_project_panel() -> void:
    if project_selector == null:
        return
    var active_id := ProjectStore.get_active_project_id()
    var projects := ProjectStore.get_projects()
    project_selector.clear()
    var selected_index := 0
    var i := 0
    for project in projects:
        project_selector.add_item(str(project.get("name", "Adsız Proje")))
        project_selector.set_item_metadata(i, str(project.get("id", "")))
        if str(project.get("id", "")) == active_id:
            selected_index = i
        i += 1
    if project_selector.item_count > 0:
        project_selector.select(selected_index)

    var active := ProjectStore.get_active_project()
    var docs := ProjectStore.get_documents(active_id)
    project_status_label.text = "Aktif proje: %s · %d belge" % [str(active.get("name", "Aktif proje yok")), docs.size()]
    project_documents_label.clear()
    if docs.is_empty():
        project_documents_label.append_text("[i]Henüz belge yok. Teknik rapor, şartname, mevzuat veya proje notlarını ekleyebilirsin.[/i]")
        return
    var idx := 1
    for doc in docs:
        project_documents_label.append_text("[b]%d. %s[/b]\n" % [idx, str(doc.get("name", "Belge"))])
        project_documents_label.append_text("   %d karakter · %d bilgi parçası\n\n" % [int(doc.get("char_count", 0)), int(doc.get("chunk_count", 0))])
        idx += 1

func _create_project_from_ui() -> void:
    var name := new_project_edit.text.strip_edges()
    if name.is_empty():
        project_status_label.text = "Proje adı yazmalısın."
        return
    ProjectStore.create_project(name)
    new_project_edit.clear()
    _refresh_project_panel()

func _on_project_selected(index: int) -> void:
    if index < 0 or index >= project_selector.item_count:
        return
    var project_id := str(project_selector.get_item_metadata(index))
    ProjectStore.set_active_project(project_id)
    _refresh_project_panel()

func _on_active_project_changed(_project_id: String) -> void:
    _refresh_project_panel()

func _select_document() -> void:
    if OS.get_name() == "Android" and DocumentImporter.supports_native_picker():
        if DocumentImporter.request_native_picker():
            project_status_label.text = "Belge seçici açıldı. PDF veya metin belgesi seçebilirsin."
            return
    document_file_dialog.popup_centered_ratio(0.78)

func _on_document_selected(path: String) -> void:
    DocumentImporter.import_desktop_file(path)

func _on_document_import_started(display_name: String) -> void:
    if project_status_label != null:
        project_status_label.text = "%s yerel olarak okunuyor ve indeksleniyor…" % display_name

func _on_document_import_finished(ok: bool, message: String, _document_id: String) -> void:
    _refresh_project_panel()
    if project_status_label != null:
        project_status_label.text += "\n%s %s" % ["✓" if ok else "✗", message]

func _on_document_picker_state(message: String) -> void:
    if DocumentImporter.get_pending_target() == "procurement":
        if procurement_status_label != null:
            procurement_status_label.text = message
    elif project_status_label != null:
        project_status_label.text = message


func _toggle_procurement_panel() -> void:
    procurement_panel.visible = not procurement_panel.visible
    if procurement_panel.visible:
        chat_panel.visible = false
        model_panel.visible = false
        if project_panel != null:
            project_panel.visible = false
        if engineering_panel != null:
            engineering_panel.visible = false
        _refresh_procurement_panel()

func _selected_procurement_kind() -> String:
    if procurement_source_selector == null or procurement_source_selector.selected < 0:
        return "other"
    return str(procurement_source_selector.get_item_metadata(procurement_source_selector.selected))

func _select_procurement_document() -> void:
    var kind := _selected_procurement_kind()
    if OS.get_name() == "Android" and DocumentImporter.supports_native_picker():
        if DocumentImporter.request_native_procurement_picker(kind):
            procurement_status_label.text = "Belge seçici açıldı. Resmi KİK/YFK/mevzuat belgesini seçebilirsin."
            return
    procurement_file_dialog.popup_centered_ratio(0.80)

func _on_procurement_document_selected(path: String) -> void:
    DocumentImporter.import_procurement_desktop_file(path, _selected_procurement_kind())

func _on_procurement_import_started(display_name: String, source_kind: String) -> void:
    if procurement_status_label != null:
        procurement_status_label.text = "%s (%s) yerel ihale arşivine hazırlanıyor…" % [display_name, source_kind.to_upper()]

func _on_procurement_import_finished(ok: bool, message: String, _document_id: String, _source_kind: String) -> void:
    _refresh_procurement_panel()
    if procurement_status_label != null:
        procurement_status_label.text += "\n%s %s" % ["✓" if ok else "✗", message]

func _refresh_procurement_panel() -> void:
    if procurement_status_label == null or procurement_documents_label == null:
        return
    procurement_status_label.text = ProcurementKnowledge.archive_coverage_text()
    procurement_documents_label.clear()
    var docs := ProcurementKnowledge.get_documents()
    if docs.is_empty():
        procurement_documents_label.append_text("[i]Yerel karar arşivi henüz boş. Resmi KİK/YFK kararlarını ve mevzuat belgelerini ekledikçe uzman bunları kaynak göstererek kullanacak.[/i]")
        return
    var index := 1
    for doc in docs:
        var kind := str(doc.get("source_kind", "other")).to_upper()
        procurement_documents_label.append_text("[b]%d. [%s] %s[/b]\n" % [index, kind, str(doc.get("name", "Belge"))])
        procurement_documents_label.append_text("   %d karakter · %d bilgi parçası\n\n" % [int(doc.get("char_count", 0)), int(doc.get("chunk_count", 0))])
        index += 1
