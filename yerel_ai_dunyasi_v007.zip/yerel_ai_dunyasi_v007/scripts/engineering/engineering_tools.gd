extends Node

const HISTORY_DIR := "user://engineering"
const HISTORY_PATH := HISTORY_DIR + "/history.jsonl"

const TOOL_OPEN := "<YEREL_ARAC>"
const TOOL_CLOSE := "</YEREL_ARAC>"

var _unit_defs := {
    "n": {"family":"force", "scale":1.0, "label":"N"},
    "kn": {"family":"force", "scale":1000.0, "label":"kN"},
    "mn": {"family":"force", "scale":1000000.0, "label":"MN"},
    "mm": {"family":"length", "scale":0.001, "label":"mm"},
    "cm": {"family":"length", "scale":0.01, "label":"cm"},
    "m": {"family":"length", "scale":1.0, "label":"m"},
    "pa": {"family":"stress", "scale":1.0, "label":"Pa"},
    "kpa": {"family":"stress", "scale":1000.0, "label":"kPa"},
    "mpa": {"family":"stress", "scale":1000000.0, "label":"MPa"},
    "gpa": {"family":"stress", "scale":1000000000.0, "label":"GPa"},
    "n/mm2": {"family":"stress", "scale":1000000.0, "label":"N/mm²"},
    "n/mm²": {"family":"stress", "scale":1000000.0, "label":"N/mm²"},
    "n/m": {"family":"line_load", "scale":1.0, "label":"N/m"},
    "kn/m": {"family":"line_load", "scale":1000.0, "label":"kN/m"},
    "n/m2": {"family":"area_load", "scale":1.0, "label":"N/m²"},
    "n/m²": {"family":"area_load", "scale":1.0, "label":"N/m²"},
    "kn/m2": {"family":"area_load", "scale":1000.0, "label":"kN/m²"},
    "kn/m²": {"family":"area_load", "scale":1000.0, "label":"kN/m²"}
}

func _ready() -> void:
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(HISTORY_DIR))

func get_manual_presets() -> Array[Dictionary]:
    return [
        {
            "id":"basit_kiris_yayili_yuk",
            "name":"Basit kiriş · düzgün yayılı yük",
            "fields":[
                {"key":"span_m", "label":"Açıklık L (m)", "default":"5"},
                {"key":"w_kn_m", "label":"Yayılı yük w (kN/m)", "default":"12"},
                {"key":"e_gpa", "label":"E (GPa) · isteğe bağlı", "default":""},
                {"key":"i_mm4", "label":"I (mm⁴) · isteğe bağlı", "default":""}
            ]
        },
        {
            "id":"basit_kiris_tekil_yuk",
            "name":"Basit kiriş · tekil yük",
            "fields":[
                {"key":"span_m", "label":"Açıklık L (m)", "default":"6"},
                {"key":"load_kn", "label":"Tekil yük P (kN)", "default":"20"},
                {"key":"a_m", "label":"Soldan uzaklık a (m)", "default":"2"}
            ]
        },
        {
            "id":"dikdortgen_kesit",
            "name":"Dikdörtgen kesit özellikleri",
            "fields":[
                {"key":"b_mm", "label":"Genişlik b (mm)", "default":"300"},
                {"key":"h_mm", "label":"Yükseklik h (mm)", "default":"500"}
            ]
        },
        {
            "id":"eksenel_gerilme",
            "name":"Ortalama eksenel gerilme",
            "fields":[
                {"key":"force_kn", "label":"Eksenel kuvvet N (kN)", "default":"600"},
                {"key":"area_mm2", "label":"Kesit alanı A (mm²)", "default":"150000"}
            ]
        },
        {
            "id":"alan_yukunu_cizgisele_cevir",
            "name":"Alan yükünü çizgisel yüke çevir",
            "fields":[
                {"key":"area_load_kn_m2", "label":"Alan yükü q (kN/m²)", "default":"5"},
                {"key":"tributary_width_m", "label":"Tesir genişliği (m)", "default":"3"}
            ]
        },
        {
            "id":"oz_agirlik",
            "name":"Hacimden öz ağırlık hesabı",
            "fields":[
                {"key":"volume_m3", "label":"Hacim (m³)", "default":"2"},
                {"key":"unit_weight_kn_m3", "label":"Birim hacim ağırlık (kN/m³)", "default":"25"}
            ]
        }
    ]

func get_agent_tool_instructions(agent_id: String) -> String:
    if agent_id not in ["core", "coordinator", "civil"]:
        return ""
    return """
YEREL MÜHENDİSLİK ARAÇLARI:
Sayısal bir taşıyıcı sistem veya birim hesabı gerekiyorsa sonucu zihinden uydurma. Uygun araç aşağıdaysa önce aracı çağır.
Araç çağrısı gerekiyorsa cevabının TAMAMI yalnızca şu biçimde olsun:
<YEREL_ARAC>{\"tool\":\"arac_adi\",\"args\":{...}}</YEREL_ARAC>
Başına veya sonuna açıklama ekleme. Araç sonucu sana geri verildikten sonra Türkçe nihai açıklamayı üret.

Kullanılabilir araçlar:
- basit_kiris_yayili_yuk: {span_m, w_kn_m, e_gpa?, i_mm4?}
- basit_kiris_tekil_yuk: {span_m, load_kn, a_m}
- dikdortgen_kesit: {b_mm, h_mm}
- eksenel_gerilme: {force_kn, area_mm2}
- alan_yukunu_cizgisele_cevir: {area_load_kn_m2, tributary_width_m}
- oz_agirlik: {volume_m3, unit_weight_kn_m3}
- birim_donustur: {value, from_unit, to_unit}

SINIRLAR:
- Bu araçlar temel statik/mukavemet ve birim işlemleridir; tek başına mevzuata göre boyutlandırma veya güvenlik onayı değildir.
- Yük birleşimleri, deprem hesabı, betonarme/çelik dayanım, stabilite, süneklik, detaylandırma ve temel-zemin tasarımı için ayrıca doğrulanmış mevzuat/veri gerekir.
- Eksik girdi varsa araç çağırmak yerine kullanıcıdan eksik girdiyi iste.
"""

func parse_tool_call(text: String) -> Dictionary:
    var start := text.find(TOOL_OPEN)
    var finish := text.find(TOOL_CLOSE)
    if start < 0 or finish < 0 or finish <= start:
        return {}
    var payload := text.substr(start + TOOL_OPEN.length(), finish - (start + TOOL_OPEN.length())).strip_edges()
    var parsed = JSON.parse_string(payload)
    if typeof(parsed) != TYPE_DICTIONARY:
        return {"_parse_error":"Araç çağrısı JSON biçimi geçersiz."}
    return parsed

func run_tool(tool_id: String, args: Dictionary, agent_id: String = "manual", question: String = "") -> Dictionary:
    var result: Dictionary
    match tool_id:
        "basit_kiris_yayili_yuk":
            result = _beam_udl(args)
        "basit_kiris_tekil_yuk":
            result = _beam_point_load(args)
        "dikdortgen_kesit":
            result = _rect_section(args)
        "eksenel_gerilme":
            result = _axial_stress(args)
        "alan_yukunu_cizgisele_cevir":
            result = _area_to_line_load(args)
        "oz_agirlik":
            result = _self_weight(args)
        "birim_donustur":
            result = _unit_convert(args)
        _:
            result = _error(tool_id, "Bilinmeyen mühendislik aracı: %s" % tool_id)
    result["agent_id"] = agent_id
    result["question"] = question
    result["project_id"] = ProjectStore.get_active_project_id() if ProjectStore != null else ""
    result["timestamp_unix"] = int(Time.get_unix_time_from_system())
    _append_history(result)
    return result

func format_result_for_ai(result: Dictionary) -> String:
    if not bool(result.get("ok", false)):
        return "ARAÇ HATASI: %s" % str(result.get("error", "Bilinmeyen hata"))
    var lines: Array[String] = []
    lines.append("Araç: %s" % str(result.get("title", result.get("tool", "Mühendislik aracı"))))
    var outputs: Dictionary = result.get("results", {})
    for key in outputs.keys():
        lines.append("- %s: %s" % [str(key), str(outputs[key])])
    var assumptions: Array = result.get("assumptions", [])
    if not assumptions.is_empty():
        lines.append("Varsayımlar:")
        for item in assumptions:
            lines.append("- %s" % str(item))
    var equations: Array = result.get("equations", [])
    if not equations.is_empty():
        lines.append("Kullanılan temel bağıntılar:")
        for item in equations:
            lines.append("- %s" % str(item))
    var warning := str(result.get("warning", ""))
    if not warning.is_empty():
        lines.append("Uyarı: %s" % warning)
    return "\n".join(lines)

func format_result_bbcode(result: Dictionary) -> String:
    if not bool(result.get("ok", false)):
        return "[color=red][b]Hata:[/b] %s[/color]" % str(result.get("error", "Bilinmeyen hata"))
    var text := "[b]%s[/b]\n" % str(result.get("title", "Mühendislik hesabı"))
    var outputs: Dictionary = result.get("results", {})
    for key in outputs.keys():
        text += "• [b]%s:[/b] %s\n" % [str(key), str(outputs[key])]
    var assumptions: Array = result.get("assumptions", [])
    if not assumptions.is_empty():
        text += "\n[b]Varsayımlar[/b]\n"
        for item in assumptions:
            text += "• %s\n" % str(item)
    var warning := str(result.get("warning", ""))
    if not warning.is_empty():
        text += "\n[color=orange][b]Sınır:[/b] %s[/color]" % warning
    return text

func _beam_udl(args: Dictionary) -> Dictionary:
    var l := _positive(args, "span_m", "Açıklık L")
    if not l["ok"]: return l
    var w := _nonnegative(args, "w_kn_m", "Yayılı yük w")
    if not w["ok"]: return w
    var span := float(l["value"])
    var load := float(w["value"])
    var reaction := load * span / 2.0
    var moment := load * span * span / 8.0
    var outputs := {
        "Sol mesnet tepkisi RA": _fmt(reaction, "kN"),
        "Sağ mesnet tepkisi RB": _fmt(reaction, "kN"),
        "Maksimum kesme |V|max": _fmt(reaction, "kN"),
        "Maksimum eğilme momenti Mmax": _fmt(moment, "kN·m")
    }
    if args.has("e_gpa") and args.has("i_mm4") and str(args.get("e_gpa", "")).strip_edges() != "" and str(args.get("i_mm4", "")).strip_edges() != "":
        var e := _positive(args, "e_gpa", "Elastisite modülü E")
        if not e["ok"]: return e
        var inertia := _positive(args, "i_mm4", "Atalet momenti I")
        if not inertia["ok"]: return inertia
        var l_mm := span * 1000.0
        var w_n_mm := load # 1 kN/m = 1 N/mm
        var e_n_mm2 := float(e["value"]) * 1000.0
        var delta_mm := 5.0 * w_n_mm * pow(l_mm, 4.0) / (384.0 * e_n_mm2 * float(inertia["value"]))
        outputs["Elastik maksimum sehim δmax"] = _fmt(delta_mm, "mm")
    return _ok(
        "basit_kiris_yayili_yuk",
        "Basit mesnetli kiriş · düzgün yayılı yük",
        outputs,
        ["İki uç ideal basit mesnetlidir.", "Yük açıklık boyunca sabit ve düşeydir.", "İkinci mertebe etkiler ve mesnet esnekliği yok sayılır."],
        ["RA = RB = wL/2", "Mmax = wL²/8", "δmax = 5wL⁴/(384EI) · yalnız E ve I verilirse"],
        _structural_warning()
    )

func _beam_point_load(args: Dictionary) -> Dictionary:
    var l := _positive(args, "span_m", "Açıklık L")
    if not l["ok"]: return l
    var p := _nonnegative(args, "load_kn", "Tekil yük P")
    if not p["ok"]: return p
    var a_check := _nonnegative(args, "a_m", "Yük konumu a")
    if not a_check["ok"]: return a_check
    var span := float(l["value"])
    var load := float(p["value"])
    var a := float(a_check["value"])
    if a > span:
        return _error("basit_kiris_tekil_yuk", "Yük konumu a, açıklık L değerinden büyük olamaz.")
    var b := span - a
    var ra := load * b / span
    var rb := load * a / span
    var m_at_load := ra * a
    return _ok(
        "basit_kiris_tekil_yuk",
        "Basit mesnetli kiriş · tekil yük",
        {
            "Sol mesnet tepkisi RA": _fmt(ra, "kN"),
            "Sağ mesnet tepkisi RB": _fmt(rb, "kN"),
            "Yük altındaki maksimum moment": _fmt(m_at_load, "kN·m"),
            "Moment konumu": _fmt(a, "m · soldan")
        },
        ["İki uç ideal basit mesnetlidir.", "Tekil yük düşeydir.", "Yük konumu soldan ölçülür."],
        ["b = L-a", "RA = P·b/L", "RB = P·a/L", "M(yük altında) = RA·a = Pab/L"],
        _structural_warning()
    )

func _rect_section(args: Dictionary) -> Dictionary:
    var b_check := _positive(args, "b_mm", "Kesit genişliği b")
    if not b_check["ok"]: return b_check
    var h_check := _positive(args, "h_mm", "Kesit yüksekliği h")
    if not h_check["ok"]: return h_check
    var b := float(b_check["value"])
    var h := float(h_check["value"])
    var area := b * h
    var ix := b * pow(h, 3.0) / 12.0
    var iy := h * pow(b, 3.0) / 12.0
    var wx := ix / (h / 2.0)
    var wy := iy / (b / 2.0)
    return _ok(
        "dikdortgen_kesit",
        "Dikdörtgen kesit geometrik özellikleri",
        {
            "Alan A": _fmt(area, "mm²"),
            "Ix": _fmt(ix, "mm⁴"),
            "Iy": _fmt(iy, "mm⁴"),
            "Wx": _fmt(wx, "mm³"),
            "Wy": _fmt(wy, "mm³")
        },
        ["Kesit boşluksuz dikdörtgendir.", "x ekseni yatay merkez eksenidir; h düşey boyuttur."],
        ["A = b·h", "Ix = b·h³/12", "Iy = h·b³/12", "W = I/c"],
        "Geometrik kesit özellikleridir; malzeme dayanımı veya yönetmelik yeterlilik kontrolü içermez."
    )

func _axial_stress(args: Dictionary) -> Dictionary:
    var force_check := _number(args, "force_kn", "Eksenel kuvvet N")
    if not force_check["ok"]: return force_check
    var area_check := _positive(args, "area_mm2", "Kesit alanı A")
    if not area_check["ok"]: return area_check
    var force := float(force_check["value"])
    var area := float(area_check["value"])
    var stress_mpa := force * 1000.0 / area
    return _ok(
        "eksenel_gerilme",
        "Ortalama eksenel normal gerilme",
        {"σ = N/A": _fmt(stress_mpa, "MPa")},
        ["Kuvvet kesit ağırlık merkezinden eksenel etkir.", "Gerilme kesitte üniform kabul edilir."],
        ["σ = N/A", "1 MPa = 1 N/mm²"],
        "Bu sonuç ortalama gerilmedir; burkulma, ikinci mertebe, eksantrisite, çatlama, donatı ve malzeme tasarım dayanımı kontrollerini içermez."
    )

func _area_to_line_load(args: Dictionary) -> Dictionary:
    var q_check := _number(args, "area_load_kn_m2", "Alan yükü q")
    if not q_check["ok"]: return q_check
    var width_check := _positive(args, "tributary_width_m", "Tesir genişliği")
    if not width_check["ok"]: return width_check
    var q := float(q_check["value"])
    var width := float(width_check["value"])
    return _ok(
        "alan_yukunu_cizgisele_cevir",
        "Alan yükünden çizgisel yük",
        {"Çizgisel yük w": _fmt(q * width, "kN/m")},
        ["Tesir genişliği sabittir.", "Alan yükü seçilen şeritte üniformdur."],
        ["w = q · b_tesir"],
        "Tesir genişliğinin taşıyıcı sistem geometrisine uygun seçildiği ayrıca doğrulanmalıdır."
    )

func _self_weight(args: Dictionary) -> Dictionary:
    var volume_check := _nonnegative(args, "volume_m3", "Hacim")
    if not volume_check["ok"]: return volume_check
    var gamma_check := _nonnegative(args, "unit_weight_kn_m3", "Birim hacim ağırlık")
    if not gamma_check["ok"]: return gamma_check
    var volume := float(volume_check["value"])
    var gamma := float(gamma_check["value"])
    return _ok(
        "oz_agirlik",
        "Hacimden ağırlık",
        {"Toplam ağırlık G": _fmt(volume * gamma, "kN")},
        ["Birim hacim ağırlık kullanıcı girdisidir."],
        ["G = V · γ"],
        "Malzeme birim hacim ağırlığı projeye ve gerçek malzemeye göre doğrulanmalıdır."
    )

func _unit_convert(args: Dictionary) -> Dictionary:
    var value_check := _number(args, "value", "Dönüştürülecek değer")
    if not value_check["ok"]: return value_check
    var from_unit := _normalize_unit(str(args.get("from_unit", "")))
    var to_unit := _normalize_unit(str(args.get("to_unit", "")))
    if not _unit_defs.has(from_unit):
        return _error("birim_donustur", "Desteklenmeyen kaynak birim: %s" % str(args.get("from_unit", "")))
    if not _unit_defs.has(to_unit):
        return _error("birim_donustur", "Desteklenmeyen hedef birim: %s" % str(args.get("to_unit", "")))
    var source: Dictionary = _unit_defs[from_unit]
    var target: Dictionary = _unit_defs[to_unit]
    if source["family"] != target["family"]:
        return _error("birim_donustur", "Boyutları farklı birimler birbirine dönüştürülemez.")
    var base_value := float(value_check["value"]) * float(source["scale"])
    var converted := base_value / float(target["scale"])
    return _ok(
        "birim_donustur",
        "Birim dönüşümü",
        {"Sonuç": _fmt(converted, str(target["label"]))},
        [],
        [],
        ""
    )

func _ok(tool_id: String, title: String, results: Dictionary, assumptions: Array, equations: Array, warning: String) -> Dictionary:
    return {
        "ok": true,
        "tool": tool_id,
        "title": title,
        "results": results,
        "assumptions": assumptions,
        "equations": equations,
        "warning": warning,
        "basis": "Deterministik temel mühendislik hesabı"
    }

func _error(tool_id: String, message: String) -> Dictionary:
    return {"ok": false, "tool": tool_id, "error": message}

func _number(args: Dictionary, key: String, label: String) -> Dictionary:
    if not args.has(key):
        return _error("input", "%s eksik." % label)
    var raw = args[key]
    if typeof(raw) in [TYPE_INT, TYPE_FLOAT]:
        return {"ok": true, "value": float(raw)}
    var text := str(raw).strip_edges().replace(",", ".")
    if not text.is_valid_float():
        return _error("input", "%s sayısal olmalı." % label)
    return {"ok": true, "value": text.to_float()}

func _positive(args: Dictionary, key: String, label: String) -> Dictionary:
    var check := _number(args, key, label)
    if not check["ok"]: return check
    if float(check["value"]) <= 0.0:
        return _error("input", "%s sıfırdan büyük olmalı." % label)
    return check

func _nonnegative(args: Dictionary, key: String, label: String) -> Dictionary:
    var check := _number(args, key, label)
    if not check["ok"]: return check
    if float(check["value"]) < 0.0:
        return _error("input", "%s negatif olamaz." % label)
    return check

func _fmt(value: float, unit: String) -> String:
    var abs_value := absf(value)
    var numeric: String
    if abs_value >= 1000000.0:
        numeric = "%.4e" % value
    elif abs_value >= 1000.0:
        numeric = "%.2f" % value
    elif abs_value >= 10.0:
        numeric = "%.3f" % value
    else:
        numeric = "%.4f" % value
    return "%s %s" % [numeric, unit]

func _normalize_unit(value: String) -> String:
    return value.strip_edges().to_lower().replace(" ", "")

func _structural_warning() -> String:
    return "Temel statik sonuçtur; yük birleşimi, güvenlik katsayısı, kesit dayanımı, stabilite, deprem etkisi, sehim sınırı ve detaylandırma kontrolleri dahil değildir."

func _append_history(result: Dictionary) -> void:
    var file: FileAccess
    if FileAccess.file_exists(HISTORY_PATH):
        file = FileAccess.open(HISTORY_PATH, FileAccess.READ_WRITE)
        if file != null:
            file.seek_end()
    else:
        file = FileAccess.open(HISTORY_PATH, FileAccess.WRITE)
    if file == null:
        return
    file.store_line(JSON.stringify(result))
    file.close()
