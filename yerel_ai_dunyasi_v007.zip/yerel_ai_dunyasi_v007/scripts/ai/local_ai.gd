extends RefCounted
class_name LocalAI

var native_backend = null

func _init() -> void:
    if Engine.has_singleton("YerelAIBackend"):
        native_backend = Engine.get_singleton("YerelAIBackend")

func has_native_backend() -> bool:
    return native_backend != null

func is_native_ready() -> bool:
    if native_backend == null:
        return false
    if native_backend.has_method("isModelLoaded"):
        return bool(native_backend.call("isModelLoaded"))
    return false


func supports_model_picker() -> bool:
    return native_backend != null and native_backend.has_method("pickModel")

func pick_model() -> bool:
    if not supports_model_picker():
        return false
    return bool(native_backend.call("pickModel"))

func get_native_backend():
    return native_backend


func get_runtime_diagnostics() -> Dictionary:
    if native_backend == null or not native_backend.has_method("getRuntimeDiagnostics"):
        return {"ok": false, "error": "Android YerelAIBackend tanı bilgisi kullanılamıyor."}
    var raw = native_backend.call("getRuntimeDiagnostics")
    if raw is String:
        var parsed = JSON.parse_string(str(raw))
        if parsed is Dictionary:
            return parsed
    return {"ok": false, "error": "Tanı bilgisi okunamadı."}

func inspect_model(path: String) -> Dictionary:
    if native_backend == null or not native_backend.has_method("inspectModel"):
        if FileAccess.file_exists(path):
            return {"ok": true, "valid_gguf": path.get_extension().to_lower() == "gguf", "path": path}
        return {"ok": false, "error": "Model dosyası bulunamadı."}
    var raw = native_backend.call("inspectModel", path)
    if raw is String:
        var parsed = JSON.parse_string(str(raw))
        if parsed is Dictionary:
            return parsed
    return {"ok": false, "error": "GGUF doğrulama sonucu okunamadı."}

func get_backend_info() -> String:
    if native_backend == null:
        return "Demo altyapısı · Android YerelAIBackend eklentisi bulunamadı"
    if native_backend.has_method("getBackendInfo"):
        return str(native_backend.call("getBackendInfo"))
    return "YerelAIBackend bulundu"

func load_model(path: String) -> Dictionary:
    if native_backend == null:
        return {"ok": false, "error": "Android YerelAIBackend eklentisi yüklü değil."}
    if not native_backend.has_method("loadModel"):
        return {"ok": false, "error": "YerelAIBackend.loadModel() bulunamadı."}
    var result = native_backend.call("loadModel", path)
    if result is bool:
        return {"ok": bool(result), "error": "" if bool(result) else "Model yüklenemedi."}
    if result is String:
        var text := str(result)
        var parsed = JSON.parse_string(text)
        if parsed is Dictionary:
            return parsed
        if text.begins_with("ERROR:"):
            return {"ok": false, "error": text.trim_prefix("ERROR:").strip_edges()}
        return {"ok": true, "message": text}
    return {"ok": is_native_ready(), "error": "" if is_native_ready() else "Model yüklenemedi."}

func unload_model() -> void:
    if native_backend != null and native_backend.has_method("unloadModel"):
        native_backend.call("unloadModel")

func ask(system_prompt: String, user_message: String, context: Array, generation_settings: Dictionary = {}) -> Dictionary:
    if is_native_ready() and native_backend.has_method("generate"):
        var payload := {
            "system": system_prompt,
            "message": user_message,
            "context": context,
            "generation": generation_settings
        }
        var raw = native_backend.call("generate", JSON.stringify(payload))
        if raw is String:
            var text := str(raw)
            var parsed = JSON.parse_string(text)
            if parsed is Dictionary and parsed.has("ok"):
                return parsed
            if text.begins_with("ERROR:"):
                return {"ok": false, "error": text.trim_prefix("ERROR:").strip_edges()}
            return {"ok": true, "text": text, "backend": "llama.cpp"}
        return {"ok": false, "error": "Yerel backend geçersiz yanıt döndürdü."}
    return {
        "ok": true,
        "text": _offline_demo_response(system_prompt, user_message),
        "backend": "demo"
    }

func _offline_demo_response(system_prompt: String, user_message: String) -> String:
    var role := "Genel Yerel Zekâ"
    if "KOORDİNATÖR" in system_prompt:
        role = "Koordinatör"
    elif "İNŞAAT MÜHENDİSİ" in system_prompt:
        role = "İnşaat Mühendisi"
    elif "MAKİNE MÜHENDİSİ" in system_prompt:
        role = "Makine Mühendisi"
    elif "ELEKTRİK-ELEKTRONİK" in system_prompt:
        role = "Elektrik-Elektronik Mühendisi"
    elif "İÇ MİMAR" in system_prompt:
        role = "İç Mimar"
    elif "PEYZAJ" in system_prompt:
        role = "Peyzaj Mimarı"
    elif "MEVZUAT" in system_prompt:
        role = "Mevzuat Uzmanı"
    elif "MİMAR" in system_prompt:
        role = "Mimar"

    return "%s olarak mesajını aldım: “%s”\n\nŞu anda dünya ve ajan sistemi gerçek çalışma kuyruğunu kullanıyor; ancak bu cihazda gerçek GGUF modeli yüklenmediği için demo yanıtı gösteriyorum. MODEL ekranından doğrulanmış bir GGUF seçip YerelAIBackend eklentisiyle yüklediğinde aynı konuşma zinciri gerçek cihaz-içi modele gider." % [role, user_message]
