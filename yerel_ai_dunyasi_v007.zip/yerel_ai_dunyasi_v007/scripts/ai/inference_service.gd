extends Node

signal state_changed(state: String)
signal model_load_finished(ok: bool, message: String)
signal request_started(request_id: int, meta: Dictionary)
signal request_completed(request_id: int, result: Dictionary, meta: Dictionary)
signal request_failed(request_id: int, error: String, meta: Dictionary)
signal model_imported(path: String, display_name: String)
signal model_import_progress(progress: String, detail: String)
signal model_import_failed(error: String)
signal self_test_finished(ok: bool, message: String)

const LocalAIClass = preload("res://scripts/ai/local_ai.gd")

var _ai
var _queue: Array[Dictionary] = []
var _busy := false
var _thread: Thread = null
var _request_counter := 0
var _state := "idle"
var _model_loaded := false
var _backend_info := ""
var _active_model_path := ""

func _ready() -> void:
    _ai = LocalAIClass.new()
    _model_loaded = _ai.is_native_ready()
    _backend_info = _ai.get_backend_info()
    _state = "ready" if _model_loaded else "demo"
    _bind_native_backend_signals()

func get_state() -> String:
    return _state

func is_model_loaded() -> bool:
    return _model_loaded

func get_backend_info() -> String:
    return _backend_info

func get_active_model_path() -> String:
    return _active_model_path


func supports_native_model_picker() -> bool:
    return _ai != null and _ai.supports_model_picker()

func request_native_model_picker() -> bool:
    if not supports_native_model_picker():
        return false
    return _ai.pick_model()

func _bind_native_backend_signals() -> void:
    if _ai == null:
        return
    var backend = _ai.get_native_backend()
    if backend == null:
        return
    if backend.has_signal("modelImported") and not backend.is_connected("modelImported", _on_native_model_imported):
        backend.connect("modelImported", _on_native_model_imported)
    if backend.has_signal("modelImportProgress") and not backend.is_connected("modelImportProgress", _on_native_model_import_progress):
        backend.connect("modelImportProgress", _on_native_model_import_progress)
    if backend.has_signal("modelImportFailed") and not backend.is_connected("modelImportFailed", _on_native_model_import_failed):
        backend.connect("modelImportFailed", _on_native_model_import_failed)

func _on_native_model_imported(path: String, display_name: String) -> void:
    ModelManager.set_selected_model(path, display_name)
    model_imported.emit(path, display_name)

func _on_native_model_import_progress(progress: String, detail: String) -> void:
    model_import_progress.emit(progress, detail)

func _on_native_model_import_failed(error: String) -> void:
    model_import_failed.emit(error)


func get_runtime_diagnostics() -> Dictionary:
    if _ai == null:
        return {"ok": false, "error": "Yerel AI katmanı başlatılmadı."}
    return _ai.get_runtime_diagnostics()

func inspect_selected_model() -> Dictionary:
    if _ai == null:
        return {"ok": false, "error": "Yerel AI katmanı başlatılmadı."}
    var path := ModelManager.get_model_path()
    if path.is_empty():
        return {"ok": false, "error": "Henüz bir GGUF model seçilmedi."}
    return _ai.inspect_model(path)

func run_self_test() -> int:
    if not _model_loaded:
        self_test_finished.emit(false, "Önce yerel modeli yükle.")
        return -1
    return request_generation(
        "core",
        "Yalnızca Türkçe yanıt ver. Bu bir cihaz içi yerel model doğrulama testidir.",
        "Tek satırda tam olarak şu ifadeyle başla: YEREL AI HAZIR. Ardından en fazla beş Türkçe kelime yaz.",
        [],
        {"max_tokens": 48, "temperature": 0.0},
        {"kind": "self_test"}
    )

func request_generation(agent_id: String, system_prompt: String, message: String, context: Array, generation_settings: Dictionary, meta: Dictionary = {}) -> int:
    _request_counter += 1
    var request_id := _request_counter
    var merged_meta := meta.duplicate(true)
    merged_meta["agent_id"] = agent_id
    _queue.append({
        "kind": "generate",
        "request_id": request_id,
        "agent_id": agent_id,
        "system": system_prompt,
        "message": message,
        "context": context.duplicate(true),
        "generation": generation_settings.duplicate(true),
        "meta": merged_meta
    })
    _pump()
    return request_id

func load_model(path: String) -> void:
    if path.strip_edges().is_empty():
        model_load_finished.emit(false, "Önce bir GGUF model seç.")
        return
    _queue.append({"kind": "load_model", "path": path})
    _pump()

func unload_model() -> void:
    if _busy:
        _queue.append({"kind": "unload_model"})
        return
    _ai.unload_model()
    _model_loaded = false
    _active_model_path = ""
    _set_state("demo")
    model_load_finished.emit(true, "Model bellekten çıkarıldı.")

func _pump() -> void:
    if _busy or _queue.is_empty():
        return
    _busy = true
    var job: Dictionary = _queue.pop_front()
    if str(job.get("kind", "")) == "generate":
        request_started.emit(int(job["request_id"]), job["meta"])
        _set_state("generating")
    elif str(job.get("kind", "")) == "load_model":
        _set_state("loading_model")
    elif str(job.get("kind", "")) == "unload_model":
        _set_state("unloading_model")

    _thread = Thread.new()
    var err := _thread.start(_run_job.bind(job))
    if err != OK:
        _thread = null
        _busy = false
        _finish_start_error(job, "İş parçacığı başlatılamadı: %s" % error_string(err))
        _pump()

func _run_job(job: Dictionary) -> void:
    var kind := str(job.get("kind", ""))
    var result: Dictionary
    match kind:
        "generate":
            result = _ai.ask(
                str(job["system"]),
                str(job["message"]),
                job["context"],
                job["generation"]
            )
        "load_model":
            result = _ai.load_model(str(job["path"]))
        "unload_model":
            _ai.unload_model()
            result = {"ok": true}
        _:
            result = {"ok": false, "error": "Bilinmeyen inference işi."}
    call_deferred("_finish_job", job, result)

func _finish_job(job: Dictionary, result: Dictionary) -> void:
    if _thread != null:
        _thread.wait_to_finish()
        _thread = null

    var kind := str(job.get("kind", ""))
    if kind == "generate":
        var request_id := int(job["request_id"])
        var meta: Dictionary = job["meta"]
        if bool(result.get("ok", false)):
            request_completed.emit(request_id, result, meta)
            if str(meta.get("kind", "")) == "self_test":
                var text := str(result.get("text", "")).strip_edges()
                var passed := text.to_upper().begins_with("YEREL AI HAZIR")
                self_test_finished.emit(passed, text if passed else "Model yanıt verdi ancak Türkçe hazır olma testi beklenen biçimde geçmedi: %s" % text)
        else:
            var error_text := str(result.get("error", "Bilinmeyen model hatası"))
            request_failed.emit(request_id, error_text, meta)
            if str(meta.get("kind", "")) == "self_test":
                self_test_finished.emit(false, error_text)
        _set_state("ready" if _model_loaded else "demo")
    elif kind == "load_model":
        if bool(result.get("ok", false)):
            _model_loaded = _ai.is_native_ready()
            _active_model_path = str(job["path"]) if _model_loaded else ""
            _backend_info = _ai.get_backend_info()
            _set_state("ready" if _model_loaded else "demo")
            model_load_finished.emit(_model_loaded, "Model yüklendi: %s" % str(job["path"]).get_file())
        else:
            _model_loaded = false
            _set_state("demo")
            model_load_finished.emit(false, str(result.get("error", "Model yüklenemedi.")))
    elif kind == "unload_model":
        _model_loaded = false
        _active_model_path = ""
        _set_state("demo")
        model_load_finished.emit(true, "Model bellekten çıkarıldı.")

    _busy = false
    _pump()

func _finish_start_error(job: Dictionary, message: String) -> void:
    if str(job.get("kind", "")) == "generate":
        var meta: Dictionary = job["meta"]
        request_failed.emit(int(job["request_id"]), message, meta)
        if str(meta.get("kind", "")) == "self_test":
            self_test_finished.emit(false, message)
    else:
        model_load_finished.emit(false, message)
    _set_state("ready" if _model_loaded else "demo")

func _set_state(value: String) -> void:
    _state = value
    state_changed.emit(value)

func _exit_tree() -> void:
    if _thread != null and _thread.is_started():
        _thread.wait_to_finish()
