extends Node

signal reply_started(agent_id: String, request_id: int)
signal reply_completed(agent_id: String, text: String, request_id: int)
signal reply_failed(agent_id: String, error: String, request_id: int)
signal meeting_progress(session_id: int, text: String)
signal meeting_completed(session_id: int, text: String)

var _meeting_counter := 0
var _meeting_sessions: Dictionary = {}

const GLOBAL_RULES := """
DİL KURALI:
- Kullanıcı açıkça başka bir dil istemedikçe yalnızca Türkçe konuş ve yaz.
- Arayüzden gelen teknik İngilizce terimleri gerektiğinde Türkçe açıklamayla ve özgün adını parantez içinde ver.
- Cevapta gereksiz İngilizce başlıklar veya kalıp ifadeler kullanma.

ORTAK ÇALIŞMA KURALLARI:
- Kullanıcının cihazında çalışan yerel profesyonel ekip üyesisin.
- Bilmediğin veya doğrulayamadığın bilgiyi kesinmiş gibi söyleme.
- Sayısal mühendislik sonucunu salt dil modeli tahminiyle nihai hesap olarak sunma; gerekli girdileri, varsayımları ve doğrulama ihtiyacını açıkla.
- Mevzuat/standart yanıtlarında sürüm, tarih ve kaynak doğrulaması gerektiğini gözet.
- Disiplinler arası bir çakışma görürsen ilgili uzmanı veya koordinatörü devreye sokmayı öner.
- Gereksiz uzunluk yerine uygulanabilir seçenekler, riskler ve sonraki adımlar üret.
"""

var profiles: Dictionary = {
    "core": {
        "name": "Genel Yerel Zekâ",
        "role": "Tüm sisteme doğrudan erişim sağlayan genel yardımcı",
        "prompt": "Sen kullanıcının cihazında çalışan GENEL YEREL YAPAY ZEKÂ çekirdeğisin. Sorunun hangi uzmanlığı gerektirdiğini ayırt et; gerektiğinde uzman ajanlara yönlendir veya koordinatör toplantısı öner."
    },
    "coordinator": {
        "name": "Koordinatör",
        "role": "Uzman ekibi koordine eder, toplantı düzenler ve sonuçları toparlar",
        "prompt": "Sen üst düzey bir PROJE KOORDİNATÖRÜSÜN. Mimar, inşaat, makine, elektrik-elektronik, iç mimari, peyzaj, genel mevzuat ve ihale/sözleşme disiplinlerini yönet. Çakışmaları, bağımlılıkları, açık kararları ve kullanıcıdan beklenen seçimleri kısa ve net biçimde ayır."
    },
    "architect": {
        "name": "Mimar",
        "role": "Mimari tasarım ve proje geliştirme",
        "prompt": "Sen çok deneyimli bir MİMARSIN. İşlev, dolaşım, mekânsal kalite, cephe, oran, erişilebilirlik, yapım yöntemi ve diğer mühendislik disiplinleriyle koordinasyonu birlikte değerlendir."
    },
    "civil": {
        "name": "İnşaat Mühendisi",
        "role": "Taşıyıcı sistem, yapı ve uygulama danışmanı",
        "prompt": "Sen kıdemli bir İNŞAAT MÜHENDİSİSİN. Taşıyıcı sistem davranışı, yük yolu, stabilite, deprem etkileri, temel-zemin etkileşimi, betonarme/çelik detayları, uygulanabilirlik ve şantiye gerçekliğini birlikte düşün. Hesap gerektiren konuda bilinmeyen girdileri önce belirle; nihai boyutlandırmayı doğrulanmış hesap motoru ve geçerli mevzuat olmadan kesinleştirme."
    },
    "mechanical": {
        "name": "Makine Mühendisi",
        "role": "HVAC, sıhhi tesisat, yangın ve mekanik sistemler",
        "prompt": "Sen kıdemli bir MAKİNE MÜHENDİSİSİN. HVAC, sıhhi tesisat, yangın tesisatı, enerji, şaftlar, ekipman hacimleri, bakım erişimi ve mimari/strüktürel koordinasyonu değerlendir."
    },
    "electrical": {
        "name": "Elektrik-Elektronik Mühendisi",
        "role": "Elektrik, zayıf akım, otomasyon ve enerji sistemleri",
        "prompt": "Sen kıdemli bir ELEKTRİK-ELEKTRONİK MÜHENDİSİSİN. Kuvvetli/zayıf akım, dağıtım, aydınlatma, topraklama, yıldırımdan korunma, otomasyon, güvenlik, yedekleme ve enerji sürekliliğini değerlendir."
    },
    "interior": {
        "name": "İç Mimar",
        "role": "İç mekân, malzeme, ergonomi ve kullanıcı deneyimi",
        "prompt": "Sen deneyimli bir İÇ MİMARSIN. İç mekân kurgusu, ergonomi, mobilya, malzeme, aydınlatma, akustik, detay çözümü ve kullanım senaryolarına odaklan."
    },
    "landscape": {
        "name": "Peyzaj Mimarı",
        "role": "Açık alan, topoğrafya, bitkilendirme ve çevre tasarımı",
        "prompt": "Sen deneyimli bir PEYZAJ MİMARISIN. Açık alan kullanımı, topoğrafya, iklim, drenaj, su yönetimi, bitkilendirme, erişilebilirlik ve bakım gereksinimlerini birlikte düşün."
    },
    "regulations": {
        "name": "Mevzuat Uzmanı",
        "role": "Yönetmelik, standart ve ruhsat süreçleri araştırması",
        "prompt": "Sen bir MEVZUAT UZMANISIN. Kaynağı ve güncelliği doğrulanmamış mevzuat maddesini kesin hüküm gibi sunma. Uygun olduğunda belge adı, madde, yürürlük tarihi ve doğrulanması gereken resmi kaynağı belirt."
    },
    "procurement": {
        "name": "İhale ve Sözleşme Uzmanı",
        "role": "Kamu ihale mevzuatı, KİK kararları, YFK karar/görüşleri ve yapım sözleşmesi uygulamaları",
        "prompt": "Sen kıdemli bir İHALE VE SÖZLEŞME UZMANISIN. Özellikle 4734 sayılı Kamu İhale Kanunu, 4735 sayılı Kamu İhale Sözleşmeleri Kanunu, ikincil mevzuat, Yapım İşleri Genel Şartnamesi, KİK Kurul kararları ve Yüksek Fen Kurulu karar/görüşleri üzerinde çalışırsın. İhale öncesi/ihale süreci ile sözleşmenin uygulanması safhasını birbirinden ayır. KİK kararı ile YFK karar/görüşünü aynı hukuki nitelikteymiş gibi sunma. Somut olay ile emsal karar arasında benzerlik ve farkları açıkla. Yerel karar arşivinde bulunmayan karar numarası, tarih, madde veya sonuç uydurma. Bir karara dayanıyorsan [KİK N: ...], [YFK N: ...] veya [MEVZUAT N: ...] kaynak etiketini aynen kullan. Arşiv kapsamı yetersizse bunu açıkça söyle; resmi kaynaktan güncellik doğrulaması gerektiğini belirt."
    }
}

func _ready() -> void:
    InferenceService.request_completed.connect(_on_request_completed)
    InferenceService.request_failed.connect(_on_request_failed)

func get_profile(agent_id: String) -> Dictionary:
    return profiles.get(agent_id, profiles["core"])

func ask_async(agent_id: String, message: String) -> int:
    var profile := get_profile(agent_id)
    # Mevcut mesajı context'e iki kez sokmamak için geçmişi önce al.
    var context := MemoryStore.get_recent(agent_id, 12)
    MemoryStore.append_message(agent_id, "user", message)
    var rag_context := _build_agent_context(agent_id, message, 6)
    var system_prompt := _build_system_prompt(profile, rag_context, agent_id)
    var request_id := InferenceService.request_generation(
        agent_id,
        system_prompt,
        message,
        context,
        ModelManager.get_generation_settings(),
        {"kind": "chat", "user_message": message, "tool_round": 0}
    )
    reply_started.emit(agent_id, request_id)
    return request_id

func start_meeting(topic: String) -> int:
    _meeting_counter += 1
    var session_id := _meeting_counter
    var participants := ["architect", "civil", "mechanical", "electrical", "interior", "landscape", "regulations"]
    if _is_procurement_topic(topic):
        participants.append("procurement")
    _meeting_sessions[session_id] = {
        "topic": topic,
        "participants": participants,
        "pending": participants.size(),
        "responses": {},
        "failed": []
    }
    meeting_progress.emit(session_id, "Koordinatör toplantıyı açtı. %d uzman ayrı ayrı incelemeye başladı." % participants.size())

    for agent_id in participants:
        var profile := get_profile(agent_id)
        var meeting_message := """Disiplinler arası proje toplantısındasın.
Toplantı konusu: %s

Sadece kendi disiplinin açısından şu dört başlıkta kısa bir ön değerlendirme hazırla:
1) Kritik bulgular
2) Eksik bilgi/girdi
3) Diğer disiplinlerle olası çakışmalar
4) Önerdiğin sonraki adım
""" % topic
        var rag_context := _build_agent_context(agent_id, topic, 6)
        InferenceService.request_generation(
            agent_id,
            _build_system_prompt(profile, rag_context, agent_id),
            meeting_message,
            [],
            ModelManager.get_generation_settings(),
            {"kind": "meeting_expert", "session_id": session_id, "participant_id": agent_id, "topic": topic, "meeting_message": meeting_message, "tool_round": 0}
        )
    return session_id

func _on_request_completed(request_id: int, result: Dictionary, meta: Dictionary) -> void:
    var kind := str(meta.get("kind", "chat"))
    var text := str(result.get("text", ""))
    if kind == "chat":
        var agent_id := str(meta.get("agent_id", "core"))
        var tool_call := EngineeringTools.parse_tool_call(text)
        if not tool_call.is_empty():
            _handle_chat_tool_call(agent_id, tool_call, meta)
            return
        MemoryStore.append_message(agent_id, "assistant", text)
        reply_completed.emit(agent_id, text, request_id)
        return

    if kind == "meeting_expert":
        var session_id := int(meta.get("session_id", -1))
        var participant_id := str(meta.get("participant_id", "core"))
        var tool_call := EngineeringTools.parse_tool_call(text)
        if not tool_call.is_empty():
            _handle_meeting_tool_call(session_id, participant_id, tool_call, meta)
            return
        if not _meeting_sessions.has(session_id):
            return
        var session: Dictionary = _meeting_sessions[session_id]
        session["responses"][participant_id] = text
        session["pending"] = maxi(0, int(session["pending"]) - 1)
        var p := get_profile(participant_id)
        meeting_progress.emit(session_id, "%s raporunu tamamladı." % p["name"])
        _meeting_sessions[session_id] = session
        if int(session["pending"]) == 0:
            _queue_meeting_synthesis(session_id)
        return

    if kind == "meeting_synthesis":
        var session_id := int(meta.get("session_id", -1))
        if not _meeting_sessions.has(session_id):
            return
        var session: Dictionary = _meeting_sessions[session_id]
        var topic := str(session["topic"])
        MemoryStore.append_message("coordinator", "user", "Uzman toplantısı: " + topic)
        MemoryStore.append_message("coordinator", "assistant", text)
        meeting_completed.emit(session_id, text)
        _meeting_sessions.erase(session_id)

func _handle_chat_tool_call(agent_id: String, tool_call: Dictionary, meta: Dictionary) -> void:
    var tool_round := int(meta.get("tool_round", 0))
    if tool_round >= 2:
        reply_failed.emit(agent_id, "Mühendislik aracı art arda çok kez çağrıldı. Girdileri kontrol et.", -1)
        return
    if tool_call.has("_parse_error"):
        reply_failed.emit(agent_id, str(tool_call["_parse_error"]), -1)
        return
    var tool_id := str(tool_call.get("tool", ""))
    var args = tool_call.get("args", {})
    if typeof(args) != TYPE_DICTIONARY:
        args = {}
    var original_message := str(meta.get("user_message", ""))
    var tool_result := EngineeringTools.run_tool(tool_id, args, agent_id, original_message)
    var rag_context := _build_agent_context(agent_id, original_message, 6)
    var followup := """Kullanıcının asıl sorusu:
%s

YEREL MÜHENDİSLİK ARACI SONUCU:
%s

Bu araç sonucunu kontrol edilmiş sayısal girdi olarak kullan. Türkçe yanıtla. Sonuçtaki varsayımları ve sınırı saklama; özellikle bunun mevzuata göre nihai yeterlilik kontrolü olmadığını gerekiyorsa açıkça belirt. Araç hata verdiyse kullanıcıdan eksik veya düzeltilmesi gereken girdiyi iste.
""" % [original_message, EngineeringTools.format_result_for_ai(tool_result)]
    var new_id := InferenceService.request_generation(
        agent_id,
        _build_system_prompt(get_profile(agent_id), rag_context, agent_id),
        followup,
        [],
        ModelManager.get_generation_settings(),
        {"kind":"chat", "user_message":original_message, "tool_round":tool_round + 1, "tool_used":tool_id}
    )
    reply_started.emit(agent_id, new_id)

func _handle_meeting_tool_call(session_id: int, participant_id: String, tool_call: Dictionary, meta: Dictionary) -> void:
    if not _meeting_sessions.has(session_id):
        return
    var tool_round := int(meta.get("tool_round", 0))
    if tool_round >= 1 or tool_call.has("_parse_error"):
        var session: Dictionary = _meeting_sessions[session_id]
        session["responses"][participant_id] = "Hesap aracı çağrısı tamamlanamadı; uzman bu kalemi doğrulanması gereken hesap olarak işaretledi."
        session["pending"] = maxi(0, int(session["pending"]) - 1)
        _meeting_sessions[session_id] = session
        if int(session["pending"]) == 0:
            _queue_meeting_synthesis(session_id)
        return
    var args = tool_call.get("args", {})
    if typeof(args) != TYPE_DICTIONARY:
        args = {}
    var tool_id := str(tool_call.get("tool", ""))
    var topic := str(meta.get("topic", ""))
    var tool_result := EngineeringTools.run_tool(tool_id, args, participant_id, topic)
    var original_request := str(meta.get("meeting_message", ""))
    var followup := """Toplantıdaki asıl uzmanlık görevin:
%s

YEREL MÜHENDİSLİK ARACI SONUCU:
%s

Bu sonucu kullanarak kendi disiplin raporunu Türkçe tamamla. Varsayımları ve hesabın kapsam sınırlarını belirt.
""" % [original_request, EngineeringTools.format_result_for_ai(tool_result)]
    meeting_progress.emit(session_id, "%s yerel hesap aracını kullandı; raporunu tamamlıyor." % get_profile(participant_id)["name"])
    InferenceService.request_generation(
        participant_id,
        _build_system_prompt(get_profile(participant_id), _build_agent_context(participant_id, topic, 6), participant_id),
        followup,
        [],
        ModelManager.get_generation_settings(),
        {"kind":"meeting_expert", "session_id":session_id, "participant_id":participant_id, "topic":topic, "meeting_message":original_request, "tool_round":tool_round + 1}
    )

func _on_request_failed(request_id: int, error: String, meta: Dictionary) -> void:
    var kind := str(meta.get("kind", "chat"))
    if kind == "chat":
        var agent_id := str(meta.get("agent_id", "core"))
        reply_failed.emit(agent_id, error, request_id)
        return
    if kind == "meeting_expert":
        var session_id := int(meta.get("session_id", -1))
        var participant_id := str(meta.get("participant_id", "core"))
        if not _meeting_sessions.has(session_id):
            return
        var session: Dictionary = _meeting_sessions[session_id]
        session["failed"].append(participant_id)
        session["responses"][participant_id] = "[Rapor üretilemedi: %s]" % error
        session["pending"] = maxi(0, int(session["pending"]) - 1)
        _meeting_sessions[session_id] = session
        meeting_progress.emit(session_id, "%s raporunda hata oluştu." % get_profile(participant_id)["name"])
        if int(session["pending"]) == 0:
            _queue_meeting_synthesis(session_id)
        return
    if kind == "meeting_synthesis":
        var session_id := int(meta.get("session_id", -1))
        meeting_completed.emit(session_id, "Koordinatör nihai özeti oluşturamadı: %s" % error)
        _meeting_sessions.erase(session_id)

func _queue_meeting_synthesis(session_id: int) -> void:
    if not _meeting_sessions.has(session_id):
        return
    var session: Dictionary = _meeting_sessions[session_id]
    var combined: Array[String] = []
    for participant_id in session["participants"]:
        var p := get_profile(str(participant_id))
        var report := str(session["responses"].get(participant_id, "Rapor yok"))
        combined.append("## %s\n%s" % [p["name"], report])

    var synthesis_message := """Aşağıdaki disiplin raporlarını proje koordinatörü olarak sentezle.
Toplantı konusu: %s

%s

Nihai çıktı şu sırada olsun:
- En kritik 3-7 konu
- Disiplinler arası çakışmalar
- Kullanıcıdan karar bekleyen maddeler
- Bir sonraki çalışma sırası
- Doğrulanması gereken hesap/mevzuat maddeleri
""" % [str(session["topic"]), "\n\n".join(combined)]

    meeting_progress.emit(session_id, "Tüm uzman raporları toplandı; koordinatör ortak sonucu hazırlıyor.")
    InferenceService.request_generation(
        "coordinator",
        _build_system_prompt(get_profile("coordinator"), _build_agent_context("coordinator", str(session["topic"]), 8), "coordinator"),
        synthesis_message,
        [],
        ModelManager.get_generation_settings(),
        {"kind": "meeting_synthesis", "session_id": session_id}
    )

func _build_agent_context(agent_id: String, query: String, project_limit: int = 6) -> String:
    var parts: Array[String] = []
    var project_context := ProjectStore.build_rag_context(query, project_limit)
    if not project_context.strip_edges().is_empty():
        parts.append(project_context)
    if agent_id in ["procurement", "coordinator", "core"] or _is_procurement_topic(query):
        var procurement_context := ProcurementKnowledge.build_context(query, 10)
        if not procurement_context.strip_edges().is_empty():
            parts.append(procurement_context)
    return "\n\n".join(parts)

func _is_procurement_topic(text: String) -> bool:
    var normalized := text.to_lower()
    var keys := [
        "ihale", "kik", "ekap", "yüksek fen", "yfk", "4734", "4735", "hakediş", "hakedis",
        "fiyat fark", "yeni fiyat", "iş artış", "is artis", "süre uzat", "sure uzat", "gecikme ceza",
        "itirazen", "şikayet", "sikayet", "aşırı düşük", "asiri dusuk", "yasaklı", "yasakli", "sözleşme", "sozlesme"
    ]
    for key in keys:
        if key in normalized:
            return true
    return false

func _build_system_prompt(profile: Dictionary, rag_context: String = "", agent_id: String = "core") -> String:
    var project := ProjectStore.get_active_project()
    var project_name := str(project.get("name", "Aktif proje yok")) if not project.is_empty() else "Aktif proje yok"
    var source_rules := """
PROJE VE KAYNAK KURALLARI:
- Aktif proje: %s
- Aşağıda proje bilgi tabanı parçaları verilmişse önce onları kullan.
- Belgeden bir bilgiye dayanıyorsan cevabında ilgili [Kaynak N: ...] etiketini aynen belirt.
- Kaynak parçasında bulunmayan bilgiyi belgede varmış gibi gösterme.
- Kaynaklar yetersizse bunu açıkça söyle ve hangi belgenin/girdinin gerektiğini belirt.
""" % project_name
    var procurement_rules := ""
    if agent_id in ["procurement", "coordinator", "core"]:
        procurement_rules = """
İHALE / SÖZLEŞME KAYNAK KURALLARI:
- %s
- Yerel arşivin eksik olması bir kararın mevcut olmadığı anlamına gelmez.
- KİK/YFK karar numarası veya tarihi yalnızca kaynak bağlamında açıkça bulunuyorsa kesin olarak söyle.
- Mevzuatın güncel halini ve olay tarihindeki yürürlük durumunu birbirinden ayır.
- Cevabın sonunda gerekiyorsa resmi kaynakta güncellik doğrulaması yapılması gerektiğini belirt.
""" % ProcurementKnowledge.archive_coverage_text()
    var parts: Array[String] = [str(profile.get("prompt", "")), GLOBAL_RULES, source_rules]
    if not procurement_rules.is_empty():
        parts.append(procurement_rules)
    var tool_rules := EngineeringTools.get_agent_tool_instructions(agent_id)
    if not tool_rules.strip_edges().is_empty():
        parts.append(tool_rules)
    if not rag_context.strip_edges().is_empty():
        parts.append(rag_context)
    return "\n\n".join(parts)
