extends Node

signal import_started(display_name: String)
signal import_finished(ok: bool, message: String, document_id: String)
signal procurement_import_started(display_name: String, source_kind: String)
signal procurement_import_finished(ok: bool, message: String, document_id: String, source_kind: String)
signal native_picker_state(message: String)

var _backend = null
var _thread: Thread = null
var _busy := false
var _pending_target := "project"
var _pending_source_kind := "other"

func _ready() -> void:
    if Engine.has_singleton("YerelAIBackend"):
        _backend = Engine.get_singleton("YerelAIBackend")
        if _backend.has_signal("documentImported"):
            _backend.connect("documentImported", _on_native_document_imported)
        if _backend.has_signal("documentImportFailed"):
            _backend.connect("documentImportFailed", _on_native_document_failed)

func supports_native_picker() -> bool:
    return _backend != null and _backend.has_method("pickDocument")

func request_native_picker() -> bool:
    return _request_native_picker_for("project", "other")

func request_native_procurement_picker(source_kind: String) -> bool:
    return _request_native_picker_for("procurement", source_kind)

func _request_native_picker_for(target: String, source_kind: String) -> bool:
    if not supports_native_picker():
        return false
    if _busy:
        _emit_target_error(target, "Başka bir belge içe aktarılıyor.", source_kind)
        return false
    _pending_target = target
    _pending_source_kind = source_kind
    native_picker_state.emit("Android belge seçici açıldı.")
    return bool(_backend.call("pickDocument"))

func import_desktop_file(path: String) -> void:
    _import_desktop_file_for(path, "project", "other")

func import_procurement_desktop_file(path: String, source_kind: String) -> void:
    _import_desktop_file_for(path, "procurement", source_kind)

func _import_desktop_file_for(path: String, target: String, source_kind: String) -> void:
    if _busy:
        _emit_target_error(target, "Başka bir belge içe aktarılıyor.", source_kind)
        return
    var extension := path.get_extension().to_lower()
    if extension == "pdf":
        _emit_target_error(target, "Masaüstü PDF çıkarımı bu prototipte etkin değil. Android sürümünde PDF cihaz içinde okunur. TXT/MD/CSV/JSON dosyaları masaüstünde doğrudan desteklenir.", source_kind)
        return
    if extension not in ["txt", "md", "csv", "json"]:
        _emit_target_error(target, "Desteklenmeyen belge türü: .%s" % extension, source_kind)
        return
    _busy = true
    _pending_target = target
    _pending_source_kind = source_kind
    if target == "procurement":
        procurement_import_started.emit(path.get_file(), source_kind)
    else:
        import_started.emit(path.get_file())
    _thread = Thread.new()
    var err := _thread.start(_read_text_worker.bind(path, target, source_kind))
    if err != OK:
        _busy = false
        _thread = null
        _emit_target_error(target, "Belge okuma iş parçacığı başlatılamadı: %s" % error_string(err), source_kind)

func _read_text_worker(path: String, target: String, source_kind: String) -> void:
    var result := {"ok": false, "path": path, "name": path.get_file(), "mime": "text/plain", "text": "", "error": "", "target": target, "source_kind": source_kind}
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        result["error"] = "Dosya açılamadı."
    else:
        var text := file.get_as_text()
        if text.length() > 20_000_000:
            text = text.left(20_000_000)
        result["ok"] = true
        result["text"] = text
    call_deferred("_finish_desktop_read", result)

func _finish_desktop_read(result: Dictionary) -> void:
    if _thread != null:
        _thread.wait_to_finish()
        _thread = null
    _busy = false
    var target := str(result.get("target", "project"))
    var source_kind := str(result.get("source_kind", "other"))
    if not bool(result.get("ok", false)):
        _emit_target_error(target, str(result.get("error", "Belge okunamadı.")), source_kind)
        return
    _store_document(target, source_kind, str(result["path"]), str(result["name"]), str(result["mime"]), str(result["text"]))

func _on_native_document_imported(text_path: String, display_name: String, mime_type: String) -> void:
    if _busy:
        _emit_target_error(_pending_target, "Başka bir belge içe aktarılıyor.", _pending_source_kind)
        return
    _busy = true
    var target := _pending_target
    var source_kind := _pending_source_kind
    if target == "procurement":
        procurement_import_started.emit(display_name, source_kind)
    else:
        import_started.emit(display_name)
    _thread = Thread.new()
    var err := _thread.start(_read_native_text_worker.bind(text_path, display_name, mime_type, target, source_kind))
    if err != OK:
        _busy = false
        _thread = null
        _emit_target_error(target, "Belge indeksleme iş parçacığı başlatılamadı: %s" % error_string(err), source_kind)

func _read_native_text_worker(text_path: String, display_name: String, mime_type: String, target: String, source_kind: String) -> void:
    var result := {"ok": false, "path": text_path, "name": display_name, "mime": mime_type, "text": "", "error": "", "target": target, "source_kind": source_kind}
    var file := FileAccess.open(text_path, FileAccess.READ)
    if file == null:
        result["error"] = "İçe aktarılan belge metni açılamadı."
    else:
        var text := file.get_as_text()
        if text.length() > 20_000_000:
            text = text.left(20_000_000)
        result["ok"] = true
        result["text"] = text
    call_deferred("_finish_native_read", result)

func _finish_native_read(result: Dictionary) -> void:
    if _thread != null:
        _thread.wait_to_finish()
        _thread = null
    _busy = false
    var target := str(result.get("target", "project"))
    var source_kind := str(result.get("source_kind", "other"))
    if not bool(result.get("ok", false)):
        _emit_target_error(target, str(result.get("error", "Belge okunamadı.")), source_kind)
        return
    _store_document(target, source_kind, str(result["path"]), str(result["name"]), str(result["mime"]), str(result["text"]))

func _store_document(target: String, source_kind: String, source_path: String, display_name: String, mime_type: String, text: String) -> void:
    if target == "procurement":
        if display_name.get_extension().to_lower() == "json":
            var bundle_result := ProcurementKnowledge.add_bundle_json(text, source_kind)
            if bool(bundle_result.get("ok", false)):
                procurement_import_finished.emit(true, "%s karar paketi içe aktarıldı · %d belge · %d bilgi parçası." % [display_name, int(bundle_result.get("added", 0)), int(bundle_result.get("chunks", 0))], "bundle", source_kind)
                return
        var procurement_result := ProcurementKnowledge.add_document(display_name, source_kind, source_path, mime_type, text)
        if bool(procurement_result.get("ok", false)):
            procurement_import_finished.emit(true, "%s ihale bilgi arşivine eklendi · %d bilgi parçası oluşturuldu." % [display_name, int(procurement_result.get("chunks", 0))], str(procurement_result.get("document_id", "")), source_kind)
        else:
            procurement_import_finished.emit(false, str(procurement_result.get("error", "Belge ihale arşivine eklenemedi.")), "", source_kind)
        return

    var project_id := ProjectStore.get_active_project_id()
    var result := ProjectStore.add_document(project_id, display_name, source_path, mime_type, text)
    if bool(result.get("ok", false)):
        import_finished.emit(true, "%s projeye eklendi · %d bilgi parçası oluşturuldu." % [display_name, int(result.get("chunks", 0))], str(result.get("document_id", "")))
    else:
        import_finished.emit(false, str(result.get("error", "Belge projeye eklenemedi.")), "")

func _emit_target_error(target: String, message: String, source_kind: String) -> void:
    if target == "procurement":
        procurement_import_finished.emit(false, message, "", source_kind)
    else:
        import_finished.emit(false, message, "")

func _on_native_document_failed(error: String) -> void:
    _busy = false
    _emit_target_error(_pending_target, error, _pending_source_kind)

func _exit_tree() -> void:
    if _thread != null and _thread.is_started():
        _thread.wait_to_finish()

func get_pending_target() -> String:
    return _pending_target
