extends CharacterBody3D
class_name WorldPlayer

@export var speed := 5.0
var touch_input := Vector2.ZERO

func _physics_process(_delta: float) -> void:
    var input_vec := touch_input
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        input_vec.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        input_vec.x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        input_vec.y += 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        input_vec.y -= 1.0
    input_vec = input_vec.normalized()

    var direction := Vector3(input_vec.x, 0.0, -input_vec.y)
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= 18.0 * get_physics_process_delta_time()
    else:
        velocity.y = -0.2
    if direction.length() > 0.01:
        rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), 0.18)
    move_and_slide()

func set_touch_input(value: Vector2) -> void:
    touch_input = value
