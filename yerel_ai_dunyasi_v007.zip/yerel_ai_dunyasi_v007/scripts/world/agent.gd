extends Node3D
class_name WorldAgent

var agent_id := "core"
var display_name := "Uzman"
var role := ""

func setup(id: String, p_name: String, p_role: String, body_color: Color) -> void:
    agent_id = id
    display_name = p_name
    role = p_role

    var body := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.65
    body.mesh = capsule
    body.position.y = 0.9
    var material := StandardMaterial3D.new()
    material.albedo_color = body_color
    material.roughness = 0.8
    body.material_override = material
    add_child(body)

    var label := Label3D.new()
    label.text = display_name
    label.position = Vector3(0, 2.05, 0)
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.font_size = 28
    label.outline_size = 6
    add_child(label)
