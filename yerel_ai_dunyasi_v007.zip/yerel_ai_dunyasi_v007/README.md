# Yerel AI Dünyası v0.0.8

Android hedefli, oyun dünyası içinde uzman yapay zekâ ajanlarıyla çalışılan tamamen yerel yapay zekâ prototipi.

Bu sürümde temel ürün kuralı sabittir: **uygulamanın kullanıcıya dönük dili Türkçedir ve yapay zekâ ajanları varsayılan olarak yalnızca Türkçe yanıt verir.** Teknik terimler gerektiğinde özgün adlarıyla parantez içinde korunabilir.

## v0.0.8’da bulunanlar

- Dolaşılabilir 3B ofis/kampüs prototipi.
- Koordinatör, Mimar, İnşaat Mühendisi, Makine Mühendisi, Elektrik-Elektronik Mühendisi, İç Mimar, Peyzaj Mimarı, Mevzuat Uzmanı ve **İhale ve Sözleşme Uzmanı**.
- Dünyanın her yerinden erişilebilen Genel Yerel Zekâ.
- Tüm ajanlara uygulanan zorunlu Türkçe yanıt kuralı.
- Cihaz içinde kalıcı konuşma hafızası.
- Tek yerel GGUF modelini bütün ajanların paylaşmasını sağlayan ajan yönlendirici.
- Model üretimini oyun ana iş parçacığından ayıran tek-model çalışma kuyruğu.
- Yedi uzman + Koordinatör sentezli disiplinler arası toplantı zinciri.
- Model Merkezi: GGUF seçimi, yükleme/boşaltma ve lisans kaydı.
- **Android çalışma tanısı:** cihaz modeli, Android API, ABI, kullanılabilir/toplam RAM, uygulama depolama boş alanı ve backend durumunu gösterir.
- **Gerçek GGUF doğrulaması:** Android seçiminde dosyanın yalnız uzantısı değil GGUF imzası kontrol edilir.
- **Güvenli büyük model aktarımı:** boş alan kontrolü, arka plan kopyalama, yüzde ilerleme ve `.part` geçici dosyasıyla yarım kopya koruması.
- Android debug APK için hazır `export_presets.cfg`, otomatik eklenti etkinliği ve `tools/build_android_debug.sh`.
- **Tek tuş Türkçe yerel-model testi** ve isteğe bağlı açılışta otomatik GGUF yükleme.
- Temiz ortamda APK üreten `.github/workflows/android-debug-apk.yml` CI hattı.
- Android araç zincirini kontrol eden `tools/android_preflight.py`.
- llama.cpp kaynağı günlük `master` yerine varsayılan olarak **`v0.4.1`** sürümüne sabitlenmiştir.
- **Proje Çalışma Alanı:** birden fazla proje oluşturma ve aktif proje seçme.
- **Yerel belge bilgi tabanı:** proje belgelerini parçalara ayırıp cihaz içinde indeksleme.
- **Kaynaklı RAG:** soruyla ilgili belge parçalarını seçip yalnızca ilgili bağlamı ajana verme.
- Kaynağa dayanan cevaplarda `[Kaynak N: Belge adı · parça X]` etiketini kullanma talimatı.
- Android sistem dosya seçicisiyle PDF/TXT/MD/CSV/JSON içe aktarma.
- PDF metnini Android üzerinde cihaz içinde çıkarma; belge internet servisine gönderilmez.
- Taranmış/görüntü tabanlı PDF'lerde OCR henüz etkin değildir.
- **İhale ve Sözleşme Bilgi Merkezi:** KİK kararları, YFK karar/görüşleri ve ihale mevzuatını ayrı kaynak türleriyle cihaz içinde indeksleme.
- İhale uzmanının yerel karar arşivinde benzer karar bulması; KİK/YFK/mevzuat kaynak etiketlerini cevapta koruması.
- Karar numarası/tarihinin belgede bulunmadığı durumda uydurmayı engelleyen kaynak kuralları.
- Yerel arşivin belge/parça/KİK/YFK/mevzuat kapsamını kullanıcıya gösteren arşiv durumu.
- KİK/EKAP resmi karar sorgu ekranı ve YFK resmi sayfasını uygulamadan açabilme.
- Toplu karar korpusu için `yerel_ai_procurement_bundle` JSON biçimi ve `tools/build_procurement_bundle.py`.
- İhale/sözleşme konusu geçen uzman toplantılarına İhale ve Sözleşme Uzmanının otomatik katılması.
- **Mühendislik Hesap Masası:** kullanıcı tarafından doğrudan çalıştırılabilen deterministik temel hesap araçları.
- **Ajan araç çağırma protokolü:** İnşaat Mühendisi, Koordinatör ve Genel Yerel Zekâ gerektiğinde hesap aracını otomatik çağırır; sayısal sonucu LLM üretmez.
- Basit kiriş yayılı/tekil yük hesapları, dikdörtgen kesit özellikleri, eksenel gerilme, alan yükü→çizgisel yük, öz ağırlık ve temel birim dönüşümleri.
- Hesapların cihaz içinde JSONL geçmişine kaydı; aktif proje ve çağıran ajan kimliği korunur.
- Mevzuat ve standart hesabı ile temel mekanik hesabı ayrılmıştır; v0.0.4 herhangi bir yapısal eleman için yönetmeliğe göre otomatik “uygun/yetersiz” kararı vermez.

## Masaüstünde çalıştırma

1. Godot 4.7.2 stable ile `project.godot` dosyasını aç.
2. F6/F5 ile çalıştır.
3. WASD/ok tuşlarıyla yürü; `E` veya `KONUŞ` ile etkileş.
4. `PROJE` ekranından proje oluştur ve TXT/MD/CSV/JSON belge ekle.
5. Native Android eklentisi yoksa AI demo yanıtı verir; dünya, proje ve yerel arama katmanı yine test edilebilir.

Masaüstü PDF metin çıkarımı bu prototipte etkin değildir. Android sürümünde PDF, cihaz içinde işlenir.

## Android'de gerçek yerel AI

Kaynak köprü paketin içindedir ancak derlenmiş AAR ikilileri ZIP'e gömülü değildir. Ayrıntılar `docs/ANDROID_LOCAL_AI.md` içindedir.

Kısa akış:

```bash
cd android_plugin
./prepare_llama_android.sh
./build_and_install.sh
```

v0.0.8’da eklenti ve Android debug export preset proje içinde hazırdır. AAR’lar derlendikten sonra proje kökünde `./tools/build_android_debug.sh` gerçek debug APK üretim hattını çalıştırır. Ayrıntılar `docs/ANDROID_BUILD_V008.md` içindedir.

## Proje belgeleri ve RAG

Sistem ilk aşamada embedding modeli gerektirmeyen hafif bir yerel arama kullanır. Soru Türkçe normalize edilir; belge parçaları anahtar sözcük, ifade eşleşmesi ve belge adı sinyallerine göre puanlanır. En ilgili parçalar yapay zekâ istemine kaynak etiketiyle eklenir.

Bu yaklaşım özellikle mobil prototipte hızlı ve tamamen yereldir. Daha sonra lisansı uygun bir embedding modeli doğrulanırsa hibrit semantik arama eklenebilir; çekirdek proje formatı buna bağımlı değildir.

## İhale, KİK ve YFK arşivi

İhale ve Sözleşme Uzmanı yerel modelin ezberine güvenmez. Cihazda indekslenen karar/mevzuat korpusunu sorgular ve bulduğu parçaları KİK, YFK veya mevzuat olarak ayrı etiketler. KİK/YFK kararının numarası veya tarihi kaynakta açık değilse kesin karar numarası üretmemesi sistem isteminde zorunlu tutulur.

Resmi başvuru noktaları `config/procurement_sources.json` içinde kayıtlıdır. Karar metinlerinin tamamı uygulama paketine gömülmez. Kullanıcı, kurum tarafından yayımlanan kararları PDF/metin olarak yerel arşive ekleyebilir. Çok sayıda metin tabanlı karar için `tools/build_procurement_bundle.py` tek JSON korpus paketi üretir.

Ayrıntılar: `docs/IHALE_KIK_YFK.md`.

## Donma ve performans ilkesi

- LLM üretimi oyun ana iş parçacığında çalışmaz.
- GGUF kopyalama Android arayüz iş parçacığında yapılmaz.
- PDF metin çıkarımı Android arayüz iş parçacığında yapılmaz.
- Belge okuma ve indeksleme ayrı iş parçacığında yürütülür.
- Tek model paylaşılır; sekiz ayrı büyük model aynı anda belleğe yüklenmez.

## Lisans yaklaşımı

- Ücretli API zorunluluğu yoktur.
- `llama.cpp` ile seçilen GGUF modelinin lisansı ayrı değerlendirilir.
- PDFBox-Android yalnızca yerel PDF metin çıkarımı için kullanılır.
- Modelin teknik olarak çalışması, ticari dağıtıma uygun olduğu anlamına gelmez.
- Lisansı ve ticari/yeniden dağıtım şartları doğrulanmayan model uygulamanın içine gömülmez.

## Sıradaki aşamalar

- **v0.0.8 doğrulaması:** CI veya geliştirme makinesinde gerçek debug APK üretmek; fiziksel Android cihazda gerçek Türkçe GGUF ile smoke test ve performans ölçümü.
- **v0.0.8:** proje bazlı hesap senaryoları / hesap föyü ve İhale-KİK-YFK karar araştırmacısının derinleştirilmesi.
- Sonraki aşamada Türkçe yerel konuşma tanıma/seslendirme, NPC rutinleri ve araç sistemi.

## Mühendislik ilkesi

Dil modeli kritik mühendislik hesabının kendisi değildir. Problemi anlar, eksik girdileri belirler, kaynakları getirir, uygun hesap aracını çağırır ve sonucu açıklar. Nihai sayısal kontroller ayrı, test edilebilir ve birim kontrollü hesap motorlarında yürütülür.
