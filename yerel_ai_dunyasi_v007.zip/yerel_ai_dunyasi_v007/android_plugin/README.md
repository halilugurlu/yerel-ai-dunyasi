# YerelAIBackend Android Eklentisi

Godot 4.7 v2 Android eklentisidir. İki yerel görevi Godot'a açar:

- `llama.cpp` Android kütüphanesi üzerinden cihaz-içi GGUF çıkarımı.
- PDFBox-Android üzerinden cihaz-içi PDF metin çıkarımı ve belge içe aktarma.

## Derleme

```bash
./prepare_llama_android.sh
./build_and_install.sh
```

`prepare_llama_android.sh` geliştirici makinesinde kaynak bağımlılığı hazırlarken ağ erişimi gerektirir. Son kullanıcı tarafında çalışma için ücretli API gerekmez.

Başarılı derlemeden sonra Godot proje kökündeki `addons/YerelAIBackend/` altında debug/release eklenti AAR'ları ve llama AAR bulunur.

Belge seçimi Android Storage Access Framework ile yapılır; geniş depolama izni istenmez. PDF ve metin çıkarımı arka plandaki iş parçacığında yürütülür.
