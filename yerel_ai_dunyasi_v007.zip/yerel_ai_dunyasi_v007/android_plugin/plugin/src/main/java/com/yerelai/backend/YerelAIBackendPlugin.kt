package com.yerelai.backend

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.StatFs
import android.provider.OpenableColumns
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.isModelLoaded
import com.arm.aichat.gguf.GgufMetadataReader
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.runBlocking
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Godot <-> llama.cpp Android bridge.
 *
 * Heavy methods intentionally block the calling thread. The Godot-side InferenceService
 * invokes them from a dedicated worker thread, keeping rendering/input responsive.
 */
class YerelAIBackendPlugin(godot: Godot) : GodotPlugin(godot) {
    companion object {
        private const val REQUEST_OPEN_GGUF = 7301
        private const val REQUEST_OPEN_DOCUMENT = 7302
        private const val MAX_EXTRACTED_CHARS = 8_000_000
        private const val MODEL_COPY_BUFFER = 1024 * 1024
        private const val MODEL_FREE_SPACE_RESERVE = 256L * 1024L * 1024L
    }

    @Volatile
    private var engine: InferenceEngine? = null

    @Volatile
    private var loaded = false

    @Volatile
    private var activeModelPath: String = ""

    override fun getPluginName() = BuildConfig.GODOT_PLUGIN_NAME

    override fun getPluginSignals(): MutableSet<SignalInfo> = mutableSetOf(
        SignalInfo("modelImported", String::class.java, String::class.java),
        SignalInfo("modelImportProgress", String::class.java, String::class.java),
        SignalInfo("modelImportFailed", String::class.java),
        SignalInfo("documentImported", String::class.java, String::class.java, String::class.java),
        SignalInfo("documentImportFailed", String::class.java)
    )

    private fun ensureEngine(): InferenceEngine {
        val current = engine
        if (current != null) return current

        val appContext = requireNotNull(activity) {
            "Android Activity henüz hazır değil."
        }.applicationContext

        return AiChat.getInferenceEngine(appContext).also { engine = it }
    }

    @UsedByGodot
    fun isModelLoaded(): Boolean {
        val e = engine
        return loaded && e != null && e.state.value.isModelLoaded
    }

    @UsedByGodot
    fun getActiveModelPath(): String = activeModelPath

    @UsedByGodot
    fun getBackendInfo(): String =
        "llama.cpp resmi Android bağlayıcısı · GGUF · tamamen cihaz içinde"


    @UsedByGodot
    fun getRuntimeDiagnostics(): String {
        return try {
            val host = requireNotNull(activity) { "Android Activity henüz hazır değil." }
            val activityManager = host.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val memoryInfo = android.app.ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }
            val filesStat = StatFs(host.filesDir.absolutePath)
            JSONObject()
                .put("ok", true)
                .put("android_sdk", Build.VERSION.SDK_INT)
                .put("device", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                .put("abis", JSONArray(Build.SUPPORTED_ABIS.toList()))
                .put("memory_total_bytes", memoryInfo.totalMem)
                .put("memory_available_bytes", memoryInfo.availMem)
                .put("storage_available_bytes", filesStat.availableBytes)
                .put("model_loaded", isModelLoaded())
                .put("active_model_path", activeModelPath)
                .put("backend", getBackendInfo())
                .toString()
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("error", t.message ?: t.javaClass.simpleName).toString()
        }
    }

    @UsedByGodot
    fun inspectModel(path: String): String {
        return try {
            val file = File(path)
            require(file.isFile) { "GGUF dosyası bulunamadı: $path" }
            require(file.extension.equals("gguf", ignoreCase = true)) { "Seçilen dosya .gguf değil." }
            val valid = runBlocking { GgufMetadataReader.create().ensureSourceFileFormat(file) }
            require(valid) { "Dosyanın GGUF imzası doğrulanamadı." }
            JSONObject()
                .put("ok", true)
                .put("valid_gguf", true)
                .put("name", file.name)
                .put("path", file.absolutePath)
                .put("size_bytes", file.length())
                .toString()
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("error", t.message ?: t.javaClass.simpleName).toString()
        }
    }

    @UsedByGodot
    fun loadModel(path: String): String {
        return try {
            val modelFile = File(path)
            require(modelFile.isFile) { "GGUF dosyası bulunamadı: $path" }
            require(modelFile.extension.equals("gguf", ignoreCase = true)) {
                "Seçilen dosya .gguf değil."
            }
            val validGguf = runBlocking { GgufMetadataReader.create().ensureSourceFileFormat(modelFile) }
            require(validGguf) { "Dosyanın GGUF imzası doğrulanamadı." }

            val e = ensureEngine()
            if (e.state.value.isModelLoaded) {
                e.cleanUp()
            }

            runBlocking {
                e.loadModel(modelFile.absolutePath)
            }
            loaded = e.state.value.isModelLoaded
            activeModelPath = if (loaded) modelFile.absolutePath else ""

            JSONObject()
                .put("ok", loaded)
                .put("path", activeModelPath)
                .put("error", if (loaded) "" else "Model yüklendi ancak backend ModelReady durumuna geçmedi.")
                .toString()
        } catch (t: Throwable) {
            loaded = false
            activeModelPath = ""
            JSONObject()
                .put("ok", false)
                .put("error", t.message ?: t.javaClass.simpleName)
                .toString()
        }
    }

    @UsedByGodot
    fun unloadModel() {
        try {
            engine?.cleanUp()
        } finally {
            loaded = false
            activeModelPath = ""
        }
    }

    /**
     * Payload schema:
     * {
     *   "system": "...",
     *   "message": "...",
     *   "context": [{"user":"...", "assistant":"..."}],
     *   "generation": {"max_tokens": 768}
     * }
     */
    @UsedByGodot
    fun generate(payloadJson: String): String {
        return try {
            val e = ensureEngine()
            check(e.state.value.isModelLoaded && loaded) { "Önce bir GGUF model yüklenmeli." }

            val payload = JSONObject(payloadJson)
            val system = payload.optString("system", "")
            val message = payload.optString("message", "")
            val context = payload.optJSONArray("context") ?: JSONArray()
            val generation = payload.optJSONObject("generation") ?: JSONObject()
            val maxTokens = generation.optInt("max_tokens", 768).coerceIn(64, 4096)

            val contextualPrompt = buildContextPrompt(context, message)
            val output = StringBuilder()

            runBlocking {
                e.setSystemPrompt(system)
                e.sendUserPrompt(contextualPrompt, maxTokens).collect { token ->
                    output.append(token)
                }
            }

            output.toString().trim()
        } catch (t: Throwable) {
            "ERROR:${t.message ?: t.javaClass.simpleName}"
        }
    }

    private fun buildContextPrompt(context: JSONArray, message: String): String {
        if (context.length() == 0) return message

        val sb = StringBuilder()
        sb.append("ÖNCEKİ KONUŞMA BAĞLAMI\n")
        for (i in 0 until context.length()) {
            val item = context.optJSONObject(i) ?: continue
            val speaker = item.optString("speaker", "").trim()
            val text = item.optString("text", "").trim()
            if (speaker.isNotEmpty() && text.isNotEmpty()) {
                when (speaker.lowercase()) {
                    "user" -> sb.append("KULLANICI: ").append(text).append('\n')
                    "assistant" -> sb.append("ASİSTAN: ").append(text).append('\n')
                    else -> sb.append(speaker.uppercase()).append(": ").append(text).append('\n')
                }
                continue
            }

            // Backward/alternate payload compatibility.
            val user = item.optString("user", "").trim()
            val assistant = item.optString("assistant", "").trim()
            if (user.isNotEmpty()) sb.append("KULLANICI: ").append(user).append('\n')
            if (assistant.isNotEmpty()) sb.append("ASİSTAN: ").append(assistant).append('\n')
        }
        sb.append("\nGÜNCEL KULLANICI MESAJI\n").append(message)
        return sb.toString()
    }

    /** Opens Android's Storage Access Framework so no raw storage permission is needed. */
    @UsedByGodot
    fun pickModel(): Boolean {
        val host = activity ?: return false
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/gguf", "*/*"))
        }
        host.runOnUiThread { host.startActivityForResult(intent, REQUEST_OPEN_GGUF) }
        return true
    }


    /**
     * Opens Android's document picker. PDF and common text formats are processed fully on-device.
     * Extracted plain text is written under app-private files/documents and indexed by Godot later.
     */
    @UsedByGodot
    fun pickDocument(): Boolean {
        val host = activity ?: return false
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("application/pdf", "text/plain", "text/markdown", "text/csv", "application/json")
            )
        }
        host.runOnUiThread { host.startActivityForResult(intent, REQUEST_OPEN_DOCUMENT) }
        return true
    }

    override fun onMainActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onMainActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return

        val uri = data.data ?: return
        val host = activity ?: return

        when (requestCode) {
            REQUEST_OPEN_GGUF -> {
                // GGUF files can be multiple gigabytes. Never copy them on the Android UI thread.
                Thread {
                    try {
                        val resolver = host.contentResolver
                        val rawName = queryDisplayName(uri) ?: "model.gguf"
                        val safeName = sanitizeModelName(rawName)
                        require(safeName.lowercase().endsWith(".gguf")) { "Yalnızca .gguf model dosyası seçilebilir." }

                        val sourceValid = runBlocking {
                            GgufMetadataReader.create().ensureSourceFileFormat(host, uri)
                        }
                        require(sourceValid) { "Seçilen dosyanın GGUF imzası geçersiz." }

                        val modelsDir = File(host.filesDir, "models").apply { mkdirs() }
                        val target = uniqueTarget(modelsDir, safeName)
                        val partial = File(modelsDir, target.name + ".part")
                        val sourceSize = querySize(uri)
                        val available = StatFs(modelsDir.absolutePath).availableBytes
                        if (sourceSize > 0) {
                            require(available > sourceSize + MODEL_FREE_SPACE_RESERVE) {
                                "Model için yeterli boş alan yok. Gerekli: ${formatBytes(sourceSize + MODEL_FREE_SPACE_RESERVE)}, kullanılabilir: ${formatBytes(available)}."
                            }
                        }

                        partial.delete()
                        var copied = 0L
                        var lastPercent = -1
                        try {
                            resolver.openInputStream(uri).use { input ->
                                requireNotNull(input) { "Seçilen dosya açılamadı." }
                                FileOutputStream(partial).use { output ->
                                    val buffer = ByteArray(MODEL_COPY_BUFFER)
                                    while (true) {
                                        val count = input.read(buffer)
                                        if (count <= 0) break
                                        output.write(buffer, 0, count)
                                        copied += count
                                        val percent = if (sourceSize > 0) ((copied * 100L) / sourceSize).toInt().coerceIn(0, 100) else -1
                                        if (percent < 0 || percent >= lastPercent + 5 || percent == 100) {
                                            lastPercent = percent
                                            val progressText = if (percent >= 0) "%$percent" else formatBytes(copied)
                                            val detail = if (sourceSize > 0) "${formatBytes(copied)} / ${formatBytes(sourceSize)}" else formatBytes(copied)
                                            host.runOnUiThread { emitSignal("modelImportProgress", progressText, detail) }
                                        }
                                    }
                                    output.fd.sync()
                                }
                            }
                            require(sourceSize <= 0 || copied == sourceSize) {
                                "Model kopyalama tamamlanamadı (${formatBytes(copied)} / ${formatBytes(sourceSize)})."
                            }
                            require(partial.renameTo(target)) { "Model geçici dosyadan kalıcı dosyaya taşınamadı." }
                        } catch (t: Throwable) {
                            partial.delete()
                            throw t
                        }

                        host.runOnUiThread {
                            emitSignal("modelImportProgress", "%100", "Tamamlandı · ${formatBytes(copied)}")
                            emitSignal("modelImported", target.absolutePath, target.name)
                        }
                    } catch (t: Throwable) {
                        host.runOnUiThread { emitSignal("modelImportFailed", t.message ?: t.javaClass.simpleName) }
                    }
                }.start()
            }
            REQUEST_OPEN_DOCUMENT -> importDocumentAsync(uri)
        }
    }



    private fun importDocumentAsync(uri: android.net.Uri) {
        val host = activity ?: return
        Thread {
            try {
                val resolver = host.contentResolver
                val displayName = queryDisplayName(uri) ?: "belge"
                val mime = resolver.getType(uri) ?: guessMime(displayName)
                val lowerName = displayName.lowercase()
                val isPdf = mime == "application/pdf" || lowerName.endsWith(".pdf")
                val isText = mime.startsWith("text/") || lowerName.endsWith(".txt") ||
                    lowerName.endsWith(".md") || lowerName.endsWith(".csv") || lowerName.endsWith(".json")
                require(isPdf || isText) {
                    "Desteklenmeyen belge türü. PDF, TXT, MD, CSV veya JSON seç."
                }

                val extracted = resolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Seçilen belge açılamadı." }
                    if (isPdf) extractPdfText(input) else readTextCapped(input)
                }.trim()

                require(extracted.length >= 20) {
                    if (isPdf) "PDF içinde seçilebilir metin bulunamadı. Taranmış/görüntü PDF için OCR henüz etkin değil."
                    else "Belgede kullanılabilir metin bulunamadı."
                }

                val docsDir = File(host.filesDir, "documents").apply { mkdirs() }
                val safeBase = sanitizeDocumentName(displayName.substringBeforeLast('.', displayName))
                val target = uniqueTarget(docsDir, "$safeBase.txt")
                target.writeText(extracted.take(MAX_EXTRACTED_CHARS), Charsets.UTF_8)

                // Godot user:// maps to the app-private files directory on Android.
                val godotPath = "user://documents/${target.name}"
                host.runOnUiThread { emitSignal("documentImported", godotPath, displayName, mime) }
            } catch (t: Throwable) {
                host.runOnUiThread { emitSignal("documentImportFailed", t.message ?: t.javaClass.simpleName) }
            }
        }.start()
    }

    private fun extractPdfText(input: java.io.InputStream): String {
        val appContext = requireNotNull(activity).applicationContext
        PDFBoxResourceLoader.init(appContext)
        PDDocument.load(input).use { document ->
            val stripper = PDFTextStripper()
            stripper.sortByPosition = true
            return stripper.getText(document).take(MAX_EXTRACTED_CHARS)
        }
    }

    private fun readTextCapped(input: java.io.InputStream): String {
        val reader = input.bufferedReader(Charsets.UTF_8)
        val buffer = CharArray(16 * 1024)
        val out = StringBuilder()
        while (out.length < MAX_EXTRACTED_CHARS) {
            val remaining = MAX_EXTRACTED_CHARS - out.length
            val n = reader.read(buffer, 0, minOf(buffer.size, remaining))
            if (n <= 0) break
            out.append(buffer, 0, n)
        }
        return out.toString()
    }

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> "application/pdf"
        "md" -> "text/markdown"
        "csv" -> "text/csv"
        "json" -> "application/json"
        else -> "text/plain"
    }

    private fun sanitizeDocumentName(name: String): String {
        val clean = name.replace(Regex("[^A-Za-z0-9._() -]"), "_").trim().take(150)
        return if (clean.isBlank()) "belge" else clean
    }


    private fun querySize(uri: android.net.Uri): Long {
        val resolver = activity?.contentResolver ?: return -1L
        resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index)
            }
        }
        return -1L
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 0) return "bilinmiyor"
        val gb = bytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        if (gb >= 1.0) return String.format(java.util.Locale.US, "%.2f GB", gb)
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        return String.format(java.util.Locale.US, "%.1f MB", mb)
    }

    private fun queryDisplayName(uri: android.net.Uri): String? {
        val resolver = activity?.contentResolver ?: return null
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun sanitizeModelName(name: String): String {
        val clean = name.replace(Regex("[^A-Za-z0-9._() -]"), "_").trim().take(180)
        return if (clean.isBlank()) "model.gguf" else clean
    }

    private fun uniqueTarget(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate

        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "gguf")
        var i = 2
        while (candidate.exists()) {
            candidate = File(dir, "$base-$i.$ext")
            i++
        }
        return candidate
    }

    override fun onMainDestroy() {
        try {
            engine?.destroy()
        } finally {
            engine = null
            loaded = false
            activeModelPath = ""
        }
        super.onMainDestroy()
    }
}
