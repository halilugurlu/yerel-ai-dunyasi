plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

val pluginName = "YerelAIBackend"
val pluginPackageName = "com.yerelai.backend"
val llamaAar = file("libs/llama-android-release.aar")

android {
    namespace = pluginPackageName
    compileSdk = 36

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        minSdk = 33
        manifestPlaceholders["godotPluginName"] = pluginName
        manifestPlaceholders["godotPluginPackageName"] = pluginPackageName
        buildConfigField("String", "GODOT_PLUGIN_NAME", "\"$pluginName\"")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17)
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}


dependencies {
    implementation("org.godotengine:godot:4.7.2.stable")

    // llama.cpp's Android lib AAR is built by prepare_llama_android.sh.
    // It is compileOnly here because Godot exports that AAR separately next to this plugin AAR.
    compileOnly(files(llamaAar))

    // The llama.cpp APIs used by this bridge require coroutines, but do not
    // reference AndroidX Core or DataStore. Keeping those unused dependencies
    // out of the exported app avoids forcing Godot 4.7.2's AGP 8.6.1 to consume
    // AndroidX Core 1.17, which requires AGP 8.9.1+.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}

val exportTemplateDir = rootProject.layout.projectDirectory.dir("export_scripts_template")
val projectAddonDir = rootProject.layout.projectDirectory.dir("../addons/$pluginName")

tasks.register<Copy>("installDebugToGodot") {
    dependsOn("assembleDebug")
    from(layout.buildDirectory.file("outputs/aar/plugin-debug.aar")) {
        rename { "$pluginName-debug.aar" }
    }
    from(llamaAar)
    into(projectAddonDir.dir("bin/debug"))
    doLast {
        copy {
            from(exportTemplateDir)
            include("export_plugin.gd", "plugin.cfg")
            into(projectAddonDir)
        }
    }
}

tasks.register<Copy>("installReleaseToGodot") {
    dependsOn("assembleRelease")
    from(layout.buildDirectory.file("outputs/aar/plugin-release.aar")) {
        rename { "$pluginName-release.aar" }
    }
    from(llamaAar)
    into(projectAddonDir.dir("bin/release"))
    doLast {
        copy {
            from(exportTemplateDir)
            include("export_plugin.gd", "plugin.cfg")
            into(projectAddonDir)
        }
    }
}
