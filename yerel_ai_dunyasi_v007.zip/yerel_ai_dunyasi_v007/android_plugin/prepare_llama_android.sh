#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THIRD_PARTY="$HERE/.third_party"
LLAMA_DIR="$THIRD_PARTY/llama.cpp"
LLAMA_REF="${LLAMA_CPP_REF:-v0.4.1}"
DEST="$HERE/plugin/libs/llama-android-release.aar"

mkdir -p "$THIRD_PARTY" "$(dirname "$DEST")"

if [[ ! -d "$LLAMA_DIR/.git" ]]; then
  rm -rf "$LLAMA_DIR"
  git clone --depth 1 --branch "$LLAMA_REF" --single-branch \
    https://github.com/ggml-org/llama.cpp.git "$LLAMA_DIR"
else
  git -C "$LLAMA_DIR" fetch --depth 1 origin "refs/tags/$LLAMA_REF:refs/tags/$LLAMA_REF" || true
  git -C "$LLAMA_DIR" checkout -f "$LLAMA_REF"
fi

GRADLE_FILE="$LLAMA_DIR/examples/llama.android/lib/build.gradle.kts"
python3 - "$GRADLE_FILE" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8')
old='abiFilters += listOf("arm64-v8a", "x86_64")'
new='abiFilters += listOf("arm64-v8a")'
if old in s:
    s=s.replace(old,new)
elif new not in s:
    raise SystemExit('llama.cpp Android ABI satırı beklenen biçimde değil.')
p.write_text(s,encoding='utf-8')
PY

chmod +x "$LLAMA_DIR/examples/llama.android/gradlew"
pushd "$LLAMA_DIR/examples/llama.android" >/dev/null
./gradlew :lib:assembleRelease --no-daemon --max-workers="$(nproc)"
popd >/dev/null

SOURCE_AAR="$LLAMA_DIR/examples/llama.android/lib/build/outputs/aar/lib-release.aar"
test -s "$SOURCE_AAR"
cp "$SOURCE_AAR" "$DEST"
git -C "$LLAMA_DIR" rev-parse HEAD > "$HERE/LLAMA_CPP_REVISION.txt"
echo "Hazır: $DEST"
echo "llama.cpp revision: $(cat "$HERE/LLAMA_CPP_REVISION.txt")"
