#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THIRD_PARTY="$HERE/.third_party"
LLAMA_DIR="$THIRD_PARTY/llama.cpp"
LLAMA_REF="${LLAMA_CPP_REF:-v0.4.1}"
DEST="$HERE/plugin/libs/llama-android-release.aar"

mkdir -p "$THIRD_PARTY" "$(dirname "$DEST")"

if [[ ! -d "$LLAMA_DIR/.git" ]]; then
  rm -rf "$LLAMA_DIR"
  git clone --depth 1 --branch "$LLAMA_REF" --single-branch \
    https://github.com/ggml-org/llama.cpp.git "$LLAMA_DIR"
else
  git -C "$LLAMA_DIR" fetch --depth 1 origin "refs/tags/$LLAMA_REF:refs/tags/$LLAMA_REF" || true
  git -C "$LLAMA_DIR" checkout -f "$LLAMA_REF"
fi

VERSION_FILE="$LLAMA_DIR/examples/llama.android/gradle/libs.versions.toml"
WRAPPER_FILE="$LLAMA_DIR/examples/llama.android/gradle/wrapper/gradle-wrapper.properties"

python3 - "$VERSION_FILE" "$WRAPPER_FILE" <<'PY2'
from pathlib import Path
import sys
version_file = Path(sys.argv[1])
wrapper_file = Path(sys.argv[2])
s = version_file.read_text(encoding="utf-8")
s = s.replace('agp = "8.13.2"', 'agp = "8.6.1"')
s = s.replace('kotlin = "2.3.0"', 'kotlin = "2.1.21"')
version_file.write_text(s, encoding="utf-8")
w = wrapper_file.read_text(encoding="utf-8")
w = w.replace('gradle-8.14.3-bin.zip', 'gradle-8.7-bin.zip')
wrapper_file.write_text(w, encoding="utf-8")
PY2

GRADLE_FILE="$LLAMA_DIR/examples/llama.android/lib/build.gradle.kts"
python3 - "$GRADLE_FILE" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8')
old='abiFilters += listOf("arm64-v8a", "x86_64")'
new='abiFilters += listOf("arm64-v8a")'
if old in s:
    s=s.replace(old,new)
elif new not in s:
    raise SystemExit('llama.cpp Android ABI satırı beklenen biçimde değil.')
s=s.replace('    implementation(libs.androidx.core.ktx)\n', '')
s=s.replace('    implementation(libs.androidx.datastore.preferences)\n', '')
needle='dependencies {\n'
coroutines='    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")\n'
if coroutines not in s:
    s=s.replace(needle, needle+coroutines, 1)
p.write_text(s,encoding='utf-8')
PY

chmod +x "$LLAMA_DIR/examples/llama.android/gradlew"
pushd "$LLAMA_DIR/examples/llama.android" >/dev/null
./gradlew :lib:assembleRelease --no-daemon --max-workers="$(nproc)"
popd >/dev/null

SOURCE_AAR="$LLAMA_DIR/examples/llama.android/lib/build/outputs/aar/lib-release.aar"
test -s "$SOURCE_AAR"
cp "$SOURCE_AAR" "$DEST"
git -C "$LLAMA_DIR" rev-parse HEAD > "$HERE/LLAMA_CPP_REVISION.txt"
echo "Hazır: $DEST"
echo "llama.cpp revision: $(cat "$HERE/LLAMA_CPP_REVISION.txt")"
