#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THIRD_PARTY="$HERE/.third_party"
LLAMA_DIR="$THIRD_PARTY/llama.cpp"
LLAMA_REF="${LLAMA_CPP_REF:-v0.4.1}"
DEST="$HERE/plugin/libs/llama-android-release.aar"

mkdir -p "$THIRD_PARTY" "$(dirname "$DEST")"

if [[ ! -d "$LLAMA_DIR/.git" ]]; then
  git clone https://github.com/ggml-org/llama.cpp.git "$LLAMA_DIR"
fi

git -C "$LLAMA_DIR" fetch --tags --prune origin
git -C "$LLAMA_DIR" checkout "$LLAMA_REF"
if [[ "$LLAMA_REF" == "master" ]]; then
  echo "UYARI: master değişkendir. Tekrarlanabilir derleme için LLAMA_CPP_REF ile sürüm/commit sabitle." >&2
  git -C "$LLAMA_DIR" pull --ff-only origin master
fi

pushd "$LLAMA_DIR/examples/llama.android" >/dev/null
./gradlew :lib:assembleRelease --no-daemon
popd >/dev/null

SOURCE_AAR="$LLAMA_DIR/examples/llama.android/lib/build/outputs/aar/lib-release.aar"
if [[ ! -f "$SOURCE_AAR" ]]; then
  echo "llama.cpp Android AAR bulunamadı: $SOURCE_AAR" >&2
  exit 1
fi

cp "$SOURCE_AAR" "$DEST"
git -C "$LLAMA_DIR" rev-parse HEAD > "$HERE/LLAMA_CPP_REVISION.txt"
echo "Hazır: $DEST"
echo "llama.cpp revision: $(cat "$HERE/LLAMA_CPP_REVISION.txt")"
