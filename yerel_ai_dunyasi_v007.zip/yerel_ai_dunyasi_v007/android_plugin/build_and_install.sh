#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LLAMA_DIR="$HERE/.third_party/llama.cpp"

if [[ ! -s "$HERE/plugin/libs/llama-android-release.aar" ]]; then
  "$HERE/prepare_llama_android.sh"
fi

if [[ ! -x "$LLAMA_DIR/examples/llama.android/gradlew" ]]; then
  echo "Gradle wrapper bulunamadı. Önce prepare_llama_android.sh çalıştır." >&2
  exit 1
fi

TASKS=(":plugin:installDebugToGodot")
if [[ "${BUILD_RELEASE_PLUGIN:-0}" == "1" ]]; then
  TASKS+=(":plugin:installReleaseToGodot")
fi

"$LLAMA_DIR/examples/llama.android/gradlew" -p "$HERE" "${TASKS[@]}" \
  --no-daemon --max-workers="$(nproc)"

echo "YerelAIBackend Godot projesindeki addons/YerelAIBackend klasörüne kuruldu."
